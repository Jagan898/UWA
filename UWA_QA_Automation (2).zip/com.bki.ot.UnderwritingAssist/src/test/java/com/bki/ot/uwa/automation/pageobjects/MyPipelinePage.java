package com.bki.ot.uwa.automation.pageobjects;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import java.util.List;

public class MyPipelinePage {
	WebDriver driver;

	public MyPipelinePage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);

	}

	// *******************My Pipeline Page Generic
	// Elements************************************************
	@FindBy(xpath = "//*[@class='logo']/descendant::img[@alt='logo']")
	public WebElement Mypipelinepage_Logo;
	@FindBy(xpath = "//*[@class='header-name']")
	public WebElement Mypipelinepage_Logo_text;
	@FindBy(xpath = "//*[@class='menu-title']")
	public WebElement Mypipelinepage_Menu_section;
	@FindBy(xpath = "//*[contains(@class,'side-nav__item')]/descendant::span")
	public WebElement Mypipelinepage_LeftPanel_PipelineHeading;
	@FindBy(xpath = "//*[text()='Pipeline']/preceding::*[@data-icon='folders']")
	public WebElement Mypipelinepage_Pipeline_Folder_icon;
	@FindBy(xpath = "//*[@class='pipeline-search-container']/descendant::mat-label")
	public List<WebElement> Mypipelinepage_SearchOptions_list;
	@FindBy(xpath = "//*[@class='pipeline-search-container']/descendant::button[@class='btn__search']")
	public WebElement Mypipelinepage_ClearSearch_link;
	@FindBy(xpath = "//*[text()='New Loan']")
	public WebElement Mypipelinepage_NewLoan_button;
	@FindBy(xpath = "//*[@data-icon='times']")
	public WebElement Mypipelinepage_close_ICon;	
	@FindBy(xpath = "//div[normalize-space(text())='Sign out']")
	public WebElement Mypipelinepage_SignOut_Msg;
	@FindBy(xpath = "//span[@class='session-model__remain-time']")
	public WebElement Mypipelinepage_RemainingTime_Msg;
	@FindBy(xpath = "//button[text()='Reset Session']")	
	public WebElement Mypipelinepage_Session_ExpireScreen;
	@FindBy(xpath = "//h1[normalize-space(text())='Session Timeout']")	
	public WebElement Mypipelinepage_SessionTimeOut_Msg;	
	@FindBy(xpath = "//*[text()='New Loan']/preceding-sibling::*[@data-icon='upload']")
	public WebElement Mypipelinepage_NewLoan_Upload_icon;
	@FindBy(xpath = "//nav[@class='sidebar']")
	public WebElement Mypipeline_menu_sidebar;
	@FindBy(xpath = "//*[@data-icon='bars']")
	public WebElement Mypipelinepage_Menu_CollapseExpand_Icon;
	@FindBy(xpath = "//*[@id='table-rec-det'] ")
	public WebElement Mypipelinepage_GridResults_Message;

	@FindBy(xpath = "//a[@href='/pipe-line']")
	public WebElement Mypipeline_menu_pipeline;

	@FindBy(xpath = "//nav[@class='colapsed-sidebar']")
	public WebElement Mypipeline_menu_collapse;
	@FindBy(xpath = "//*[@class='lone-list-table']/following-sibling::div[@id='snackbar']")
	public WebElement Mypipeline_File_validation_message;

	// LoanType Text is displayed.
	@FindBy(xpath = "//*[@id=\"mat-form-field-label-5\"]/mat-label")
	public WebElement Mypipeline_LoanType_title;

	// LoanType Text is displayed.
	@FindBy(xpath = "//*[@id='mat-select-value-1']")
	public WebElement Mypipeline_LoanType_List;

	// LoanNumber Text feild .
	@FindBy(xpath = "//input[@name='LoanID']")
	public WebElement Mypipelinepage_FilterText_LoanNumber;

	@FindBy(xpath = "//input[@name='LastName']")
	public WebElement Mypipelinepage_FilterText_borrowerName;

	@FindBy(xpath = "//h1[text()='My Pipeline']")
	public WebElement myPipeLinePageHeader;

	@FindBy(xpath = "//mat-select[@name='MortgageType']")
	public WebElement Mypipelinepage_filetType_dropdown;

	@FindBy(xpath = "//mat-select[@name='MortgageType']")
	public WebElement Mypipelinepage_filetType_dropdown_option;
	
	@FindBy(xpath = "//table[contains(@class,'mat-table')]//th/div[@role='button']")
	public List<WebElement> Mypipelinepage_Headers_list;
	@FindBy(xpath = "//table[contains(@class,'mat-table')]//th/div[@role='button']")
	public List<WebElement> Mypipelinepage_SortIcons_list_Of_Headers;
	
	// ****************************Upload Pop up
	// Elements***********************************************
	@FindBy(xpath = "//*[@data-icon='times']")
	public WebElement Mypipelinepage_Upload_close;
	@FindBy(xpath = "//*[@class='file-heading']")
	public WebElement Mypipelinepage_Upload_FileHeading_yourUploads;
	@FindBy(xpath = "//*[@class='model-header']/following::*[@class='browse']")
	public WebElement Mypipelinepage_UploadPopup_BrowseFiles_link;
	@FindBy(xpath = "//*[contains(text(),'SAVE')] | //*[contains(text(),'ADD')]")
	public WebElement Mypipelinepage_UploadPopup_Save_button;

	@FindBy(xpath = "//*[@class='model-header']/following::mat-dialog-actions/button/span[contains(text(),'CANCEL')]")
	public WebElement Mypipelinepage_UploadPopup_Cancel_button;
	@FindBy(xpath = "(//*[contains(text(),'CANCEL')])[1]")
	public WebElement Mypipelinepage_Deletepopper_Cancel_button;
	@FindBy(xpath = "//*[contains(text(),'DELETE')]")
	public WebElement Mypipelinepage_UploadPopup_Delete_button;
	@FindBy(xpath = "//*[contains(text(),'Are you sure you want to delete this file?')]")
	public WebElement Mypipelinepage_UploadPopup_Deletepop_message;;
	@FindBy(xpath = "//*[@class='model-header']/following::*[@data-icon='upload'][2]")
	public WebElement Mypipelinepage_UploadPopup_Upload_icon;
	@FindBy(xpath = "//*[@id='fileDropRef']/following::div[@class='drag-drop']/p[1]")
	public WebElement Mypipelinepage_UploadPopup_DragDrop_text;
	@FindBy(xpath = "//*[@id='fileDropRef']/following::div[text()='Your loan file(s) here or']")
	public WebElement Mypipelinepage_UploadPopup_yourLoanFiles_text;

	@FindBy(xpath = "//*[@id='fileDropRef']")
	public WebElement Mypipelinepage_UploadPopup_uploadsection;

	@FindBy(xpath = "//*[@class='files-list']/descendant::div[@class='ng-star-inserted'][3]/following::span[1]")
	public WebElement Mypipelinepage_UploadPopup_first_Loannumber;
	@FindBy(xpath = "//*[contains(@class,'mat-dialog-title')]")
	public WebElement Mypipelinepage_UploadPopup_uploadsection_Header_Text;
	@FindBy(xpath = "//*[@class='heading__primary' and contains(text(),' All the loan files you added will be deleted if you quit the upload process now')]")
	public WebElement Mypipelinepage_UploadPopup_uploadsection_Middel_Text;

	@FindBy(xpath = "//*[@class='files-list']/descendant::div[@class='ng-star-inserted'][3]/following::span[2]")
	public WebElement Mypipelinepage_UploadPopup_BorrowerName;

	@FindBy(xpath = "//*[@class='files-list']/descendant::div[@class='ng-star-inserted'][3]/following::span[3]")
	public WebElement Mypipelinepage_UploadPopup_LoanType;
	// **************************** MiSMO File
	// elements***********************************************

	@FindBy(xpath = "(//*[@class='mismo-file-name'])[1]")
	public WebElement Mypipelinepage_UploadPopup_FirstFileName_text;
	@FindBy(xpath = "(//*[@class='mismo-file-name'])[2]")
	public WebElement Mypipelinepage_UploadPopup_SecondFileName_text;
	@FindBy(xpath = "(//*[@class='mismo-file-name'])[1]/following::*[contains(text(),'Uploading file...')][1]")
	public WebElement Mypipelinepage_UploadPopup_FirstMismo_Uploadingfile_text;
	@FindBy(xpath = "(//*[@class='mismo-file-name'])[1]/following::div[@class='progress-cont'][1]/div[@class='progress']")
	public WebElement Mypipelinepage_UploadPopup_FirstMismo_Uploadingbar;
	@FindBy(xpath = "(//*[@class='mismo-file-name'])[1]/following::*[contains(text(),'Estimated Time:')][1]")
	public WebElement Mypipelinepage_UploadPopup_FirstMismo_EstimationTime_text;
	@FindBy(xpath = "(//*[@class='mismo-file-name'])[1]/following::*[@data-icon='trash'][1]")
	public WebElement Mypipelinepage_UploadPopup_FirstMismo_Delete_icon;

	@FindBy(xpath = "//*[contains(@class,'error-info')] | //*[contains (@class,'error-message ng-star-inserted')]")
	public WebElement Mypipelinepage_UploadPopup_ErrorMessage_text;

	@FindBy(xpath = "(//*[@data-icon='check-circle'])[1]")
	public WebElement Mypipelinepage_UploadPopup_FirstMismoCheckcircle_icon;

	// ***********************************Grid Section
	// Elements*********************************
	@FindBy(xpath = "//*[@class='mat-tab-label-content']")
	public List<WebElement> Mypipelinepage_TabActiveInActive_list;
	@FindBy(xpath = "//*[@role='rowgroup']/descendant::div[@role='button']/descendant::span")
	public List<WebElement> Mypipelinepage_GridHeader_list;
	@FindBy(xpath = "//*[@data-icon='sort-up']")
	public List<WebElement> Mypipelinepage_GridHeader_Asscending_Sorting_icon;
	@FindBy(xpath = "//tbody[@role='rowgroup']/tr/td[2]")
	public List<WebElement> Mypipelinepage_Grid_BarrowerName_Data_list;
	@FindBy(xpath = "//tbody[@role='rowgroup']/tr/td[1]")
	public List<WebElement> Mypipelinepage_Grid_LoanNumber_Data_list;
	
	@FindBy(xpath = "//*[@data-icon='ellipsis-v']")
	public List<WebElement> Mypipelinepage_Grid_Elipseoption_List;

	@FindBy(xpath = "//*[@data-icon='bells']/following::span[1]")
	public List<WebElement> Mypipelinepage_Grid_Bellicons_List;
	@FindBy(xpath = "//*[@data-icon='file-exclamation']/following::span[1]")
	public List<WebElement> Mypipelinepage_Grid_Exclamation_Icon_List;

	// LoanType_DataList Text is displayed.
	@FindBy(xpath = "//tbody[@role='rowgroup']/tr/td[3]")
	public List<WebElement> Mypipeline_LoanType_DataList;

	@FindBy(xpath = "//tbody[@role='rowgroup']/tr/td[3]")
	public WebElement Mypipeline_LoanType_DataList_WithGridValue;
	
	@FindBy(xpath = "//table[contains(@class,'mat-table')]//th//span[contains(text(),'loan number')]")
	public WebElement Mypipelinepage_LoanNumber_Header;	
	@FindBy(xpath = "//table[contains(@class,'mat-table')]//th//span[contains(text(),'borrower last name')]")
	public WebElement Mypipelinepage_BorrowerLastName_Header;	
	@FindBy(xpath = "//th[@aria-sort='ascending']")
	public WebElement Mypipelinepage_SortingOrder_Type;
	@FindBy(xpath = "//span[@class='mismo-file-name']/parent::div/div[1]//button/span")
	public WebElement Mypipelinepage_FileUpload_Progress;
	@FindBy(xpath = "//button[contains(@class,'save')]")
	public WebElement Mypipelinepage_Save_Button;
	
	// ***********************Footer Elements ***********************************
	@FindBy(xpath = "//div[@class='footer-list']")
	public WebElement Mypipelinepage_footer;

	@FindBy(xpath = "//div[@class='footer-list']/div")
	public List<WebElement> Mypipelinepage_footer_list;

}
