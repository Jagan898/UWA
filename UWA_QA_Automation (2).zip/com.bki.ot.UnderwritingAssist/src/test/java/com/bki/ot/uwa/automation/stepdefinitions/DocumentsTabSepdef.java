package com.bki.ot.uwa.automation.stepdefinitions;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.support.ui.ExpectedConditions;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.GherkinKeyword;
import com.aventstack.extentreports.Status;
import com.bki.ot.uwa.automation.extentreport.ExtentReportConfig;
import com.bki.ot.uwa.automation.filereadermanager.FileReaderManager;
import com.bki.ot.uwa.automation.testcontext.TestContext;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.Then;

public class DocumentsTabSepdef extends ExtentReportConfig {

	Hooks hook;
	TestContext testContext;
	String url = null;
	public static String fname;

	public DocumentsTabSepdef(TestContext context) {
		testContext = context;
		hook = new Hooks(context);
		url = FileReaderManager.getFileReaderManagerInstance().getConfigInstance().getUrl();

	}

	@Then("^Navigate to \"(.*)\" view and then verify below fields in a sorted order$")
	public void VerifyHeaderandUploadbuttoninDocumentsTab(String fieldNameToVerify, DataTable dt) throws Exception {
		ExtentTest loginfo = null;
		try {
			loginfo = test.createNode(new GherkinKeyword("Then"), "Navigate to " + fieldNameToVerify
					+ " view and then verify Documents status with below Column header and sort option");
			hook.driver.findElement(By.xpath("//*[contains(@class,'" + fieldNameToVerify + "')]")).click();
			List<String> data = dt.asList(String.class);
			for (int i = 0; i < data.size(); i++) {
				if (hook.driver.findElement(By.xpath("//span[contains(text(),'" + data.get(i) + "')]")).isDisplayed())
					loginfo.log(Status.PASS, "Upload button displayed  : " + hook.driver
							.findElement(By.xpath("//span[contains(text(),'" + data.get(i) + "')]")).getText());
			}

		} catch (AssertionError e) {
			fname = hook.cm.addScreenshot(testContext);
			loginfo.log(Status.FAIL, "Verify Header and upload documents button" + e.getMessage());
			loginfo.addScreenCaptureFromPath(fname);

		}
	}

	@Then("^Navigate to table view$")
	public void clickOnTableView() throws Exception {
		ExtentTest loginfo = null;
		try {
			loginfo = test.createNode(new GherkinKeyword("Then"), "Navigate to table view");
			hook.wait.until(ExpectedConditions.visibilityOf(hook.lp.LoanLandingPage_UploadDocuments_TableViewButton));
			if (hook.lp.LoanLandingPage_UploadDocuments_TableViewButton.isDisplayed()) {
				JavascriptExecutor js = (JavascriptExecutor) hook.driver;
				js.executeScript("arguments[0].click();", hook.lp.LoanLandingPage_UploadDocuments_TableViewButton);
				loginfo.log(Status.PASS, "Clicked on Table view icon");
			}
		} catch (AssertionError e) {
			fname = hook.cm.addScreenshot(testContext);
			loginfo.log(Status.FAIL, "Table view icok is not available to click " + e.getMessage());
			loginfo.addScreenCaptureFromPath(fname);

		}

	}
	@Then("^Navigate to Grid view$")
	public void clickOnGridView() throws Exception {
		ExtentTest loginfo = null;
		try {
			loginfo = test.createNode(new GherkinKeyword("Then"), "Navigate to Grid view");
			hook.wait.until(ExpectedConditions.visibilityOf(hook.lp.LoanLandingPage_UploadDocuments_gridViewButton));
			if (hook.lp.LoanLandingPage_UploadDocuments_gridViewButton.isDisplayed()) {
				JavascriptExecutor js = (JavascriptExecutor) hook.driver;
				js.executeScript("arguments[0].click();", hook.lp.LoanLandingPage_UploadDocuments_gridViewButton);
				loginfo.log(Status.PASS, "Clicked on Grid view icon");
			}
		} catch (AssertionError e) {
			fname = hook.cm.addScreenshot(testContext);
			loginfo.log(Status.FAIL, "Grid view icok is not available to click " + e.getMessage());
			loginfo.addScreenCaptureFromPath(fname);

		}

	}

	@Then("Verify documents displayed in \"(.*)\" order as per document name header")
	public void Verify_documents_in_ascending_and_descending_sorted_order(String order) throws Exception {
		ExtentTest loginfo = null;
		try {
			loginfo = test.createNode(new GherkinKeyword("Then"),
					"Verify documents in ascending and descending sorted order");
			hook.wait.until(ExpectedConditions.visibilityOf(hook.lp.LoanLandingPag_DocumentsTab_DocumentsHeader));
			String docOrderAttribute = hook.lp.LoanLandingPag_DocumentsTab_DocumentsHeader.getAttribute("aria-sort");
			String docsArray[] = new String[hook.lp.LoanLandingPag_DocumentsTab_ListOfDocsInTable.size() - 1];
			if (order.contains("ascending")) {
				if (docOrderAttribute.contains("ascending")) {
					loginfo.log(Status.PASS, "Document are diplaying in ascending order");
				} else {
					hook.lp.LoanLandingPag_DocumentsTab_HeaderDocName.click();
					loginfo.log(Status.PASS, "Document are diplaying in ascending order");
				}
				for (int i = 1; i < hook.lp.LoanLandingPag_DocumentsTab_ListOfDocsInTable.size(); i++) {
					docsArray[i - 1] = hook.driver
							.findElement(By.xpath("//table[@matsortactive='docName']/tbody/tr[" + i + "]/td[2]"))
							.getText();
				}
				Arrays.sort(docsArray);
			} else {
				if (docOrderAttribute.contains("descending")) {
					loginfo.log(Status.PASS, "Document are diplaying in descending order");
				} else {
					hook.lp.LoanLandingPag_DocumentsTab_HeaderDocName.click();
					loginfo.log(Status.PASS, "Document are diplaying in ascending order");
				}
				hook.actions.pause(2000).build().perform();
				for (int i = 1; i < hook.lp.LoanLandingPag_DocumentsTab_ListOfDocsInTable.size(); i++) {
					docsArray[i - 1] = hook.driver
							.findElement(By.xpath("//table[@matsortactive='docName']/tbody/tr[" + i + "]/td[2]"))
							.getText();
				}
				Arrays.sort(docsArray, Collections.reverseOrder());
			}
			int k = 0;
			for (int j = 0; j < docsArray.length; j++) {
				k = j + 1;
				String tableValues = hook.driver
						.findElement(By.xpath("//table[@matsortactive='docName']/tbody/tr[" + k + "]/td[2]")).getText()
						.trim();
				String sortedTableValue = docsArray[j].trim();
				if (tableValues.equalsIgnoreCase(sortedTableValue)) {
					loginfo.log(Status.PASS,
							j + "th document" + tableValues + "  is correctly displaying in " + order + " Order");
				} else {
					loginfo.log(Status.FAIL, j + "th document" + tableValues + " is not matching: " + "Table Value :"
							+ tableValues + " :: " + sortedTableValue);
				}
			}

		} catch (AssertionError e) {
			fname = hook.cm.addScreenshot(testContext);
			loginfo.log(Status.FAIL, "Verify documents in ascending and descending sorted order " + e.getMessage());
			loginfo.addScreenCaptureFromPath(fname);

		}
	}

	@Then("Verify documents displayed in \"(.*)\" order as per last opened header$")
	public void Verify_documents_in_ascending_and_descending_sorted_order_as_per_lastOpened(String order)
			throws Exception {
		ExtentTest loginfo = null;
		try {
			loginfo = test.createNode(new GherkinKeyword("Then"),
					"Verify documents in ascending and descending sorted order as per last opened");
			hook.wait.until(ExpectedConditions.visibilityOf(hook.lp.LoanLandingPag_DocumentsTab_DocumentsHeader));
			String docOrderAttribute = hook.lp.LoanLandingPag_DocumentsTab_LastOpenedHeader.getAttribute("aria-sort");
			String docsArray[] = new String[hook.lp.LoanLandingPag_DocumentsTab_ListOfDocsInTable.size() - 1];
			if (order.contains("ascending")) {
				if (docOrderAttribute.contains("ascending")) {
					loginfo.log(Status.PASS, "Document are diplaying in ascending order");
				} else {
					hook.lp.LoanLandingPag_DocumentsTab_HeaderLastOpened.click();
					loginfo.log(Status.PASS, "Document are diplaying in ascending order");
				}
				hook.actions.pause(2000).build().perform();
				for (int i = 1; i < hook.lp.LoanLandingPag_DocumentsTab_ListOfDocsInTable.size(); i++) {
					docsArray[i - 1] = hook.driver
							.findElement(By.xpath("//table[@matsortactive='docName']/tbody/tr[" + i + "]/td[3]"))
							.getText();
				}
				Arrays.sort(docsArray);
			} else {
				if (docOrderAttribute.contains("descending")) {
					loginfo.log(Status.PASS, "Document are diplaying in descending order");
				} else {
					hook.lp.LoanLandingPag_DocumentsTab_HeaderLastOpened.click();
					loginfo.log(Status.PASS, "Document are diplaying in ascending order");
				}
				hook.actions.pause(2000).build().perform();
				for (int i = 1; i < hook.lp.LoanLandingPag_DocumentsTab_ListOfDocsInTable.size(); i++) {
					docsArray[i - 1] = hook.driver
							.findElement(By.xpath("//table[@matsortactive='docName']/tbody/tr[" + i + "]/td[3]"))
							.getText();
				}
				Arrays.sort(docsArray, Collections.reverseOrder());
			}
			int k = 0;
			for (int j = 0; j < docsArray.length; j++) {
				k = j + 1;
				String tableValues = hook.driver
						.findElement(By.xpath("//table[@matsortactive='docName']/tbody/tr[" + k + "]/td[3]")).getText()
						.trim();
				String sortedTableValue = docsArray[j].trim();
				if (tableValues.equalsIgnoreCase(sortedTableValue)) {
					loginfo.log(Status.PASS, j + "th document" + tableValues
							+ "  opened time is correctly displaying in " + order + " Order");
				} else {
					loginfo.log(Status.FAIL, j + "th document" + tableValues + " opened time is not matching: "
							+ "Table Value :" + tableValues + " :: " + sortedTableValue);
				}
			}

		} catch (AssertionError e) {
			fname = hook.cm.addScreenshot(testContext);
			loginfo.log(Status.FAIL, "Verify documents in ascending and descending sorted order " + e.getMessage());
			loginfo.addScreenCaptureFromPath(fname);

		}
	}

	@Then("Click on SortBy button to select \"(.*)\" as sorting option and then verify sorting order$")
	public void click_on_SortBy_button_to_select_sorting_option_and_ThenVerify_sortingOrder(String documentsOrder)
			throws Exception {
		ExtentTest loginfo = null;
		try {
			loginfo = test.createNode(new GherkinKeyword("Then"),
					"Click on SortBy button to select "+documentsOrder+" as sorting option and then verify sorting order");
			hook.wait.until(ExpectedConditions.visibilityOf(hook.lp.LoanLandingPage_UploadDocuments_GridViewButtonSortByButton));
			hook.lp.LoanLandingPage_UploadDocuments_GridViewButtonSortByButton.click();
			hook.actions.pause(3000).build().perform();
			hook.driver.findElement(By.xpath("//span[contains(text(),'"+documentsOrder+"')]")).click();			
			hook.actions.pause(2000).build().perform();
			String docsArray[] = new String[hook.lp.LoanLandingPage_Uploaded_PDFDocumentsInGridView.size()];

			for (int i = 0; i < hook.lp.LoanLandingPage_Uploaded_PDFDocumentsInGridView.size(); i++) {
				docsArray[i] = hook.lp.LoanLandingPage_Uploaded_PDFDocumentsInGridView.get(i).getText();
			}
			Arrays.sort(docsArray);
			hook.actions.pause(2000).build().perform();			
			for (int j = 0; j < docsArray.length; j++) {
				String tableValues = hook.lp.LoanLandingPage_Uploaded_PDFDocumentsInGridView.get(j).getText();
				String sortedTableValue = docsArray[j].trim();
				if (tableValues.equalsIgnoreCase(sortedTableValue)) {
					loginfo.log(Status.PASS, j + "th document" + tableValues
							+ "  is correctly displaying as per " + documentsOrder + " Order");
				} else {
					loginfo.log(Status.FAIL, j + "th document" + tableValues
							+ "  is not displaying correctly as per " + documentsOrder + " Order");
				}
			}

		} catch (AssertionError e) {
			fname = hook.cm.addScreenshot(testContext);
			loginfo.log(Status.FAIL, "Docuements are not displaying as per "+documentsOrder+ ": " + e.getMessage());
			loginfo.addScreenCaptureFromPath(fname);

		}
	}

	@Then("^Check ckeckboxes availability and select \"(.*)\" check boxes to verify Delete button$")
	public void check_ckeckbox_availability_and_select_and_deselect_check_box_to_verify_Delete_button(
			String numberOfCheckBoxesToSelect) throws Exception {
		ExtentTest loginfo = null;
		try {
			loginfo = test.createNode(new GherkinKeyword("Then"), "Check ckeckboxes availability and select "
					+ numberOfCheckBoxesToSelect + " check boxes to verify Delete button");
			hook.wait.until(ExpectedConditions.visibilityOf(hook.lp.LoanLandingPage_UploadDocuments_button));
			String attributeVal = hook.lp.LoanLandingPag_DocumentsTab_ListCheckBoxesInListView.get(0)
					.getAttribute("class");
			if (hook.lp.LoanLandingPag_DocumentsTab_ListCheckBoxesInListView.size() > 0
					& (!attributeVal.contains("checked"))) {
				loginfo.log(Status.INFO, "Checkbox is available in a table");
				for (int i = 0; i < Integer.parseInt(numberOfCheckBoxesToSelect); i++) {
					hook.lp.LoanLandingPag_DocumentsTab_ListCheckBoxesInListView.get(i).click();
				}
				attributeVal = hook.lp.LoanLandingPag_DocumentsTab_ListCheckBoxesInListView.get(0)
						.getAttribute("class");
				if (attributeVal.contains("checked")) {
					loginfo.log(Status.PASS, "Clicked on ckeckbox to verify availability of Delete button");
				} else {
					loginfo.log(Status.FAIL,
							"Clicked on ckeckbox to verify un availability of Delete button but Delete button in not available");
				}
			}
		} catch (Exception e) {
			fname = hook.cm.addScreenshot(testContext);
			loginfo.log(Status.FAIL, "Verify documents in ascending and descending sorted order " + e.getMessage());
			loginfo.addScreenCaptureFromPath(fname);
		}
	}

	@Then("^Deselect \"(.*)\" checkboxes to verify Delete button unavailability$")
	public void Deselect_check_box_to_verify_Delete_button_to_be_disabled(String numberOfCheckBoxesTodeSelect)
			throws Exception {
		ExtentTest loginfo = null;
		try {
			loginfo = test.createNode(new GherkinKeyword("Then"),
					"Deselect " + numberOfCheckBoxesTodeSelect + " checkboxes to verify Delete button unavailability");
			hook.actions.pause(3000).build().perform();
			String attributeVal = hook.lp.LoanLandingPag_DocumentsTab_ListCheckBoxesInListView.get(0)
					.getAttribute("class");
			if (hook.lp.LoanLandingPag_DocumentsTab_ListCheckBoxesInListView.size() > 0
					& (attributeVal.contains("checked"))) {
				loginfo.log(Status.INFO, "Checkbox is available in a table");
				for (int i = 0; i < Integer.parseInt(numberOfCheckBoxesTodeSelect); i++) {
					hook.lp.LoanLandingPag_DocumentsTab_ListCheckBoxesInListView.get(i).click();
				}
				hook.actions.pause(2000).build().perform();
				attributeVal = hook.lp.LoanLandingPag_DocumentsTab_ListCheckBoxesInListView.get(0).getAttribute("id");
				if (attributeVal.contains("mat-checkbox-2")
						& hook.driver.findElements(By.xpath("//span[contains(text(),'delete')]")).size() == 0) {
					loginfo.log(Status.PASS,
							"Clicked on ckeckbox to Uncheck checkbox to verify un availability of Delete button and button not available");
				} else {
					loginfo.log(Status.FAIL,
							"Clicked on ckeckbox to Uncheck checkbox to verify un availability of Delete button and button available");
				}
			}
		} catch (Exception e) {
			fname = hook.cm.addScreenshot(testContext);
			loginfo.log(Status.FAIL,
					"Clicked on ckeckbox to verify un availability of Delete button but Delete button in not available "
							+ e.getMessage());
			loginfo.addScreenCaptureFromPath(fname);

		}
	}
	
}
