package com.bki.ot.uwa.automation.extentreport;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;
import java.sql.Timestamp;

public class ExtentReportConfig {

	public static ExtentHtmlReporter report;
	public static ExtentReports extent;
	public static ExtentTest test;

	public static ExtentReports extentRepotSetup() {
		String timestamp = new Timestamp(System.currentTimeMillis()).toString();
		// remove the seconds part
		timestamp = timestamp.substring(0, timestamp.length() - 6).replaceAll(":", "");
		if (extent != null)
			return extent;
		report = new ExtentHtmlReporter("src/test/resources/output/extentreport/ExtentReport" + timestamp + ".html");
		report.config().setDocumentTitle("Underwriting Assist");
		report.config().setReportName("Underwriting Assist");
		report.config().setTheme(Theme.DARK);
		report.config().setTimeStampFormat("MMM dd, yyyy HH:mm:ss");
		report.config().enableTimeline(true);
		report.start();
		extent = new ExtentReports();

		extent.attachReporter(report);
		return extent;
	}

}
