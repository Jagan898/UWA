package com.bki.ot.uwa.automation.extentreport;

import java.util.Properties;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.mail.BodyPart;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;


public class SendEmailReport extends ExtentReportConfig{
	public void sendEmail() {
		String[] tos= {"Janell.Ellison@bkfs.com","Leela.Rani.Kudipudi@bkfs.com","Sanjeev.Pulakurthi@bkfs.com","RanjithKumar.G@bkfs.com","John.Kondajutur@bkfs.com","Dharma.Kovvuri@bkfs.com"};
		String from= "Leela.Rani.Kudipudi@bkfs.com";
		String host = "10.49.67.151";
		Properties properties=System.getProperties();
		properties.setProperty("mail.smtp.host", host);
	    Session session = Session.getDefaultInstance(properties);
		
		try {
			for(String to: tos) {
			MimeMessage message=new MimeMessage(session);
			message.setFrom(new InternetAddress(from));
			message.addRecipient(Message.RecipientType.TO,new InternetAddress(to));
			String subject=report.getFilePath();
			String[] reportPath=subject.split("/");
			String reportName=reportPath[reportPath.length-1];
			message.setSubject("UWA Automation Report");
			BodyPart messageBodyPart= new MimeBodyPart();
            messageBodyPart.setText("UWA Automation Report");

             Multipart multipart = new MimeMultipart();


             // Set text message part
             multipart.addBodyPart(messageBodyPart);


             // Part two is attachment
             messageBodyPart = new MimeBodyPart();
             String filename=report.getFilePath();
			DataSource source=new FileDataSource(filename);
			messageBodyPart.setDataHandler(new DataHandler(source));
            messageBodyPart.setFileName(reportName);
            multipart.addBodyPart(messageBodyPart);
            message.setContent(multipart );
            Transport.send(message);
            System.out.println("Sent message successfully....");	
			} 
		}catch(MessagingException e) {
			e.printStackTrace();
		}
		
		
		
		
	}
	
}
