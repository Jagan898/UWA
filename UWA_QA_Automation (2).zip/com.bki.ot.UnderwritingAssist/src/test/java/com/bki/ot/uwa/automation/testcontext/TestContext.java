package com.bki.ot.uwa.automation.testcontext;

import com.bki.ot.uwa.automation.baseconfig.BaseConfig;
import com.bki.ot.uwa.automation.pageobjectmanager.PageObjectManager;

public class TestContext {

	private PageObjectManager pageObjectManager;
	private BaseConfig baseConfig;

	public TestContext() {
		baseConfig = new BaseConfig();
		pageObjectManager = new PageObjectManager(baseConfig.getDriver());
	}

	public BaseConfig getBaseConfigInstance() {
		return baseConfig;
	}

	public PageObjectManager getPageObjectManagerInstance() {
		return pageObjectManager;
	}
}

