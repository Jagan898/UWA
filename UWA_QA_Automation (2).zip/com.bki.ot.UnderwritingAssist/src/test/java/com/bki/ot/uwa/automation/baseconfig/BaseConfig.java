package com.bki.ot.uwa.automation.baseconfig;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.ie.InternetExplorerOptions;
import com.bki.ot.uwa.automation.filereadermanager.FileReaderManager;
import io.github.bonigarcia.wdm.WebDriverManager;

public class BaseConfig {
	private WebDriver driver = null;
	String driverPath = null;

	public BaseConfig() {
		driverPath = FileReaderManager.getFileReaderManagerInstance().getConfigInstance().getDriverPath();
	}

	public WebDriver getDriver() {
		if (driver == null) {
			driver = Initialization();
		}
		return driver;

	}

	private WebDriver Initialization() {
		String browserType = System.getProperty("browserType");
		if ("chrome".equalsIgnoreCase(browserType)) {
			try {
//				Runtime.getRuntime().exec("taskkill /F /IM chrome.exe");
//				Thread.sleep(3000);
				WebDriverManager.chromedriver().setup();
				ChromeOptions chrome = new ChromeOptions();
				chrome.addArguments("--disable-infobars");
				String chromeOptionsArg = System.getProperty("chromeOptionsArg");
				if ("--headless".equalsIgnoreCase(chromeOptionsArg)) {
					chrome.addArguments("--headless");
					chrome.addArguments("window-size=1600x900");

				}
				driver = new ChromeDriver(chrome);
			} catch (Exception e) {
				e.printStackTrace();
			}
		} else if ("ie".equalsIgnoreCase(browserType)) {
			try {
//				Runtime.getRuntime().exec("taskkill /F /IM iexplore.exe");
//				Thread.sleep(3000);
				WebDriverManager.iedriver().setup();
				InternetExplorerOptions options = new InternetExplorerOptions();
				options.setCapability("nativeEvents", false);
				options.setCapability("unexpectedAlertBehaviour", "accept");
				options.setCapability("ignoreZoomSetting", true);
				options.setCapability("disable-popup-blocking", true);
				options.setCapability("requiredWindowFocus", true);
				driver = new InternetExplorerDriver(options);

			} catch (Exception e) {
				e.printStackTrace();
			}
		} else if ("edge".equalsIgnoreCase(browserType)) {
			try {
//				Runtime.getRuntime().exec("taskkill /F /IM msedge.exe");
//				Thread.sleep(3000);
				System.setProperty("webdriver.edge.driver", driverPath);
				EdgeOptions options = new EdgeOptions();
				driver = new EdgeDriver(options);
			} catch (Exception e) {
				e.printStackTrace();
			}
		} else {
			throw new RuntimeException("Browser name is not specified ");
		}
		return driver;
	}

}
