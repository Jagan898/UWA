package com.bki.ot.uwa.automation.stepdefinitions;

import java.io.File;
import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import java.util.function.Function;
import java.util.logging.Level;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.logging.LogType;
import org.openqa.selenium.logging.LoggingPreferences;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;
import org.testng.Assert;
import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.GherkinKeyword;
import com.aventstack.extentreports.Status;
import com.bki.ot.uwa.automation.extentreport.ExtentReportConfig;
import com.bki.ot.uwa.automation.filereadermanager.FileReaderManager;
import com.bki.ot.uwa.automation.testcontext.TestContext;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class IncomeVerificationStepDef extends ExtentReportConfig {

	Hooks hook;
	TestContext testContext;
	String url = null;
	public static String fname;
	Boolean iselementpresent1 = false;
	public static int p=0;

	public IncomeVerificationStepDef(TestContext context) {
		testContext = context;
		hook = new Hooks(context);
		url = FileReaderManager.getFileReaderManagerInstance().getConfigInstance().getUrl();

	}

	@Then("^Verify Borrower details in application against \"(.*)\" as input MISMO file$")
	public void validate_Borrower_Details(String mismoFile) throws Exception {
		ExtentTest loginfo = null;
		try {
			loginfo = test.createNode(new GherkinKeyword("Then"), "Verify loan details from " + mismoFile);
			DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
			DocumentBuilder builder = null;
			builder = factory.newDocumentBuilder();
			String xmlFilePath = System.getProperty("user.dir") + "/src/test/resources/files/" + mismoFile;
			Document doc = builder.parse(new File(xmlFilePath));
			doc.getDocumentElement().normalize();
			Element rootElement = doc.getDocumentElement();
			String xpath = "//INDIVIDUAL";
			XPath xPath = XPathFactory.newInstance().newXPath();
			NodeList nodeList = (NodeList) xPath.compile(xpath).evaluate(doc, XPathConstants.NODESET);
			System.out.println(nodeList.getLength());
			List<String> listOfBorrowersInMISMO = new ArrayList<String>();
			for (int l = 0; l < nodeList.getLength(); l++) {
				Node nNode = nodeList.item(l);
				if (nNode.getNodeType() == Node.ELEMENT_NODE) {
					Element eElement = (Element) nNode;
					try {
						String firstName = eElement.getElementsByTagName("FirstName").item(0).getTextContent();
						String lastName = eElement.getElementsByTagName("LastName").item(0).getTextContent();
						String borrowerName = lastName + ", " + firstName;
						System.out.println("Node value from XML :" + borrowerName);
						loginfo.log(Status.INFO, lastName + ", " + firstName
								+ " Employer is populated in Income Verification page as per MISMO file");
						if (!listOfBorrowersInMISMO.contains(borrowerName)) {
							listOfBorrowersInMISMO.add(borrowerName);
						}
					} catch (Exception e) {
						// TODO Auto-generated catch block
						System.out.println(e.getMessage());
					}
				}
			}
			List<WebElement> borrowers = hook.driver
					.findElements(By.xpath("//table/tbody/tr/td[contains(text(),'Borrower')]"));
			List<String> listOfUIBorrowers = new ArrayList<String>();
			for (int i = 0; i < borrowers.size(); i++) {
				if (!listOfUIBorrowers.contains(borrowers.get(i).getText())) {
					listOfUIBorrowers.add(borrowers.get(i).getText());
				}
			}
			for (int m = 0; m < listOfUIBorrowers.size(); m++) {
				if (listOfUIBorrowers.get(m).contains(listOfBorrowersInMISMO.get(m))) {
					loginfo.log(Status.PASS,
							borrowers.get(m).getText() + " is displayed in application as per the XML data");
				} else {
					loginfo.log(Status.FAIL,
							borrowers.get(m).getText() + " is not displayed in application as per the XML data");
				}
			}

		} catch (Exception e) {
			fname = hook.cm.addScreenshot(testContext);
			loginfo.log(Status.FAIL, e.getMessage());
			loginfo.addScreenCaptureFromPath(fname);
		}

	}

	@And("^Verify all the document preview links in Income Verification tab$")
	public void VerifyallthedocumentpreviewlinksinIncomeVerificationtab() throws Exception {
		ExtentTest loginfo = null;
		try {
			loginfo = test.createNode(new GherkinKeyword("And"), "Column headers displayed in Income Information Tab");
			int temp = 0;
			int k = 1;
			if (hook.lp.IncomeInformationTab_DropdownArrowsRowCount.size() != 0) {
				for (int i = 1; i <= hook.lp.IncomeInformationTab_DropdownArrowsRowCount.size(); i++) {
					hook.driver
							.findElement(By.xpath(
									"(//tbody[@role='rowgroup']//td[8]//span[@class='mat-button-wrapper'])[" + i + "]"))
							.click();
					temp = temp + 2;
					int count = hook.driver.findElements(By.xpath(
							"//tbody[@role='rowgroup']//tr[" + temp + "]//div[4]//span[@class='ng-star-inserted']"))
							.size();
					for (int j = 1; j <= count; j++) {
						hook.actions.pause(2000).build().perform();
						hook.driver.findElement(By.xpath("(//tbody[@role='rowgroup']//tr[" + temp
								+ "]//div[4]//span[@class='ng-star-inserted'])[" + j + "]")).click();
						hook.actions.pause(5000).build().perform();
						hook.driver.findElement(By.xpath("(//span[contains(text(),'View Document')])[" + k + "]"))
								.click();
						k = k + 1;
						if (hook.driver.findElements(By.xpath("//span[contains(text(),'2020 W2')]")).size() != 0) {
							hook.driver.findElement(By.xpath("//span[contains(text(),'2020 W2')]")).click();
						}
						ArrayList<String> wins = new ArrayList<String>(hook.driver.getWindowHandles());
						loginfo.log(Status.INFO, "Number of Tabs Opened : " + wins.size());
						hook.actions.pause(5000).build().perform();
						hook.driver.switchTo().window(wins.get(1));
						loginfo.log(Status.INFO, "Child Window : " + hook.driver.getTitle());
						Boolean iselementpresent1 = hook.driver.findElements(By.xpath(
								"//div[contains(text(),'WVOE') or contains(text(),'PAY STUB') or contains(text(),'2020 W2')]"))
								.size() != 0;
						if (iselementpresent1) {
							hook.actions.pause(3000).build().perform();
							hook.driver.close();
						}
						hook.driver.switchTo().window(wins.get(0));
						if (hook.driver.findElements(By.xpath("//span[contains(text(),'CLOSE')]")).size() != 0) {
							hook.driver.findElement(By.xpath("//span[contains(text(),'CLOSE')]")).click();
						}
						hook.driver.findElement(By.xpath("(//*[name()='svg' and @data-icon='minus'])[1]")).click();
						hook.actions.pause(5000).build().perform();
						loginfo.log(Status.PASS, "Main Window : " + hook.driver.getTitle());
					}
				}
			}

		} catch (Exception e) {
			fname = hook.cm.addScreenshot(testContext);
			loginfo.log(Status.FAIL, e.getMessage());
			loginfo.addScreenCaptureFromPath(fname);
		}
	}

	@And("^verify that Documents Tab is in Grid View$")
	public void verifythatDocumentsTabisinGridView() throws Exception {
		ExtentTest loginfo = null;
		try {
			loginfo = test.createNode(new GherkinKeyword("And"), "Document Tab is dispalyed in Grid View");
			hook.wait.until(ExpectedConditions.visibilityOf(hook.lp.LoanLandingPage_DocumentsTab_GridView));
			// Assert.assertTrue(hook.lp.LoanLandingPage_DocumentsTab_GridView.isDisplayed());
			hook.lp.LoanLandingPage_DocumentsTab_GridView.click();
			Wait<WebDriver> wait = new FluentWait<WebDriver>(hook.driver)
				       .withTimeout(30, TimeUnit.SECONDS)
				       .pollingEvery(5, TimeUnit.SECONDS)
				       .ignoring(NoSuchElementException.class);

				   WebElement foo = wait.until(new Function<WebDriver, WebElement>() {
				     public WebElement apply(WebDriver driver) {
				       return hook.lp.LoanLandingPage_DocumentsTab_GridView;
				     }
				   });
			
			String attributeVal = hook.lp.LoanLandingPage_DocumentsTab_GridView.getAttribute("class");
			if (attributeVal.contains("btn thumbnail__grid active"))
				loginfo.log(Status.PASS, "Documents are dispalyed in Grid View:");
			else
				loginfo.log(Status.FAIL, "Documents are not dispalyed in Grid View:");
		} catch (Exception e) {
			fname = hook.cm.addScreenshot(testContext);
			loginfo.log(Status.FAIL, e.getMessage());
			loginfo.addScreenCaptureFromPath(fname);
		}
	}

	@And("^I click on the Document Link$")
	public void clickontheDocumentLink() throws Exception {
		ExtentTest loginfo = null;
		try {
			loginfo = test.createNode(new GherkinKeyword("And"), "Click on Document Link");
			hook.wait.until(ExpectedConditions.visibilityOf(hook.lp.LoanLandingPage_DocumentsTab_DocumentLink));
			hook.lp.LoanLandingPage_DocumentsTab_DocumentLink.click();
			ArrayList<String> wins = new ArrayList<String>(hook.driver.getWindowHandles());
			loginfo.log(Status.INFO, "Number of Tabs Opened : " + wins.size());
			hook.actions.pause(5000).build().perform();
			hook.driver.switchTo().window(wins.get(2));
			hook.actions.pause(5000).build().perform();
			loginfo.log(Status.INFO, "Child Window : " + hook.driver.getTitle());
			iselementpresent1 = hook.driver.findElements(By.xpath("//div[contains(text(),'WVOE')]")).size() != 0;
			if (iselementpresent1) {
				hook.driver.close();
				hook.actions.pause(5000).build().perform();
			}
			hook.driver.switchTo().window(wins.get(1));
			hook.driver.close();
			loginfo.log(Status.PASS, "I clicked on Document Link :");
		} catch (Exception e) {
			fname = hook.cm.addScreenshot(testContext);
			loginfo.log(Status.FAIL, e.getMessage());
			loginfo.addScreenCaptureFromPath(fname);
		}
	}

	@And("^I verify that document is opened in new tab$")
	public void verifythatdocumentisopenedinnewtab() throws Exception {
		ExtentTest loginfo = null;
		try {
			loginfo = test.createNode(new GherkinKeyword("And"), "Verify Document is Opened in New tab");
			if (iselementpresent1) {
				loginfo.log(Status.PASS, "Document Opened in New tab :");
			}else {
				loginfo.log(Status.FAIL, "Document not Opened in New tab :");
			}
		} catch (Exception e) {
			fname = hook.cm.addScreenshot(testContext);
			loginfo.log(Status.FAIL, e.getMessage());
			loginfo.addScreenCaptureFromPath(fname);
		}
	}

	@Then("^Verify Employer details in application against \"(.*)\" as input MISMO file$")
	public void Verify_Borrower_details_in_application_with_the_help_of_MISMO_file(String mismoFile) throws Exception {
		ExtentTest loginfo = null;
		try {
			loginfo = test.createNode(new GherkinKeyword("Then"), "Verify loan details from " + mismoFile);
			DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
			List<String> borrowers = new ArrayList<String>();
			DocumentBuilder builder = null;
			builder = factory.newDocumentBuilder();
			String xmlFilePath = System.getProperty("user.dir") + "/src/test/resources/files/" + mismoFile;
			Document doc = builder.parse(new File(xmlFilePath));
			doc.getDocumentElement().normalize();
			Element rootElement = doc.getDocumentElement();
			NodeList node = rootElement.getElementsByTagName("ROLE");

			List<WebElement> employerNames = hook.driver.findElements(By.xpath("//table/tbody/tr/td[2]"));
			List<String> employersFromXML = new ArrayList<String>();
			String xpath = "//LEGAL_ENTITY_DETAIL";
			XPath xPath = XPathFactory.newInstance().newXPath();
			NodeList nodeList = (NodeList) xPath.compile(xpath).evaluate(doc, XPathConstants.NODESET);
			System.out.println(nodeList.getLength());

			for (int l = 0; l < nodeList.getLength(); l++) {
				Node nNode = nodeList.item(l);
				if (nNode.getNodeType() == Node.ELEMENT_NODE) {
					Element eElement = (Element) nNode;
					String nodeVal = eElement.getElementsByTagName("FullName").item(0).getTextContent();
					System.out.println("Node value from XML :" + nodeVal);
					loginfo.log(Status.INFO,
							nodeVal + " Employer is populated in Income Verification page as per MISMO file");
					employersFromXML.add(nodeVal);
				}
			}

			for (int m = 0; m < employerNames.size(); m++) {
				if (employersFromXML.contains(employerNames.get(m).getText())) {
					loginfo.log(Status.PASS,
							employerNames.get(m).getText() + " is displayed in application as per the XML data");
				} else {
					loginfo.log(Status.FAIL,
							employerNames.get(m).getText() + " is not displayed in application as per the XML data");
				}
			}

		} catch (Exception e) {
			fname = hook.cm.addScreenshot(testContext);
			loginfo.log(Status.FAIL, e.getMessage());
			loginfo.addScreenCaptureFromPath(fname);
		}
	}

	@Then("^Verify Weather \"(.*)\" with \"(.*)\" employer contains W2 as qualified income$")
	public void verifyBorrower_with_Employer_Details_of_QualifiedIncome(String borrower, String employer)
			throws Exception {
		ExtentTest loginfo = null;
		try {
			loginfo = test.createNode(new GherkinKeyword("Then"),
					"Verify Weather " + borrower + " with " + employer + " employer contains W2 as qualified income");
			String qualifiedIncomeColor = hook.driver
					.findElement(By.xpath("//table/tbody/tr/td[contains(text(),'" + borrower
							+ "')]/parent::tr/td[contains(text(),'" + employer + "')]/parent::tr/td[5]/div/a"))
					.getCssValue("color");
			System.out.println(qualifiedIncomeColor);
			// CSS value rgba(0, 138, 39, 1) specifies green color
			if (qualifiedIncomeColor.contains("rgba(0, 138, 39, 1)")) {
				loginfo.log(Status.PASS, borrower + " with " + employer + " employer contains W@ as qualified income");
			}
		} catch (Exception e) {
			fname = hook.cm.addScreenshot(testContext);
			loginfo.log(Status.FAIL, e.getMessage());
			loginfo.addScreenCaptureFromPath(fname);
		}
	}

	@Then("^Verify W2 alone contains income value as \"(.*)\" and become qualified income$")
	public void Verify_W2_alone_contains_income_value_and_become_qualified_income(String incomeValue) throws Exception {
		ExtentTest loginfo = null;
		try {
			loginfo = test.createNode(new GherkinKeyword("Then"),
					"Verify W2 alone contains income value and become qualified income");
			for (int i = 0; i < hook.iv.IncomeInformationTab_ListOfColumnsInIncoVerificationtable.size(); i++) {
				String w2 = hook.driver.findElements(By.xpath("//table/tbody/tr/td[5]")).get(i).getText();
				String wpayStub = hook.driver.findElements(By.xpath("//table/tbody/tr/td[6]")).get(i).getText();
				String wvoe = hook.driver.findElements(By.xpath("//table/tbody/tr/td[4]")).get(i).getText();
				if ((wpayStub.contains("--") & wvoe.contains("--")) & (!w2.contains("--"))) {
					String w2HightlightedColor = hook.driver.findElements(By.xpath("//table/tbody/tr/td[5]/div/a"))
							.get(i).getCssValue("color");
					String UIincomeValue = hook.driver.findElements(By.xpath("//table/tbody/tr/td[5]/div/a")).get(i)
							.getText();
					// CSS value rgba(0, 138, 39, 1) specifies green color
					if (w2HightlightedColor.contains("rgba(0, 138, 39, 1)")
							& UIincomeValue.equalsIgnoreCase(incomeValue)) {
						loginfo.log(Status.PASS, " employer contains W2 as qualified income");
					}
				}
			}

		} catch (Exception e) {
			fname = hook.cm.addScreenshot(testContext);
			loginfo.log(Status.FAIL, e.getMessage());
			loginfo.addScreenCaptureFromPath(fname);
		}
	}

	@Then("^Verify W2 prior 2 year monthly pay \"(.*)\" and \"(.*)\" and verify displayed amount should be avg of 2 years income$")
	public void getW2_2Year_PriorMonthly(String firstYearIncome, String secondYearIncome) throws Exception {
		ExtentTest loginfo = null;
		try {
			loginfo = test.createNode(new GherkinKeyword("Then"),
					"Verify W2 prior 2 year monthly pay " + firstYearIncome + " and " + secondYearIncome
							+ " and verify displayed amount should be avg of 2 years income");
			LoggingPreferences logPrefs = new LoggingPreferences();
			logPrefs.enable(LogType.PERFORMANCE, Level.ALL);
			double expAvgeAmount = (Integer.parseInt(firstYearIncome) + Integer.parseInt(secondYearIncome)) / 2;
			BigDecimal bd = new BigDecimal(expAvgeAmount);

			DecimalFormatSymbols symbols = DecimalFormatSymbols.getInstance();
			DecimalFormat formatter = new DecimalFormat("###,###.##", symbols);
			String expValue = formatter.format(bd.longValue());
			// DecimalFormat df = new DecimalFormat("0.00");
			// String expVal=df.format(expValue);
			String avgMonthlyAmount = hook.driver
					.findElement(By.xpath(
							"//table/tbody/tr/td[contains(text(),'Maple Glen Ice Cream')]/parent::tr/td[5]/div/a"))
					.getText();
			if (avgMonthlyAmount.contains(expValue)) {
				loginfo.log(Status.PASS, " Displayed average monthly income of 2 years correctly ");
			}

		} catch (Exception e) {
			fname = hook.cm.addScreenshot(testContext);
			loginfo.log(Status.FAIL, e.getMessage());
			loginfo.addScreenCaptureFromPath(fname);
		}
	}

	@Then("^Verify that \"(.*)\" and \"(.*)\" does not contains W2 income value and displayed \"(.*)\"$")
	public void verify_borrowerWithPretzelHeaven_W2Value(String borrower, String employer, String expectedVal)
			throws Exception {

		ExtentTest loginfo = null;
		try {
			loginfo = test.createNode(new GherkinKeyword("Then"),
					"Verify that " + borrower + " and " + employer + " does not contains W2 value and displayed - -");

			String actualW2Val = hook.driver
					.findElement(By.xpath("//table/tbody/tr/td[contains(text(),'" + borrower
							+ "')]/parent::tr/td[contains(text(),'" + employer + "')]/parent::tr/td[8]/button"))
					.getText();
			if (actualW2Val.contains(expectedVal)) {
				loginfo.log(Status.PASS,
						" Verified that employer Pretzel Heaven does not contain value and displayed --");
			}
		} catch (Exception e) {
			fname = hook.cm.addScreenshot(testContext);
			loginfo.log(Status.FAIL, e.getMessage());
			loginfo.addScreenCaptureFromPath(fname);
		}

	}

	@Then("^Verify that \"(.*)\" and \"(.*)\" does contain sum of Base \"(.*)\" and \"(.*)\" should display in PayStub$")
	public void verifying_payStub_with_SumOf_BasePayandOverTime(String borrower, String employer, String pay,
			String overtime) throws Exception {
		ExtentTest loginfo = null;
		try {
			loginfo = test.createNode(new GherkinKeyword("Then"), "Verify that " + borrower + " and " + employer
					+ " does contain sum of BasePay and Overtime should display in PayStub$");
			String actualsPaystub = hook.driver
					.findElement(By.xpath("//table/tbody/tr/td[contains(text(),'" + borrower
							+ "')]/parent::tr/td[contains(text(),'" + employer + "')]/parent::tr/td[6]/div/a"))
					.getText().trim().replace("$", "");
			System.out.println(actualsPaystub);
			loginfo.log(Status.INFO, "PayStub amount from UI :" + actualsPaystub);
			String actualPaystub = actualsPaystub.replace(",", "");
			float actualPayStubUI = Float.parseFloat(actualPaystub);
			hook.driver
					.findElement(By.xpath("//table/tbody/tr/td[contains(text(),'" + borrower
							+ "')]/parent::tr/td[contains(text(),'" + employer + "')]/parent::tr/td[8]/button"))
					.click();
			String basePay = hook.driver.findElement(By.xpath(
					"//div[contains(text(),'" + pay + "')]/parent::div/following-sibling::div/div[contains(text(),'"
							+ employer + "')]/parent::div/following-sibling::div/div"))
					.getText().trim().replace("$", "");
			basePay = basePay.replace(",", "");
			float basepayAmount = Float.parseFloat(basePay);
			loginfo.log(Status.INFO, "BasePay amount from UI :" + basepayAmount);
			String overTime = hook.driver.findElement(By.xpath("//div[contains(text(),'" + overtime
					+ "')]/parent::div/following-sibling::div/div[contains(text(),'" + employer
					+ "')]/parent::div/following-sibling::div/div")).getText().trim().replace("$", "");
			overTime = overTime.replace(",", "");
			float overtimeAmount = Float.parseFloat(overTime);
			loginfo.log(Status.INFO, "OverTime amount from UI :" + basepayAmount);
			float expectedPayStub = basepayAmount + overtimeAmount;
			if (actualPayStubUI == expectedPayStub) {
				loginfo.log(Status.PASS, "PayStub: " + actualsPaystub + " is displaying correctly with sum of "
						+ basePay + " and " + overTime + " amount");
			}

		} catch (Exception e) {
			fname = hook.cm.addScreenshot(testContext);
			loginfo.log(Status.FAIL, e.getMessage());
			loginfo.addScreenCaptureFromPath(fname);
		}
	}

	@Then("^Verify that \"(.*)\" and \"(.*)\" does contain sum of All type of Incomes under WVOE column$")
	public void verify_WVOEIncome_by_adding_allTypeOfIncomeAmounts(String borrower, String employer, DataTable incomes)
			throws Exception {

		ExtentTest loginfo = null;
		try {
			loginfo = test.createNode(new GherkinKeyword("Then"), "Verify that " + borrower + " and " + employer
					+ " does contain sum of All type of Incomes under WVOE column");

			String wvoeAmount = hook.driver
					.findElement(By.xpath("//table/tbody/tr/td[contains(text(),'" + borrower
							+ "')]/parent::tr/td[contains(text(),'" + employer + "')]/parent::tr/td[4]/div/a"))
					.getText().trim().replace("$", "");
			wvoeAmount = wvoeAmount.replace(",", "");
			hook.driver
					.findElement(By.xpath("//table/tbody/tr/td[contains(text(),'" + borrower
							+ "')]/parent::tr/td[contains(text(),'" + employer + "')]/parent::tr/td[8]/button"))
					.click();
			float wvoeAmountUI = Float.parseFloat(wvoeAmount);
			float sumOfMonthlyIncomes = 0;
			List<Map<String, String>> list = incomes.asMaps(String.class, String.class);
			for (Map<String, String> data : list) {
				Set<String> keys = data.keySet();
				Iterator<String> it = keys.iterator();
				while (it.hasNext()) {
					String key = it.next();
					String expectedMonthlyIncome = data.get(key);
					String actualMonthlyIncome = hook.driver.findElement(By.xpath("//div[contains(text(),'" + key
							+ "')]/parent::div/following-sibling::div/div[contains(text(),'" + employer
							+ "')]/parent::div/following-sibling::div/div")).getText().trim().replace("$", "");
					actualMonthlyIncome = actualMonthlyIncome.replace(",", "");
					if (expectedMonthlyIncome.contains(actualMonthlyIncome)) {
						loginfo.log(Status.PASS,
								actualMonthlyIncome + " is displaying correctly in application as per the input");
					}
					float monthlyIncomeUI = Float.parseFloat(actualMonthlyIncome);
					sumOfMonthlyIncomes = sumOfMonthlyIncomes + monthlyIncomeUI;
				}

			}
			if (wvoeAmountUI == sumOfMonthlyIncomes) {
				loginfo.log(Status.PASS,
						wvoeAmount + " is displaying correctly in application with sum of all monthly income "
								+ sumOfMonthlyIncomes);
			}

		} catch (Exception e) {
			fname = hook.cm.addScreenshot(testContext);
			loginfo.log(Status.FAIL, e.getMessage());
			loginfo.addScreenCaptureFromPath(fname);
		}
	}

	@Then("^Click on \"(.*)\" for \"(.*)\" with \"(.*)\" employer to verify displaying below all types of monthly incomes$")
	public void click_on_downAreow_Then_verfy_allTypes_of_IncomeLabels(String aerow, String borrower, String employer,
			DataTable incomesLabels) throws Exception {

		ExtentTest loginfo = null;
		try {
			loginfo = test.createNode(new GherkinKeyword("Then"), "Click on " + aerow + " for " + borrower + " with "
					+ employer + " employer to verify displaying below all types of monthly incomes");

			hook.driver
					.findElement(By.xpath("//table/tbody/tr/td[contains(text(),'" + borrower
							+ "')]/parent::tr/td[contains(text(),'" + employer + "')]/parent::tr/td[8]/button"))
					.click();
			List<String> labels = incomesLabels.asList(String.class);
			for (int i = 0; i < labels.size(); i++) {
				List<WebElement> monthlyIncomeLabel = hook.driver.findElements(By.xpath("//div[contains(text(),'"
						+ employer + "')]/parent::div/parent::div//div[contains(text(),'" + labels.get(i) + "')]"));
				if (monthlyIncomeLabel.size() == 1) {
					loginfo.log(Status.PASS, monthlyIncomeLabel + " is displaying correctly as " + labels.get(i)
							+ " in the application UI under " + borrower + " Borrower after clicking on Down aerow");
				} else {
					loginfo.log(Status.FAIL, monthlyIncomeLabel + " is not displaying correctly as " + labels.get(i)
							+ " in the application UI under " + borrower + " Borrower after clicking on Down aerow");
				}
			}

		} catch (Exception e) {
			fname = hook.cm.addScreenshot(testContext);
			loginfo.log(Status.FAIL, e.getMessage());
			loginfo.addScreenCaptureFromPath(fname);
		}
	}

	@Then("^Verify the borrower who is having Paystub is qualifying income and highlighted in green$")
	public void Verify_the_borrower_whois_having_Paystub_is_qualifying_income_and_highlighted_in_green()
			throws Exception {

		ExtentTest loginfo = null;
		try {
			loginfo = test.createNode(new GherkinKeyword("Then"),
					"Verify the borrower who is having Paystub is qualifying income and highlighted in green");

			int k = 0;
			for (int i = 0; i <= hook.iv.IncomeInformationTab_AvailableListOfBorrowers.size(); i += 2) {

				k = i + 1;
				String payStubValueColor = hook.driver.findElement(By.xpath("//table/tbody/tr[" + k + "]/td[6]/div/a"))
						.getCssValue("color");
				if (payStubValueColor.contains("rgba(0, 138, 39, 1)")) {
					String qualifiedPayStubAmount = hook.driver
							.findElement(By.xpath("//table/tbody/tr[" + k + "]/td[6]/div/a")).getText()
							.replace("$", "");
					qualifiedPayStubAmount = qualifiedPayStubAmount.replace(",", "");
					float qualifiedPayStubAmountUI = Float.parseFloat(qualifiedPayStubAmount);
					String qualifiedBorrowerNameforPayStub = hook.driver
							.findElement(By.xpath("//table/tbody/tr[" + k + "]/td[1]")).getText().trim();
					String qualifiedEmployerNameforPayStub = hook.driver
							.findElement(By.xpath("//table/tbody/tr[" + k + "]/td[2]")).getText().trim();
					loginfo.log(Status.PASS, qualifiedPayStubAmount + " is displayed in green so "
							+ qualifiedPayStubAmount + " is qualified income");
					loginfo.log(Status.INFO, qualifiedBorrowerNameforPayStub + " and " + qualifiedEmployerNameforPayStub
							+ "'s PayStub is qualified income");
					hook.driver.findElement(By.xpath("//table/tbody/tr[" + k + "]/td[8]/button")).click();
					String[] employerSplit = qualifiedEmployerNameforPayStub.split(" ");
					List<WebElement> listOfincomes = hook.driver
							.findElements(By.xpath("//table/tbody/tr/td//div[contains(text(),'" + employerSplit[1]
									+ "')]/ancestor::tr/td//mat-expansion-panel//div/div[3]/div"));
					List<WebElement> typeOfincomes = hook.driver
							.findElements(By.xpath("//table/tbody/tr/td//div[contains(text(),'" + employerSplit[1]
									+ "')]/ancestor::tr/td//mat-expansion-panel//div/div[1]/div"));
					float sumOfpayStubValueUI = 0;
					for (int j = 0; j < listOfincomes.size(); j++) {
						String myIncome = listOfincomes.get(j).getText().replace("$", "");
						String typeOfMonthlyIncome = typeOfincomes.get(j).getText();
						myIncome = myIncome.replace(",", "");
						float myIncomeUI = Float.parseFloat(myIncome);
						loginfo.log(Status.INFO, myIncome + " income amount is awailable for " + typeOfMonthlyIncome);
						sumOfpayStubValueUI = sumOfpayStubValueUI + myIncomeUI;
					}
					if (qualifiedPayStubAmountUI == sumOfpayStubValueUI) {
						loginfo.log(Status.PASS,
								qualifiedPayStubAmount + " is displayed with sum of all types of incomes");
						break;
					}

				}
			}

		} catch (Exception e) {
			fname = hook.cm.addScreenshot(testContext);
			loginfo.log(Status.FAIL, e.getMessage());
			loginfo.addScreenCaptureFromPath(fname);
		}

	}

	@Then("^Verify \"(.*)\" with \"(.*)\" employers income amount against \"(.*)\" as input MISMO file$")
	public void verify_borrowers_income_amount_as_per_the_miso_fil(String borrower, String employer, String mismoFile)
			throws Exception {
		ExtentTest loginfo = null;
		try {
			loginfo = test.createNode(new GherkinKeyword("Then"), "Verify " + borrower + " with " + employer
					+ " employers income amount against " + mismoFile + " as input MISMO file");
			String employerAtttributeVal = null;
			float totalMonthlyIncome = 0;
			List<String> listOfIncomeAmounts = new ArrayList<String>();
			DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
			List<String> borrowers = new ArrayList<String>();
			DocumentBuilder builder = null;
			builder = factory.newDocumentBuilder();
			String xmlFilePath = System.getProperty("user.dir") + "/src/test/resources/files/" + mismoFile;
			Document doc = builder.parse(new File(xmlFilePath));
			doc.getDocumentElement().normalize();
			// Element rootElement = doc.getDocumentElement();
			// NodeList node = rootElement.getElementsByTagName("ROLE");
			XPath xPathEmployer = XPathFactory.newInstance().newXPath();
			NamedNodeMap employerAttribute = null;
			// NodeList nodesName;
			try {

				XPathExpression expr = xPathEmployer
						.compile("//EMPLOYERS/EMPLOYER/LEGAL_ENTITY/LEGAL_ENTITY_DETAIL/FullName");
				// This XPATH is used to take employer name as per the request/feature file =
				// ABC's Electrical

				Object result = expr.evaluate(doc, XPathConstants.NODESET);
				NodeList nodes = (NodeList) result;
				// below xpath is used to take the employer ID=EMPLOYER_100
				XPathExpression employerExpr = xPathEmployer.compile("//EMPLOYERS/EMPLOYER");
				Object empResult = employerExpr.evaluate(doc, XPathConstants.NODESET);
				NodeList employerNodes = (NodeList) empResult;
				for (int i = 0; i < nodes.getLength(); i++) {
					System.out.println(nodes.item(i).getTextContent());
					String nodeVal = nodes.item(i).getTextContent();
					if (nodeVal.contains(employer)) {
						Node nNode = employerNodes.item(i);
						if (nNode.hasAttributes()) {
							Attr attr = (Attr) nNode.getAttributes().getNamedItem("xlink:label");
							if (attr != null) {
								employerAtttributeVal = attr.getValue();
								System.out.println(employerAtttributeVal);
								loginfo.log(Status.INFO, employerAtttributeVal + " is BORROWER ID for " + employer);
								// Below xpath is used for take relatioshipTO as per borrowerID(BORROWER_100)
								XPathExpression relationshipExpr = xPathEmployer
										.compile("//RELATIONSHIPS/RELATIONSHIP");
								Object relationshipResult = relationshipExpr.evaluate(doc, XPathConstants.NODESET);
								NodeList relationshipNodes = (NodeList) relationshipResult;
								for (int j = 0; j < relationshipNodes.getLength(); j++) {
									Node reltnnNode = relationshipNodes.item(j);
									if (reltnnNode.hasAttributes()) {
										// here we will get the Borrower relationship tags as per borrower
										// ID=BORROWER_100 AND RELATIONSHIP
										Attr relAttr = (Attr) reltnnNode.getAttributes().getNamedItem("xlink:to");
										if (relAttr != null) {
											String empRelationshipVal = relAttr.getValue();
											if (empRelationshipVal.contains(employerAtttributeVal)) {
												// here we will take borrower's relationship tags
												Attr relAttrAmountRef = (Attr) reltnnNode.getAttributes()
														.getNamedItem("xlink:from");
												listOfIncomeAmounts.add(relAttrAmountRef.getValue());
												loginfo.log(Status.INFO, "Relationship ID for " + employer
														+ "'s Borrower is" + relAttrAmountRef);
											}
										}
									}
								}
							}
						}
					}
				}

				// search for borrowers relationship tags as to get the income amount
				XPathExpression incomItem = xPathEmployer.compile("//CURRENT_INCOME_ITEMS/CURRENT_INCOME_ITEM");
				Object incomItemObject = incomItem.evaluate(doc, XPathConstants.NODESET);
				NodeList incomeItemNode = (NodeList) incomItemObject;
				// Once we get the Relationship tag name which is available in list, then take
				// the income amount from that relationship
				XPathExpression incomAmount = xPathEmployer.compile(
						"//CURRENT_INCOME_ITEMS/CURRENT_INCOME_ITEM/CURRENT_INCOME_ITEM_DETAIL/CurrentIncomeMonthlyTotalAmount");
				Object incomAmountObject = incomAmount.evaluate(doc, XPathConstants.NODESET);
				NodeList incomeAmountNode = (NodeList) incomAmountObject;

				for (int j = 0; j < incomeItemNode.getLength(); j++) {
					Node incomeNode = incomeItemNode.item(j);
					if (incomeNode.hasAttributes()) {
						Attr relAttr = (Attr) incomeNode.getAttributes().getNamedItem("xlink:label");
						if (relAttr != null) {
							String incomeItemAttribute = relAttr.getValue();
							if (listOfIncomeAmounts.contains(incomeItemAttribute)) {
								Node income = incomeAmountNode.item(j);
								String incomeVal = income.getTextContent();
								float monthlyIncome = Float.parseFloat(incomeVal);
								loginfo.log(Status.INFO, incomeItemAttribute + " income amount for " + employer + " is "
										+ monthlyIncome);
								totalMonthlyIncome = totalMonthlyIncome + monthlyIncome;
							}
						}
					}
				}

			} catch (XPathExpressionException e) {
				e.printStackTrace();
			}
			String incomeAmount = hook.driver.findElement(By.xpath("//td[contains(text(),'" + borrower
					+ "')]/parent::tr/td[contains(text(),'" + employer + "')]/parent::tr/td[3]/div")).getText()
					.replace("$", "");
			incomeAmount = incomeAmount.replace(",", "");
			float totalMonthlyIncomeUI = Float.parseFloat(incomeAmount);
			if (totalMonthlyIncomeUI == totalMonthlyIncome) {
				loginfo.log(Status.PASS,
						employer + "'s monthly income " + totalMonthlyIncome + " is displaying as per mismo file");
			}

		} catch (Exception e) {
			fname = hook.cm.addScreenshot(testContext);
			loginfo.log(Status.FAIL, e.getMessage());
			loginfo.addScreenCaptureFromPath(fname);
		}
	}
	
	@And("^verify that Documents Tab is in Table View$")
	public void verifythatDocumentsTabisinTableView() throws Exception {
	ExtentTest loginfo = null;
	try {
		loginfo = test.createNode(new GherkinKeyword("And"), "Document Tab is dispalyed in Table View");
		hook.wait.until(ExpectedConditions.visibilityOf(hook.lp.LoanLandingPage_DocumentsTab_TableView));
		Assert.assertTrue(hook.lp.LoanLandingPage_DocumentsTab_TableView.isDisplayed());
		loginfo.log(Status.PASS, "Document Tab is dispalyed in Table View:");
	} catch (Exception e) {
		fname = hook.cm.addScreenshot(testContext);
		loginfo.log(Status.FAIL, e.getMessage());
		loginfo.addScreenCaptureFromPath(fname);
	}
	}
	
	@When("^I click on Table View$")
	public void clickOnTableView() throws Exception {
	ExtentTest loginfo = null;
	try {
		loginfo = test.createNode(new GherkinKeyword("When"), "Click on Table View");
		hook.wait.until(ExpectedConditions.visibilityOf(hook.lp.LoanLandingPage_DocumentsTab_TableView));
		hook.lp.LoanLandingPage_DocumentsTab_TableView.click();
		loginfo.log(Status.PASS, "I clicked on Table View :");
	} catch (Exception e) {
		fname = hook.cm.addScreenshot(testContext);
		loginfo.log(Status.FAIL, e.getMessage());
		loginfo.addScreenCaptureFromPath(fname);
	}
	}
	
		
	@When("^I expand the borrower pane with below components where qualified income is \"(.*)\"$")
	public void expandTheBorrowerPaneWhereQualifiedIncome(String incomeType, DataTable components) throws Exception {
	ExtentTest loginfo = null;
	try {
		loginfo = test.createNode(new GherkinKeyword("And"), "Borrower pane expanded where qualified income is W2");
		
		int colSize = hook.driver.findElements(By.xpath("//thead[@role='rowgroup']//tr//th")).size();
		int rowSize = hook.driver.findElements(By.xpath("//tbody[@role='rowgroup']//tr")).size();
		int i, incomeCount = 0, count=0;
		String incomeValue2 = "";
		
		for(i=1; i<colSize ; i++) {
			String colName = hook.driver.findElement(By.xpath("(//thead[@role='rowgroup']//tr//th)["+i+"]")).getText();
			if(colName.equalsIgnoreCase(incomeType)) {
				incomeCount = hook.driver.findElements(By.xpath("//tbody[@role='rowgroup']//tr[contains(@class,'element-row')]//td["+i+"]//a")).size();
			for(int j=1; j<=incomeCount; j++) {
				String incomeValue1 = hook.driver.findElement(By.xpath("(//tbody[@role='rowgroup']//tr[contains(@class,'element-row')]//td["+i+"]//a)["+j+"]")).getAttribute("class");
				if(incomeValue1.contains("qualified")) {
					incomeValue2 = hook.driver.findElement(By.xpath("(//tbody[@role='rowgroup']//tr[contains(@class,'element-row')]//td["+i+"]//a)["+j+"]")).getText();
					for(int k=1; k<rowSize; k++) {
						String compareIncomeValues = hook.driver.findElement(By.xpath("//tbody[@role='rowgroup']//tr["+k+"]//td["+i+"]//div")).getText();
						loginfo.log(Status.INFO,
                                "Compare Income Values :"+compareIncomeValues+" and "+incomeValue2);
						count = hook.driver.findElements(By.xpath("//tbody[@role='rowgroup']//tr["+(k+1)+"]//div[4]//span[@class='ng-star-inserted']")).size();
						if(k!=1) {
							p=p+count+1;
						}
						if(compareIncomeValues.equalsIgnoreCase(incomeValue2)) {
							hook.driver.findElement(By.xpath("//tbody[@role='rowgroup']//tr["+k+"]//button//span")).click();
							hook.actions.pause(5000).build().perform();
							List<String> label = components.asList(String.class);
							loginfo.log(Status.INFO,
                                    "Label Components : "+label.size());
							if(count == 5) {
								for (int c = 0; c < label.size(); c++) {
									if (hook.driver.findElement(By.xpath("//tbody[@role='rowgroup']//tr["+(k+1)+"]//div[contains(text(),'" + label.get(c) + "')]")).isDisplayed()) {
										loginfo.log(Status.PASS, "Component is displayed : " + hook.driver
												.findElement(By.xpath("//tbody[@role='rowgroup']//tr["+(k+1)+"]//div[contains(text(),'" + label.get(c) + "')]")).getText());
									}
								}
							}
							if(k!=1) {
								p=p-count-1;
								}
							for(int l=0;l<count;l++) {
								hook.driver.findElement(By.xpath("(//tbody[@role='rowgroup']//tr["+(k+1)+"]//div[4]//span[@class='ng-star-inserted'])["+(l+1)+"]")).click();
								hook.actions.pause(5000).build().perform();
								boolean result = hook.driver.findElements(By.xpath("//tbody[@role='rowgroup']//tr["+(k+1)+"]//div[@id='cdk-accordion-child-"+p+"\'"+"]//*[name()='svg' and @data-icon='not-equal']")).size()!=0;
								hook.actions.pause(3000).build().perform();
								if(result){
									hook.driver.findElement(By.xpath("//span[contains(text(),'Borrower Application and Qualifying Pay do not match')]")).isDisplayed();
									hook.driver.findElement(By.xpath("//div[@class='button-layout']//button//span[contains(text(),'NEW CONDITION')]")).isDisplayed();
									hook.driver.findElement(By.xpath("//div[@class='button-layout']//button//span[contains(text(),'ACCEPT')]")).isDisplayed();
								}else{
									hook.driver.findElement(By.xpath("//*[name()='svg' and @data-icon='equals']")).isDisplayed();
									loginfo.log(Status.PASS, "Button is displayed : " + hook.driver
											.findElement(By.xpath("//*[name()='svg' and @data-icon='equals']")).getText());
								}
								p=p+1;
							}
							break;
						}
						k = k+1;
					}
				}
			}
		}
	}
			
	} catch (Exception e) {
        fname = hook.cm.addScreenshot(testContext);
        loginfo.log(Status.FAIL, e.getMessage());
        loginfo.addScreenCaptureFromPath(fname);
 }
	
	}
}
