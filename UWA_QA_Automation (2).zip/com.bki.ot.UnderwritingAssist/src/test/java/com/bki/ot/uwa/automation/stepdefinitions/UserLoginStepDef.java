package com.bki.ot.uwa.automation.stepdefinitions;

import org.openqa.selenium.support.ui.ExpectedConditions;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.GherkinKeyword;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;
import com.bki.ot.uwa.automation.extentreport.ExtentReportConfig;
import com.bki.ot.uwa.automation.filereadermanager.FileReaderManager;
import com.bki.ot.uwa.automation.testcontext.TestContext;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;

public class UserLoginStepDef extends ExtentReportConfig {

	Hooks hook;
	TestContext testContext;
	String url = null;
	public static String fname;

	public UserLoginStepDef(TestContext context) {
		testContext = context;
		hook = new Hooks(context);
		url = FileReaderManager.getFileReaderManagerInstance().getConfigInstance().getUrl();

	}

	@Given("^User enters \"(.*)\" \"(.*)\"$")
	public void UserentersUsernameAndPassword(String username, String password) throws Exception {
		ExtentTest loginfo = null;
		try {
			loginfo = test.createNode(new GherkinKeyword("Given"), "User enters " + username + password);
			hook.actions.pause(8000).build().perform();
			hook.wait.until(ExpectedConditions.visibilityOf(hook.gp.GenericPage_Username));
			hook.gp.GenericPage_Username.sendKeys(username);
			hook.wait.until(ExpectedConditions.visibilityOf(hook.gp.GenericPage_Password));
			hook.gp.GenericPage_Password.sendKeys(password);
			loginfo.log(Status.INFO, username + " " + password);
			hook.actions.pause(3000).build().perform();
			loginfo.log(Status.PASS, "Successfully entered Username and password ");
		} catch (Exception e) {
			fname = hook.cm.addScreenshot(testContext);
			loginfo.log(Status.FAIL, e.getMessage());
			loginfo.addScreenCaptureFromPath(fname);

		}

	}

	@Given("^Click on Logout in mypipeline page$")
	public void ClickonLogoutinmypipelinepage() throws Exception {
		ExtentTest loginfo = null;
		try {
			loginfo = test.createNode(new GherkinKeyword("Given"), "Click on Logout in mypipeline page");
			hook.wait.until(ExpectedConditions.visibilityOf(hook.gp.GenericPage_UserName_dropdown_option));
			hook.gp.GenericPage_UserName_dropdown_option.click();
			hook.wait.until(ExpectedConditions.visibilityOf(hook.gp.GenericPage_Logout));
			hook.gp.GenericPage_Logout.click();
			hook.actions.pause(3000).build().perform();
			if (hook.gp.GenericPage_Signout_page.getText().contains("Sign out")) {
				loginfo.log(Status.PASS, "User successfully Logged out ");
			} else {
				loginfo.log(Status.FAIL, "User not logged out ");
			}
		} catch (Exception e) {
			fname = hook.cm.addScreenshot(testContext);
			loginfo.log(Status.FAIL, e.getMessage());
			loginfo.addScreenCaptureFromPath(fname);

		}

	}

	@Then("^Verify home page and error message for Invalid credentials$")
	public void VerifyhomepageanderrormessageforInvalidcredentials() throws Exception {
		ExtentTest loginfo = null;
		try {
			loginfo = test.createNode(new GherkinKeyword("Then"),
					"Verify home page and error message for Invalid credentials");
			try {
				if (hook.gp.GenericPage_LoginError_Msg.isDisplayed()) {
					fname = hook.cm.addScreenshot(testContext);
					loginfo.log(Status.INFO,
							"Invalid Login Credentials Provided : " + hook.gp.GenericPage_LoginError_Msg.getText());
					loginfo.addScreenCaptureFromPath(fname);
				} else {
					hook.wait.until(ExpectedConditions.visibilityOf(hook.gp.GenericPage_UserName_dropdown_option));
					hook.gp.GenericPage_UserName_dropdown_option.click();
					hook.wait.until(ExpectedConditions.visibilityOf(hook.gp.GenericPage_Logout));
					fname = hook.cm.addScreenshot(testContext);
					loginfo.log(Status.PASS, "Successfully logged in with valid crendentials");
					loginfo.addScreenCaptureFromPath(fname);
					hook.wait.until(ExpectedConditions.elementToBeClickable(hook.gp.GenericPage_Logout));
					hook.gp.GenericPage_Logout.click();
					loginfo.log(Status.PASS, "Valid Login Credentials Case Pass");
				}
			} catch (Exception e) {
				hook.wait.until(ExpectedConditions.visibilityOf(hook.gp.GenericPage_UserName_dropdown_option));
				hook.gp.GenericPage_UserName_dropdown_option.click();
				hook.wait.until(ExpectedConditions.visibilityOf(hook.gp.GenericPage_Logout));
				hook.wait.until(ExpectedConditions.elementToBeClickable(hook.gp.GenericPage_Logout));
				hook.gp.GenericPage_Logout.click();
				fname = hook.cm.addScreenshot(testContext);
				loginfo.log(Status.PASS, "Login Successful");
				loginfo.addScreenCaptureFromPath(fname);
				loginfo.pass(MarkupHelper.createLabel("User Logged in Successfully", ExtentColor.GREEN));
				loginfo.pass(MarkupHelper.createLabel("Valid Login Credentials Case Pass", ExtentColor.GREEN));
			}
		} catch (Exception e) {
			fname = hook.cm.addScreenshot(testContext);
			loginfo.addScreenCaptureFromPath(fname);
			loginfo.log(Status.FAIL, e.getMessage());
		}
	}

	@Given("^User Login$")
	public void UserLogin() throws Exception {
		ExtentTest loginfo = null;
		try {
			loginfo = test.createNode(new GherkinKeyword("Then"), "User Login");
			hook.wait.until(ExpectedConditions.visibilityOf(hook.gp.GenericPage_Username));
			hook.gp.GenericPage_Username
					.sendKeys(FileReaderManager.getFileReaderManagerInstance().getConfigInstance().getUserName());
			hook.wait.until(ExpectedConditions.visibilityOf(hook.gp.GenericPage_Password));
			hook.gp.GenericPage_Password
					.sendKeys(FileReaderManager.getFileReaderManagerInstance().getConfigInstance().getPassword());
			hook.wait.until(ExpectedConditions.elementToBeClickable(hook.gp.GenericPage_Signin_button));
			hook.gp.GenericPage_Signin_button.click();
			loginfo.log(Status.INFO, "Successfully logged in as user : "
					+ FileReaderManager.getFileReaderManagerInstance().getConfigInstance().getUserName());

		} catch (Exception e) {
			fname = hook.cm.addScreenshot(testContext);
			loginfo.addScreenCaptureFromPath(fname);
			loginfo.log(Status.FAIL, e.getMessage());
		}
	}

	@Then("^Validate UWA Secure browse$")
	public void ValidateUWASecurebrowse() throws Exception {
		ExtentTest loginfo = null;
		try {

			loginfo = test.createNode(new GherkinKeyword("Then"), "Validate UWA Secure browse");
			String s = hook.driver.getCurrentUrl();
			loginfo.log(Status.INFO, "Secured browsing URL"
					+ FileReaderManager.getFileReaderManagerInstance().getConfigInstance().getUrl());
			if (s.contains("https")) {
				loginfo.pass(MarkupHelper.createLabel("UWA site is Secure", ExtentColor.GREEN));
			} else {
				loginfo.pass(MarkupHelper.createLabel("UWA site is NOT Secure", ExtentColor.RED));
			}
		} catch (Exception e) {
			fname = hook.cm.addScreenshot(testContext);
			loginfo.addScreenCaptureFromPath(fname);
			loginfo.log(Status.FAIL, e.getMessage());
		}
	}
	
	@Then("^verify user logout from application$")
	public void verifyUserLogoutFromApplication() throws Exception {
		ExtentTest loginfo = null;
		try {
			loginfo = test.createNode(new GherkinKeyword("Then"), "verify user logout from application");
			if (hook.gp.GenericPage_Signout_page.getText().contains("Sign out")) {
				loginfo.log(Status.PASS, "User successfully Logged out ");
			} else {
				loginfo.log(Status.FAIL, "User not logged out ");
			}

		} catch (Exception e) {
			fname = hook.cm.addScreenshot(testContext);
			loginfo.addScreenCaptureFromPath(fname);
			loginfo.log(Status.FAIL, e.getMessage());
		}
	}

}
