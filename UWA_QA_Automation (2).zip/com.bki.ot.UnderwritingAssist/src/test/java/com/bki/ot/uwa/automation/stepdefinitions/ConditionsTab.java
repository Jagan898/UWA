package com.bki.ot.uwa.automation.stepdefinitions;

import java.io.IOException;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Spliterator;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.GherkinKeyword;
import com.aventstack.extentreports.Status;
import com.bki.ot.uwa.automation.extentreport.ExtentReportConfig;
import com.bki.ot.uwa.automation.filereadermanager.FileReaderManager;
import com.bki.ot.uwa.automation.testcontext.TestContext;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.an.E;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class ConditionsTab extends ExtentReportConfig {
	Hooks hook;
	TestContext testContext;
	String url = null;
	public static String fname;
	public static HashMap<String, String> myHashMap = new HashMap<>();

	public ConditionsTab(TestContext context) {
		testContext = context;
		hook = new Hooks(context);
		url = FileReaderManager.getFileReaderManagerInstance().getConfigInstance().getUrl();

	}

	@And("^Click on button contains text \"(.*)\" and verify number of Documents count$")
	public void click_on_Button_and_Verify_documents_Count(String labelName) throws Exception {

		ExtentTest loginfo = null;
		try {
			loginfo = test.createNode(new GherkinKeyword("And"),
					"Click on button contains text " + labelName + " and verify number of Documents count");
			if (hook.driver.findElement(By.xpath("//*[@role='tablist']//span[text()='" + labelName + "']"))
					.isDisplayed()) {
				hook.driver.findElement(By.xpath("//*[@role='tablist']//span[text()='" + labelName + "']")).click();
				loginfo.log(Status.PASS, labelName + " tab is displayed and clicked on it");
				String documents = hook.driver
						.findElement(By.xpath(
								"//*[@role='tablist']//span[text()='" + labelName + "']/following-sibling::span"))
						.getText();
				loginfo.log(Status.INFO, documents + " of documents displayed under " + labelName + " tab");
			} else {
				loginfo.log(Status.FAIL, labelName + " tab is not displayed");
			}

		} catch (AssertionError e) {
			fname = hook.cm.addScreenshot(testContext);
			loginfo.log(Status.FAIL, e.getMessage());
			loginfo.addScreenCaptureFromPath(fname);

		}

	}

	@Then("^Verify below labels displaying in the page$")
	public void verify_below_labels_displayed_in_the_page(DataTable uiLabels) throws Exception {
		ExtentTest loginfo = null;
		try {
			loginfo = test.createNode(new GherkinKeyword("Then"), "Verify below labels displaying in the page");
			List<String> label = uiLabels.asList(String.class);
			for (int i = 0; i < label.size(); i++) {
				if (hook.driver
						.findElement(By.xpath(
								"//span[contains(text(),'" + label.get(i) + "')]|//*[(text()='" + label.get(i) + "')]"))
						.isDisplayed())
					loginfo.log(Status.PASS, "Header displayed : " + hook.driver.findElement(By.xpath(
							"//span[contains(text(),'" + label.get(i) + "')]|//*[(text()='" + label.get(i) + "')]"))
							.getText());
			}

		} catch (AssertionError e) {
			fname = hook.cm.addScreenshot(testContext);
			loginfo.log(Status.FAIL, e.getMessage());
			loginfo.addScreenCaptureFromPath(fname);

		}

	}

	@Then("^Verify \"(.*)\" label displaying with eqaul text in the page$")
	public void verify_Lable_with_eaqualTest(String label) throws Exception {
		ExtentTest loginfo = null;
		try {
			loginfo = test.createNode(new GherkinKeyword("Then"), "Verify below labels displaying in the page");

			if (hook.driver.findElement(By.xpath("//*[text()='" + label + "']")).isDisplayed())
				loginfo.log(Status.PASS, "Header displayed : "
						+ hook.driver.findElement(By.xpath("//*[(text()='" + label + "')]")).getText());
			else
				loginfo.log(Status.FAIL, "Header not displayed : " + label);

		} catch (AssertionError e) {
			fname = hook.cm.addScreenshot(testContext);
			loginfo.log(Status.FAIL, e.getMessage());
			loginfo.addScreenCaptureFromPath(fname);

		}
	}

	@Then("^Click \"(.*)\" label displaying with eqaul text in the page$")
	public void click_Lable_with_eaqualTest(String label) throws Exception {
		ExtentTest loginfo = null;
		try {
			loginfo = test.createNode(new GherkinKeyword("Then"), "Verify below labels displaying in the page");

			if (hook.driver.findElement(By.xpath("//*[(text()='" + label + "')]")).isDisplayed()) {
				hook.driver.findElement(By.xpath("//*[(text()='" + label + "')]")).click();
				loginfo.log(Status.PASS, "Header displayed : "
						+ hook.driver.findElement(By.xpath("//*[(text()='" + label + "')]")).getText());
			} else
				loginfo.log(Status.FAIL, "Header not displayed : " + label);

		} catch (AssertionError e) {
			fname = hook.cm.addScreenshot(testContext);
			loginfo.log(Status.FAIL, e.getMessage());
			loginfo.addScreenCaptureFromPath(fname);

		}
	}

	@Then("^Verify conditions displayed in \"(.*)\" order as per Condition header$")
	public void verify_Conditions_display_Order(String conditionsOrder) throws Exception {

		ExtentTest loginfo = null;
		try {
			loginfo = test.createNode(new GherkinKeyword("Then"),
					"Verify conditions displayed in " + conditionsOrder + " order as per Condition header");
			hook.wait.until(ExpectedConditions.visibilityOf(hook.lp.LoanLandingPag_ConditionsTab_ConditionHeader));
			String docOrderAttribute = hook.lp.LoanLandingPag_ConditionsTab_ConditionHeader.getAttribute("aria-sort");
			String conditionsArray[] = new String[hook.lp.LoanLandingPag_ConditionsTab_ListOfConditions.size() - 1];
			if (conditionsOrder.contains("ascending")
					& hook.lp.LoanLandingPag_ConditionsTab_ListOfConditions.size() > 1) {
				if (docOrderAttribute.contains("ascending")) {
					loginfo.log(Status.PASS, "Conditions are diplaying in ascending order");
				} else {
					hook.lp.LoanLandingPag_ConditionsTab_ConditionHeader.click();
					loginfo.log(Status.PASS, "Conditions are diplaying in ascending order");
				}
				int l = 0, k = 1;
				for (int i = 1; i < hook.lp.LoanLandingPag_ConditionsTab_ListOfConditions.size(); i++) {
					k = l + i;
					conditionsArray[l] = hook.driver
							.findElement(By.xpath("//table[@matsortactive='conditionType']/tbody/tr[" + k + "]/td[3]"))
							.getText();
					l = l + 1;
				}
				Arrays.sort(conditionsArray);
			} else {
				if (docOrderAttribute.contains("descending")) {
					loginfo.log(Status.PASS, "Conditions are diplaying in descending order");
				} else {
					hook.lp.LoanLandingPag_ConditionsTab_ConditionHeader.click();
					loginfo.log(Status.PASS, "Conditions are diplaying in ascending order");
				}
				hook.actions.pause(2000).build().perform();
				int l = 0, k = 1;
				for (int i = 1; i < hook.lp.LoanLandingPag_ConditionsTab_ListOfConditions.size(); i++) {
					k = l + i;
					conditionsArray[l] = hook.driver
							.findElement(By.xpath("//table[@matsortactive='conditionType']/tbody/tr[" + k + "]/td[3]"))
							.getText();
					l = l + 1;
				}
				Arrays.sort(conditionsArray, Collections.reverseOrder());
			}
			int l = 0, k = 1;
			for (int j = 1; j < conditionsArray.length; j++) {
				k = l + j;
				String tableValues = hook.driver
						.findElement(By.xpath("//table[@matsortactive='conditionType']/tbody/tr[" + k + "]/td[3]"))
						.getText().trim();
				String sortedTableValue = conditionsArray[j - 1].trim();
				if (tableValues.equalsIgnoreCase(sortedTableValue)) {
					loginfo.log(Status.PASS, j + "th condition" + tableValues + "  is correctly displaying in "
							+ conditionsOrder + " Order");
				} else {
					loginfo.log(Status.FAIL, j + "th condition" + tableValues + " is not matching: " + "Table Value :"
							+ tableValues + " :: " + sortedTableValue);
				}
				l = l + 1;
			}

		} catch (AssertionError e) {
			fname = hook.cm.addScreenshot(testContext);
			loginfo.log(Status.FAIL, "Verify conditions in ascending and descending sorted order " + e.getMessage());
			loginfo.addScreenCaptureFromPath(fname);

		}

	}

	@Then("^Verify condions list under cleared tab if list is empty then clear two conditions$")
	public void Verify_condions_list_under_cleared_tab_if_list_is_empty_then_clear_two_conditions() throws Exception {
		ExtentTest loginfo = null;
		try {
			loginfo = test.createNode(new GherkinKeyword("And"),
					"Verify condions list under cleared tab if list is empty then clear two conditions");
			if (hook.lp.LoanLandingPag_ConditionsTab_ListOfConditions.size() > 1) {
				loginfo.log(Status.PASS, "More than 2  documents available in conditions tab");

			} else {
				hook.actions.pause(2000).build().perform();
				hook.lp.LoanLandingPag_ConditionsTab_IncomeLabel.click();
				if (hook.lp.LoanLandingPag_ConditionsTab_ListOfConditions.size() <= 1) {
					hook.lp.LoanLandingPag_ConditionsTab_rootCheckBox.click();
					hook.actions.pause(2000).build().perform();
					hook.lp.LoanLandingPag_ConditionsTab_ClearButtom.click();
					hook.actions.pause(2000).build().perform();
					hook.cm.confirm_clickLabel("clear conditions");
					hook.lp.LoanLandingPag_ConditionsTab_ClearTAB.click();

					loginfo.log(Status.PASS, "Selected 2  conditions under Income tab");
				} else {
					for (int i = 1; i < 3; i++) {
						hook.lp.LoanLandingPag_ConditionsTab_ListOfConditionsCheckBoxes.get(i).click();
					}
					hook.lp.LoanLandingPag_ConditionsTab_ClearButtom.click();
					hook.cm.confirm_clickLabel("clear conditions");
					hook.actions.pause(2000).build().perform();
					hook.lp.LoanLandingPag_ConditionsTab_ClearTAB.click();
					loginfo.log(Status.PASS, "Selected 2  conditions under Income tab");
				}

			}

		} catch (AssertionError e) {
			fname = hook.cm.addScreenshot(testContext);
			loginfo.log(Status.FAIL, e.getMessage());
			loginfo.addScreenCaptureFromPath(fname);

		}

	}

	@Then("^Provide details in create condition popup$")
	public void Providedetailsincreateconditionpopup(DataTable dt) throws Exception {
		ExtentTest loginfo = null;
		try {
			loginfo = test.createNode(new GherkinKeyword("Then"), "Provide details in create condition popup");
			List<Map<String, String>> data = dt.asMaps(String.class, String.class);

			hook.wait.until(ExpectedConditions.visibilityOf(hook.lp.LoanLandingPage_conditiontab_popup_heading));
			hook.lp.LoanLandingPage_conditiontab_popup_conditiontype_Dropdown.click();
			JavascriptExecutor js = (JavascriptExecutor) hook.driver;
			js.executeScript("arguments[0].click();",
					hook.lp.LoanLandingPage_conditiontab_popup_conditiontype_Dropdown);
			hook.actions.pause(3000).build().perform();
			loginfo.log(Status.INFO, "In create condition popup provided details as :");
			for (int i = 0; i < hook.lp.LoanLandingPage_conditiontab_popup_ConditionType_DropdownValues.size(); i++) {
				if (hook.lp.LoanLandingPage_conditiontab_popup_ConditionType_DropdownValues.get(i).getText()
						.equalsIgnoreCase(data.get(0).get("Condition Type")))

				{
					loginfo.log(Status.PASS, "Selected condition type :"
							+ hook.lp.LoanLandingPage_conditiontab_popup_ConditionType_DropdownValues.get(i).getText());

					hook.lp.LoanLandingPage_conditiontab_popup_ConditionType_DropdownValues.get(i).click();
				}
			}
			
			hook.actions.pause(1000).build().perform();
			hook.wait.until(
					ExpectedConditions.visibilityOf(hook.lp.LoanLandingPage_conditiontab_popup_Priorto_Dropdown));
			js.executeScript("arguments[0].click();", hook.lp.LoanLandingPage_conditiontab_popup_Priorto_Dropdown);
			for (int i = 0; i < hook.lp.LoanLandingPage_conditiontab_popup_Priorto_Dropdown_Values.size(); i++) {
				if (hook.lp.LoanLandingPage_conditiontab_popup_Priorto_Dropdown_Values.get(i).getText()
						.equalsIgnoreCase(data.get(0).get("Prior to")))

				{
					loginfo.log(Status.PASS, "Selected prior to type :"
							+ hook.lp.LoanLandingPage_conditiontab_popup_Priorto_Dropdown_Values.get(i).getText());

					hook.lp.LoanLandingPage_conditiontab_popup_Priorto_Dropdown_Values.get(i).click();
				}
			}

			hook.lp.LoanLandingPage_conditiontab_popup_ConditionDescription_input
					.sendKeys(data.get(0).get("Description"));
			// hook.lp.LoanLandingPage_conditiontab_popup_ConditionDescription_input.sendKeys(data.get(0).get("Description")+
			// "_" + hook.cm.timeStamp());
			js.executeScript("arguments[0].click();", hook.lp.LoanLandingPage_conditiontab_popup_Borrower_Dropdown);
			loginfo.log(Status.INFO, "Provided description as :" + data.get(0).get("Description"));
			for (int i = 0; i < hook.lp.LoanLandingPage_conditiontab_popup_Borrower_DropdownValues.size(); i++) {
				if (hook.lp.LoanLandingPage_conditiontab_popup_Borrower_DropdownValues.get(i).getText()
						.equalsIgnoreCase(data.get(0).get("Borower")))

				{
					loginfo.log(Status.PASS, "Selected Borrower :"
							+ hook.lp.LoanLandingPage_conditiontab_popup_Borrower_DropdownValues.get(i).getText());

					hook.lp.LoanLandingPage_conditiontab_popup_Borrower_DropdownValues.get(i).click();
				}
			}

			hook.wait.until(
					ExpectedConditions.visibilityOf(hook.lp.LoanLandingPage_conditiontab_popup_Employer_Dropdown));
			hook.actions.moveToElement(hook.lp.LoanLandingPage_conditiontab_popup_Employer_Dropdown).build().perform();

			hook.wait.until(ExpectedConditions
					.elementToBeClickable(hook.lp.LoanLandingPage_conditiontab_popup_Employer_Dropdown));
			js.executeScript("arguments[0].click();", hook.lp.LoanLandingPage_conditiontab_popup_Employer_Dropdown);
			hook.wait.until(ExpectedConditions
					.visibilityOfAllElements(hook.lp.LoanLandingPage_conditiontab_popup_Employer_DropdownValues));
			for (int i = 0; i < hook.lp.LoanLandingPage_conditiontab_popup_Employer_DropdownValues.size(); i++) {
				if (hook.lp.LoanLandingPage_conditiontab_popup_Employer_DropdownValues.get(i).getText()
						.equalsIgnoreCase(data.get(0).get("Employer")))

				{
					loginfo.log(Status.PASS, "Selected Employer :"
							+ hook.lp.LoanLandingPage_conditiontab_popup_Employer_DropdownValues.get(i).getText());

					hook.lp.LoanLandingPage_conditiontab_popup_Employer_DropdownValues.get(i).click();
				}
			}

/*			hook.actions.pause(1000).build().perform();
			hook.wait.until(
					ExpectedConditions.visibilityOf(hook.lp.LoanLandingPage_conditiontab_popup_Documents_Dropdown));
			hook.actions.moveToElement(hook.lp.LoanLandingPage_conditiontab_popup_Documents_Dropdown).build().perform();
			js.executeScript("arguments[0].click();", hook.lp.LoanLandingPage_conditiontab_popup_Documents_Dropdown);
			for (int i = 0; i < hook.lp.LoanLandingPage_conditiontab_popup_Documents_DropdownValues.size(); i++) {
				if (hook.lp.LoanLandingPage_conditiontab_popup_Documents_DropdownValues.get(i).getText()
						.equalsIgnoreCase(data.get(0).get("Attach Document List")))

				{
					loginfo.log(Status.PASS, "Selected document :"
							+ hook.lp.LoanLandingPage_conditiontab_popup_Documents_DropdownValues.get(i).getText());

					hook.lp.LoanLandingPage_conditiontab_popup_Documents_DropdownValues.get(i).click();
					break;
				}
			}
*/
			// hook.lp.LoanLandingPage_conditiontab_popup_heading.click();
			// hook.lp.LoanLandingPage_conditiontab_popup_Mynotes_textarea.click();
			hook.wait.until(
					ExpectedConditions.visibilityOf(hook.lp.LoanLandingPage_conditiontab_popup_Mynotes_textarea));
			hook.lp.LoanLandingPage_conditiontab_popup_Mynotes_textarea.sendKeys(data.get(0).get("My Notes"));
			loginfo.log(Status.INFO, "Provided My notes as :" + data.get(0).get("My Notes"));
		} catch (Exception e) {
			fname = hook.cm.addScreenshot(testContext);
			loginfo.log(Status.FAIL, e.getMessage());
			loginfo.addScreenCaptureFromPath(fname);

		}
	}

	@And("^Verify condition in All conditions condition column \"(.*)\"$")
	public void VerifyconditioninAllconditionsconditioncolumn(String con) throws Exception {
		ExtentTest loginfo = null;
		try {
			loginfo = test.createNode(new GherkinKeyword("Then"),
					"Verify condition in All conditions condition column");
			int flag = 0;
			String cn = null;
			hook.actions.pause(3000).build().perform();
			hook.wait.until(ExpectedConditions.visibilityOfAllElements(
					hook.lp.LoanLandingPage_conditiontab_Allconditions_Income_cleartab_descriptionList));
			for (int i = 0; i < hook.lp.LoanLandingPage_conditiontab_Allconditions_Income_cleartab_descriptionList
					.size(); i++) {
				if (hook.lp.LoanLandingPage_conditiontab_Allconditions_Income_cleartab_descriptionList.get(i).getText()
						.equalsIgnoreCase(con)) {
					flag = 1;
					cn = hook.lp.LoanLandingPage_conditiontab_Allconditions_Income_cleartab_descriptionList.get(i)
							.getText();
					break;
				}
			}
			if (flag == 1) {
				loginfo.log(Status.PASS, "Successsfully condition displayed in condition column :" + cn);
			} else {
				loginfo.log(Status.FAIL, "Condition not displayed " + con);
			}
		} catch (Exception e) {
			fname = hook.cm.addScreenshot(testContext);
			loginfo.log(Status.FAIL, e.getMessage());
			loginfo.addScreenCaptureFromPath(fname);
		}
	}

	@And("^Select condition \"(.*)\" in Income tab using \"(.*)\"$")
	public void SelectConditioninIncometab(String con, String selectOption) throws Exception {
		ExtentTest loginfo = null;
		try {
			int flag = 0;
			loginfo = test.createNode(new GherkinKeyword("Then"), "Select condition " + con + " in Income tab");
			hook.actions.pause(3000).build().perform();
			hook.wait.until(ExpectedConditions.visibilityOfAllElements(
					hook.lp.LoanLandingPage_conditiontab_Allconditions_Income_cleartab_descriptionList));
			JavascriptExecutor js = (JavascriptExecutor) hook.driver;
			for (int i = 0; i < hook.lp.LoanLandingPage_conditiontab_Allconditions_Income_cleartab_descriptionList
					.size(); i++) {
				if (hook.lp.LoanLandingPage_conditiontab_Allconditions_Income_cleartab_descriptionList.get(i).getText()
						.equalsIgnoreCase(con))

				{
					switch (selectOption) {
					case "Checkbox":
						js.executeScript("arguments[0].click();",
								hook.driver.findElement(
										By.xpath("//*[contains(@class,'mat-column-Description') and contains(text(),'"
												+ con + "')]/preceding::*[contains(@class,'mat-checkbox')][2]")));
						flag = 1;
						break;
					case "Ellipse":
						js.executeScript("arguments[0].click();",hook.driver.findElement(By.xpath("//*[contains(@class,'mat-column-Description') and contains(text(),'"+con+"')]/following::*[@aria-label='more options'][1]/span")));					
						flag = 1;
						break;
					default:
						break;
					}
					break;
				}
			}
			hook.actions.pause(3000).build().perform();
			if (flag == 1) {
				loginfo.log(Status.PASS, "Successsfully condition selected :" + con);
			} else {
				loginfo.log(Status.PASS, "Successsfully condition selected :" + con);
			}
		} catch (Exception e) {
			fname = hook.cm.addScreenshot(testContext);
			loginfo.log(Status.FAIL, e.getMessage());
			loginfo.addScreenCaptureFromPath(fname);

		}

	}

	@And("^Click on Ellipses option for condition \"(.*)\"$")
	public void ClickonEllipsesoptionforcondition(String con) throws Exception {
		ExtentTest loginfo = null;
		try {
			loginfo = test.createNode(new GherkinKeyword("Then"), "Click on Ellipses option for condition :" + con);
			hook.wait.until(ExpectedConditions.visibilityOfAllElements(
					hook.lp.LoanLandingPage_conditiontab_Allconditions_Income_cleartab_descriptionList));
			JavascriptExecutor js = (JavascriptExecutor) hook.driver;
			js.executeScript("arguments[0].click();",
					hook.driver
							.findElement(By.xpath("//*[contains(@class,'mat-column-Description') and contains(text(),'"
									+ con + "')]/following::button[@aria-label='more options'][1]")));
			if (hook.lp.LoanLandingPage_conditiontab_Allconditions_Income_cleartab_menuitems_list.isEmpty()) {
				loginfo.log(Status.FAIL, "Unable to click ellipses option for contion:" + con);
			} else {
				loginfo.log(Status.PASS, "Successfully ellipses option clicked for condition :" + con);
			}
		} catch (Exception e) {
			fname = hook.cm.addScreenshot(testContext);
			loginfo.log(Status.FAIL, e.getMessage());
			loginfo.addScreenCaptureFromPath(fname);

		}

	}

	@And("^Verify the Ellipses options \"(.*)\" , \"(.*)\" and \"(.*)\" for condition$")
	public void Verifytheellipsesoptionforcondition(String op1, String op2, String op3) throws Exception {
		ExtentTest loginfo = null;
		try {
			loginfo = test.createNode(new GherkinKeyword("Then"),
					"Verify the Ellipses options " + op1 + "," + op2 + " and " + op3 + " for condition");

			if (hook.lp.LoanLandingPage_conditiontab_Allconditions_Income_cleartab_menuitems_list.isEmpty()) {
				loginfo.log(Status.FAIL, "Ellipses options are not displayed for conditions");
			} else {
				loginfo.log(Status.PASS, "Ellipses options are displayed successfully :"
						+ hook.lp.LoanLandingPage_conditiontab_Allconditions_Income_cleartab_menuitems_list.size());
			}
			if (hook.lp.LoanLandingPage_conditiontab_Allconditions_Income_cleartab_menuitems_list.get(0).getText()
					.equalsIgnoreCase(op1)
					&& hook.lp.LoanLandingPage_conditiontab_Allconditions_Income_cleartab_menuitems_list.get(1)
							.getText().equalsIgnoreCase(op2)
					&& hook.lp.LoanLandingPage_conditiontab_Allconditions_Income_cleartab_menuitems_list.get(2)
							.getText().equalsIgnoreCase(op3)) {
				loginfo.log(Status.PASS,
						"Successfully ellipses options matched and displayed properly:"
								+ hook.lp.LoanLandingPage_conditiontab_Allconditions_Income_cleartab_menuitems_list
										.get(0).getText()
								+ hook.lp.LoanLandingPage_conditiontab_Allconditions_Income_cleartab_menuitems_list
										.get(1).getText()
								+ hook.lp.LoanLandingPage_conditiontab_Allconditions_Income_cleartab_menuitems_list
										.get(2).getText());
			} else {
				loginfo.log(Status.FAIL, "Ellipses options are not matched and not displayed properly");
			}
		} catch (Exception e) {
			fname = hook.cm.addScreenshot(testContext);
			loginfo.log(Status.FAIL, e.getMessage());
			loginfo.addScreenCaptureFromPath(fname);

		}

	}

	@Then("^Verify New condition option and popup fields$")
	public void VerifyNewconditionoptionandpopupfields(DataTable dt) throws Exception {
		ExtentTest loginfo = null;
		try {
			loginfo = test.createNode(new GherkinKeyword("Then"), "Verify New condition option and popup fields");
			List<String> list = dt.asList(String.class);
			hook.actions.pause(3000).build().perform();
			hook.wait.until(ExpectedConditions.visibilityOf(hook.lp.LoanLandingPage_conditiontab_Newcondition_button));
			Assert.assertTrue(hook.lp.LoanLandingPage_conditiontab_Newcondition_button.getText()
					.equalsIgnoreCase("+ New Condition"));
			loginfo.log(Status.INFO, "Successfully new condition option displayed in condition tab");
			hook.lp.LoanLandingPage_conditiontab_Newcondition_button.click();
			hook.wait.until(ExpectedConditions.visibilityOf(hook.lp.LoanLandingPage_conditiontab_popup_heading));
			Assert.assertTrue(hook.lp.LoanLandingPage_conditiontab_popup_conditiontype_Dropdown.isDisplayed()
					&& hook.lp.LoanLandingPage_conditiontab_popup_ConditionDescription_input.isDisplayed()
					&& hook.lp.LoanLandingPage_conditiontab_popup_Documents_Dropdown.isDisplayed()
					&& hook.lp.LoanLandingPage_conditiontab_popup_Mynotes_textarea.isDisplayed()
					&& list.get(0).equalsIgnoreCase(hook.lp.LoanLandingPage_conditiontab_popup_heading.getText())
					&& list.get(1).equalsIgnoreCase(hook.lp.LoanLandingPage_conditiontab_popup_Mynotes_label.getText())
					&& list.get(2).equalsIgnoreCase(hook.gp.Genericpage_Cancel_button.getText())
					&& list.get(3).equalsIgnoreCase(hook.gp.Genericpage_Save_button.getText()));
			loginfo.log(Status.PASS,
					"Successfully New condition pop up heading displayed :"
							+ hook.lp.LoanLandingPage_conditiontab_popup_heading.getText() + "<br />"
							+ "Successfully all the popup options displayed" + "<br />"
							+ hook.lp.LoanLandingPage_conditiontab_popup_Mynotes_label.getText() + "<br />"
							+ hook.gp.Genericpage_Cancel_button.getText() + "<br />"
							+ hook.gp.Genericpage_Save_button.getText());

		} catch (AssertionError e) {
			fname = hook.cm.addScreenshot(testContext);
			loginfo.log(Status.FAIL, "Verify New condition and popup fields" + e.getMessage());
			loginfo.addScreenCaptureFromPath(fname);
		}
	}

	@When("^Click on All conditions \"(.*)\" tab$")
	public void ClickonAllconditionstab(String tab) throws Exception {
		ExtentTest loginfo = null;
		try {
			loginfo = test.createNode(new GherkinKeyword("When"), "Click on All conditions" + tab + " tab");
			hook.wait.until(ExpectedConditions
					.visibilityOfAllElements(hook.lp.LoanLandingPage_conditiontab_Allconditions_tabs_list));
			for (int i = 0; i < hook.lp.LoanLandingPage_conditiontab_Allconditions_tabs_list.size(); i++) {
				if (hook.lp.LoanLandingPage_conditiontab_Allconditions_tabs_list.get(i).getText()
						.equalsIgnoreCase(tab)) {
					loginfo.log(Status.PASS, "Successfull clicked on Tab : "
							+ hook.lp.LoanLandingPage_conditiontab_Allconditions_tabs_list.get(i).getText());
					hook.lp.LoanLandingPage_conditiontab_Allconditions_tabs_list.get(i).click();
					break;
				}
			}
		} catch (Exception e) {
			fname = hook.cm.addScreenshot(testContext);
			loginfo.log(Status.FAIL, e.getMessage());
			loginfo.addScreenCaptureFromPath(fname);

		}

	}

	@When("^Verify the Ellipses and option Reopen in Cleartab$")
	public void VerifytheEllipsesandoptionReopeninCleartab() throws Exception {
		ExtentTest loginfo = null;
		try {
			loginfo = test.createNode(new GherkinKeyword("When"), "Verify the Ellipses and option Reopen in Cleartab");
			hook.wait.until(ExpectedConditions.visibilityOfAllElements(
					hook.lp.LoanLandingPage_conditiontab_Allconditions_ClearTab_Ellipses_list));
			if (hook.lp.LoanLandingPage_conditiontab_Allconditions_ClearTab_Ellipses_list.size() > 0) {
				loginfo.log(Status.PASS, "Ellipses option displayed successfully in cleared tab");
				hook.lp.LoanLandingPage_conditiontab_Allconditions_ClearTab_Ellipses_list.get(0).click();
				hook.wait.until(ExpectedConditions.visibilityOf(
						hook.lp.LoanLandingPage_conditiontab_Allconditions_ClearTab_Ellipsesoption_Reopen));
				if (hook.lp.LoanLandingPage_conditiontab_Allconditions_ClearTab_Ellipsesoption_Reopen.isDisplayed()) {
					loginfo.log(Status.PASS,
							"Successfully Reopen option displayed in Ellipses for condition in cleared tab: "
									+ hook.lp.LoanLandingPage_conditiontab_Allconditions_ClearTab_Ellipsesoption_Reopen
											.getText());
				}
			} else {
				loginfo.log(Status.FAIL,
						"Ellipses option not displayed and Reopen option not displayed in cleared tab");
			}

		} catch (Exception e) {
			fname = hook.cm.addScreenshot(testContext);
			loginfo.log(Status.FAIL, e.getMessage());
			loginfo.addScreenCaptureFromPath(fname);

		}

	}

	@When("^Select condition and verify Reopen option$")
	public void SelectconditionandverifyReopenoption() throws Exception {
		ExtentTest loginfo = null;
		try {
			loginfo = test.createNode(new GherkinKeyword("When"), "Select condition and verify Reopen option");
			hook.wait.until(ExpectedConditions.visibilityOfAllElements(
					hook.lp.LoanLandingPage_conditiontab_Allconditions_ClearTab_condition_checkbox_list));
			if (hook.lp.LoanLandingPage_conditiontab_Allconditions_ClearTab_condition_checkbox_list.size() > 0) {
				loginfo.log(Status.PASS, "Checkboxes displayed for conditions");
				WebElement option = hook.lp.LoanLandingPage_conditiontab_Allconditions_ClearTab_condition_checkbox_list
						.get(1);
				JavascriptExecutor js = (JavascriptExecutor) hook.driver;
				js.executeScript("arguments[0].click();", option);
				hook.wait.until(ExpectedConditions
						.visibilityOf(hook.lp.LoanLandingPage_conditiontab_Allconditions_ClearTab_Reopen_button));
				if (hook.lp.LoanLandingPage_conditiontab_Allconditions_ClearTab_Reopen_button.isDisplayed()) {
					loginfo.log(Status.PASS,
							"Successfully Reopen button displayed when selected condition checkbox in cleared tab: "
									+ hook.lp.LoanLandingPage_conditiontab_Allconditions_ClearTab_Reopen_button
											.getText());
				}
			} else {
				loginfo.log(Status.FAIL, "Reopen button not displayed when condition selected in cleared tab");
			}

		} catch (Exception e) {
			fname = hook.cm.addScreenshot(testContext);
			loginfo.log(Status.FAIL, e.getMessage());
			loginfo.addScreenCaptureFromPath(fname);
		}
	}

	@And("^Number of Documents count should be shown beside \"(.*)\" tab$")
	public void number_of_Documents_count_should_be_shownOnTabs(String conditionaTab) throws Exception {
		ExtentTest loginfo = null;
		try {
			loginfo = test.createNode(new GherkinKeyword("And"),
					"Number of Documents count should be shown beside " + conditionaTab + " tab");
			if (hook.driver
					.findElement(By.xpath("//span[contains(text(),'" + conditionaTab + "')]/parent::div/span[2]"))
					.isDisplayed()) {
				String numberOfCounts = hook.driver
						.findElement(By.xpath("//span[contains(text(),'" + conditionaTab + "')]/parent::div/span[2]"))
						.getText();
				loginfo.log(Status.PASS, numberOfCounts + " number of " + conditionaTab + " documents are available");
			}

		} catch (Exception e) {
			fname = hook.cm.addScreenshot(testContext);
			loginfo.log(Status.FAIL, e.getMessage());
			loginfo.addScreenCaptureFromPath(fname);
		}

	}

	@And("^Ellipses Option should display for each row$")
	public void verify_EllipseOptionDisplay() throws Exception {
		ExtentTest loginfo = null;
		try {
			loginfo = test.createNode(new GherkinKeyword("And"), "Ellipses Option should display for each row");
			if (hook.lp.LoanLandingPage_conditiontab_Allconditions_ClearTab_NumberOfEllipses.size() > 1) {
				loginfo.log(Status.PASS, " Ellipses Option is displayed");
			} else
				loginfo.log(Status.PASS, " Ellipses Option not displayed");
		} catch (Exception e) {
			fname = hook.cm.addScreenshot(testContext);
			loginfo.log(Status.FAIL, e.getMessage());
			loginfo.addScreenCaptureFromPath(fname);
		}
	}

	@Then("^Verify the Row count at the right-hand side corner of the table$")
	public void verify_the_Row_count_at_the_right_hand_side_corner_of_the_table() throws Exception {

		ExtentTest loginfo = null;
		try {
			loginfo = test.createNode(new GherkinKeyword("Then"), "Ellipses Option should display for each row");
			if (hook.lp.LoanLandingPage_conditiontab_Allconditions_ClearTab_NumberOfEllipses.size() > 7) {
				loginfo.log(Status.PASS, " Ellipses Option is displayed");
				JavascriptExecutor js = (JavascriptExecutor) hook.driver;
				js.executeScript("arguments[0].scrollIntoView();",
						hook.lp.LoanLandingPag_ConditionsTab_numberOfRowsOrRecords);
				if (hook.lp.LoanLandingPag_ConditionsTab_numberOfRowsOrRecords.isDisplayed()) {
					String numberOfRecord = hook.lp.LoanLandingPag_ConditionsTab_numberOfRowsOrRecords.getText();
					String[] numberRecordsUI = numberOfRecord.split(" ");
					loginfo.log(Status.PASS,
							numberRecordsUI[numberRecordsUI.length - 1] + " Records or Rows available in this TAB");
				}
			} else {
				if (hook.lp.LoanLandingPag_ConditionsTab_numberOfRowsOrRecords.isDisplayed()) {
					String numberOfRecord = hook.lp.LoanLandingPag_ConditionsTab_numberOfRowsOrRecords.getText();
					String[] numberRecordsUI = numberOfRecord.split(" ");
					loginfo.log(Status.PASS,
							numberRecordsUI[numberRecordsUI.length - 1] + " Records or Rows available in this TAB");
				}
			}

		} catch (Exception e) {
			fname = hook.cm.addScreenshot(testContext);
			loginfo.log(Status.FAIL, e.getMessage());
			loginfo.addScreenCaptureFromPath(fname);
		}

	}

	@And("^Verify each borrower row acontains ellipse option$")
	public void verify_EllipsiOptions_for_Conditions() throws Exception {
		ExtentTest loginfo = null;
		try {
			loginfo = test.createNode(new GherkinKeyword("And"), "Verify each borrower row acontains ellipse option");
			if (hook.lp.LoanLandingPage_conditiontab_Allconditions_ClearTab_NumberOfEllipses
					.size() == hook.lp.LoanLandingPage_conditiontab_NumberOfBorrowers.size()) {
				loginfo.log(Status.PASS,
						" Borrowers and Ellipses Options count is same and all borrowers contains Ellipse option");
				loginfo.log(Status.INFO,
						hook.lp.LoanLandingPage_conditiontab_Allconditions_ClearTab_NumberOfEllipses.size()
								+ " Borrowers and Ellipses Options available");
			} else
				loginfo.log(Status.FAIL, "  There are no borrowers so there wont be Ellipse options");
		} catch (Exception e) {
			fname = hook.cm.addScreenshot(testContext);
			loginfo.log(Status.FAIL, e.getMessage());
			loginfo.addScreenCaptureFromPath(fname);
		}

	}

}
