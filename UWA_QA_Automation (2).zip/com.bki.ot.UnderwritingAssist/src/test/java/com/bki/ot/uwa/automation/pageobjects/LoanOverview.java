package com.bki.ot.uwa.automation.pageobjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class LoanOverview {

	WebDriver driver;

	public LoanOverview(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);

	}

	// *************************************Loan Overview****************************//
	@FindBy(xpath = "//*[@data-icon='exclamation-circle']")
	public WebElement LoanLandingPage_LoanOverview_exclamation_circle;
	@FindBy(xpath = "//*[@data-icon='list-ol']")
	public WebElement LoanLandingPage_LoanOverview_list_ol_icon;
	
	

}
