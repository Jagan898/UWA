package com.bki.ot.uwa.automation.stepdefinitions;

import java.io.File;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.testng.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.io.FileHandler;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.bki.ot.uwa.automation.filereadermanager.FileReaderManager;
import com.bki.ot.uwa.automation.testcontext.TestContext;

public class CommonMethods {
	WebDriver driver;
	public static String timeStamp;
	Hooks hook;
	ExtentTest loginfo = null;
	TestContext testContext;
	String url = null;

	public CommonMethods(WebDriver driver) {
		this.driver = driver;

		PageFactory.initElements(driver, this);

	}

	public CommonMethods(TestContext context) {
		testContext = context;
		hook = new Hooks(context);
		url = FileReaderManager.getFileReaderManagerInstance().getConfigInstance().getUrl();

	}

	public String addScreenshot(TestContext testContext) throws Exception {
		SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yy-mm-hh-ss");
		Date d = new Date();
		String fname = sdf.format(d) + ".png";
		File src = ((TakesScreenshot) testContext.getBaseConfigInstance().getDriver()).getScreenshotAs(OutputType.FILE);
		File dest = new File("src/test/resources/output/extentreport/" + fname);
		FileHandler.copy(src, dest);
		return fname;
	}

	public String timeStamp() {
		timeStamp = new Timestamp(System.currentTimeMillis()).toString();
		timeStamp = timeStamp.substring(0, timeStamp.length() - 6).replaceAll(":", "");
		return timeStamp;
	}

	public void selectEqualCaseIgnoreListValue(List<WebElement> elements, String Value) throws Exception {

		hook.wait.until(ExpectedConditions.visibilityOfAllElements(elements));
		for (int i = 0; i < elements.size(); i++) {
			if (elements.get(i).getText().equalsIgnoreCase(Value)) {
				loginfo.log(Status.INFO, "Successfull clicked on" + elements.get(i).getText());
				elements.get(i).click();
				break;
			}
		}
	}

	public void click(WebElement element) {
		hook.wait.until(ExpectedConditions.visibilityOf(element));
		hook.wait.until(ExpectedConditions.elementToBeClickable(element));
		element.click();
	}

	public void sendKeys(WebElement element, String value) {
		hook.wait.until(ExpectedConditions.visibilityOf(element));
		hook.wait.until(ExpectedConditions.elementToBeClickable(element));
		element.sendKeys(value);
	}

	public WebElement findElementByLabel(String stringLabel) {

		String buttonBy = "((//span[contains(text(),'" + stringLabel + "')])|(//*[contains(text(),'" + stringLabel + "')])|" + 
				"(//div[normalize-space(text())='" + stringLabel + "'])|//*[contains(text(),'" + stringLabel + "')]|" + 
				"(//a[contains(text(),'" + stringLabel + "')]))";
		WebElement temp;
		try {
			waitForAnElement(buttonBy);
			temp = driver.findElement(By.xpath(buttonBy));
			return temp;
		} catch (Exception e) {
			String element = "(//*[contains(@type,'button') and (@value='" + stringLabel + "'@name='" + stringLabel+ "')])|" + 
					"(//*[contains(@type,'submit') and (@value='" + stringLabel + "' or @name='" + stringLabel + "')])|" + 
					"(//*[contains(@type,'Button') and (@value='" + stringLabel + "' or @name='" + stringLabel + "' or @id='" + stringLabel + "')])";
			waitForAnElement(element);
			temp = driver.findElement(By.xpath(element));
			return temp;
		}

	}

	public void confirm_clickLabel(String labelName) {
		WebElement ele = findElementByLabel(labelName);
		try {
			if (ele.isDisplayed() && ele.isEnabled()) {
				ele.click();
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void enterTextWithTheHelpOfLabel(String labelName, String value) {
		boolean isFlagged = false;
		String labelXpath = "(//*[text()='" + labelName + "']/parent::* /td[//input[@type='text']]//input)|" + 
				"(//*[text()='" + labelName + "']/parent :: td/parent::* /td[//input[@type='text']]//input)|" + 
				"(//*[starts-with(normalize-space(text()),'" + labelName + "')]/parent:: td/parent::* /td[//input[@type='text']]//input)|" + 
				"(//*[starts-with(normalize-space(text()),'" + labelName + "')]/parent::td/parent::* /td[//input[@type='text']]//input)|" + 
				"(//*[starts-with(normalize-space(text()),'" + labelName	+ "')]/parent::*/td[//input[@type='text']]//input)|" + 
				"(//input[contains(@placeholder,'" + labelName+ "' or (//*[contains(@id,'test')]))])";
		waitForAnElement(labelXpath);
		WebElement textBox = driver.findElement(By.xpath(labelXpath));
		if (textBox.isDisplayed()) {
			isFlagged = true;
			textBox.click();
			textBox.clear();
			textBox.sendKeys(value);
		}
	}

	public void waitForAnElement(String element) {
		try {
			WebDriverWait wait = new WebDriverWait(driver, 10);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(element)));
		} catch (Exception e) {
			System.out.println(e.getMessage());
			Assert.fail(element + " Element not found ");
		}
	}

	public void clickCheckBoxWhereChoiceByIDorName(String checkBoxIDorName) {
		boolean flag = false;
		while (!flag) {
			try {
				WebElement checkBoxelement = driver.findElement(By.xpath("((//input[@id='" + checkBoxIDorName
						+ "')|(//input[@name='" + checkBoxIDorName + "' and @type='checkbox']"));
				checkBoxelement.click();
				if (checkBoxelement.getAttribute("selected") != null) {
					flag = true;
					break;
				}
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	
	
	public void clickRadioButtonWhereChoiceByIDorName(String radioButtonName) {
			try {
				WebElement radioButtonElelemt = driver.findElement(By.xpath("//input[(@value='"+radioButtonName+"' or @name='"+radioButtonName+"') and @type='radio']"));
				if(radioButtonElelemt.isDisplayed()) { 
					radioButtonElelemt.click();
				}
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
		}
	}
	public void selectValueFromDropdown(String dropdown, String value) {

		Select sel = new Select(findElementByLabel(dropdown));
		List<WebElement> list = sel.getOptions();
		for (int i = 0; i < list.size(); i++) {
			if (value.equalsIgnoreCase(list.get(i).getText())) {
				sel.selectByIndex(i);
			}
		}
	}

	public void SelectingValWithHelpOfLabel(String labelName, String dropDownVal) {
		boolean flaf=false;
		WebElement dropDownLable=driver.findElement(By.xpath("(//*[text()='"+labelName+"']/parent::*/td//select)|"
				+ "(//*[starts-with(normalize-space(text()),'"+labelName+"')]/parent:: td/parent :: tr/td/select)|"
				+ "//*[starts-with(normalize-space(text()),'"+labelName+"')]/parent :: tr/td[3]/select)"));
		if(dropDownLable.isDisplayed()) {
			Select sel = new Select(dropDownLable);
			List<WebElement> listOfDropDownValues = sel.getOptions();
			for (int i = 0; i < listOfDropDownValues.size(); i++) {
				if (dropDownVal.equalsIgnoreCase(listOfDropDownValues.get(i).getText())) {
					sel.selectByIndex(i);
				}
			}
		}
		
	}
	public void selectValueFromDropdownWithClick(String dropdown, String value) {

		try {
			WebElement ele = findElementByLabel(dropdown);
			ele.click();
			WebElement dropdownValue = findElementByLabel(value);
			System.out.println("Debug");
			Thread.sleep(8000);
			dropdownValue.click();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	public String chengeToDecimalValue(String val) {
		double value=Integer.parseInt(val);
		BigDecimal bd = new BigDecimal(value);
		DecimalFormatSymbols symbols = DecimalFormatSymbols.getInstance();
		DecimalFormat formatter = new DecimalFormat("###,###.##", symbols);
		String actualsPaystubDecimal = formatter.format(bd.longValue());
		return actualsPaystubDecimal;
	}

}