package com.bki.ot.uwa.automation.stepdefinitions;

import java.util.concurrent.TimeUnit;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.WebDriverWait;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.bki.ot.uwa.automation.extentreport.ExtentReportConfig;
import com.bki.ot.uwa.automation.pageobjects.GenericPage;
import com.bki.ot.uwa.automation.pageobjects.IncomeVarificationTab;
import com.bki.ot.uwa.automation.pageobjects.LoanLandingPage;
import com.bki.ot.uwa.automation.pageobjects.LoanOverview;
import com.bki.ot.uwa.automation.pageobjects.MyPipelinePage;
import com.bki.ot.uwa.automation.testcontext.TestContext;
import io.cucumber.core.api.Scenario;
import io.cucumber.java.After;
import io.cucumber.java.Before;

public class Hooks extends ExtentReportConfig {

	TestContext textContext;
	WebDriver driver;
	public static ExtentTest test;
	public Scenario scenario;
	public static String currentscenario;
	public static String featureName;
	public JavascriptExecutor js;
	public WebDriverWait wait;
	public Actions actions;
	public static ExtentReports extent = null;
	String url = null;
	GenericPage gp;
	MyPipelinePage mp;
	CommonMethods cm;
	LoanLandingPage lp;
	IncomeVarificationTab iv;
	LoanOverview lo;
	public static String loannum=null;

	public Hooks(TestContext textContext) {
		this.textContext = textContext;
		driver = textContext.getBaseConfigInstance().getDriver();
		gp = textContext.getPageObjectManagerInstance().getGenericPage();
		mp = textContext.getPageObjectManagerInstance().getmyPipelinePage();
		cm = textContext.getPageObjectManagerInstance().getCommonMethods();
		lp = textContext.getPageObjectManagerInstance().getloanLandingPage();
		iv=textContext.getPageObjectManagerInstance().getIncomeVarificationTab();
		wait = new WebDriverWait(textContext.getBaseConfigInstance().getDriver(), 100);
		actions = new Actions(textContext.getBaseConfigInstance().getDriver());
		lo=textContext.getPageObjectManagerInstance().getLoanOverview();
	}

	@Before
	public void setup(Scenario scenario) {
		try {
			this.scenario = scenario;
			currentscenario = scenario.getName();
			String rawFeatureName = scenario.getId().split(";")[0].replace("-", " ");
			featureName = rawFeatureName.substring(0, 1).toUpperCase() + rawFeatureName.substring(1);
			extent = extentRepotSetup();
			driver.manage().window().maximize();
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	
	
	
	public String getScenarioName() {
		return currentscenario;
	}

	public String getFeatureFileNameFromScenarioId() {
		return featureName;
	}

	
	@After
	public void DriverClose() {
		if (driver != null) {
			driver.quit();
		}
		extent.flush();
	}
	
	
}
