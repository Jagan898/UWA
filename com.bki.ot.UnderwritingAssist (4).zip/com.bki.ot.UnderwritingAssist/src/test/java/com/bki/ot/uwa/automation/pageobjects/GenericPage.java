package com.bki.ot.uwa.automation.pageobjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class GenericPage {
	WebDriver driver;

	public GenericPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);

	}

	
	@FindBy(xpath = "(//*[@class='pipeline-container']/h1 | //*[@class='loan__number'])")
	public WebElement GenericPage_PageTitle;

	@FindBy(xpath = "//*[@id='userNameInput']")
	public WebElement GenericPage_Username;

	@FindBy(xpath = "//*[@id='passwordInput']")
	public WebElement GenericPage_Password;

	@FindBy(xpath = "//*[@id='openingMessage']")
	public WebElement GenericPage_Signout_page;

	@FindBy(xpath = "//*[@id='errorText']")
	public WebElement GenericPage_LoginError_Msg;

	@FindBy(xpath = "//*[@id='submitButton']")
	public WebElement GenericPage_Signin_button;

	@FindBy(xpath = "//*[@class='header-container']/following::*[contains(text(),'Log-out')]")
	public WebElement GenericPage_Logout;

	@FindBy(xpath = "//*[@class='header-container']/descendant::*[@data-icon='caret-down']")
	public WebElement GenericPage_UserName_dropdown_option;

	@FindBy(xpath = "//*[@class='model-header']")
	public WebElement GenericPage_Upload_PopUp_title;
	@FindBy(xpath = "//*[@class='user-nav__user']/descendant::span[contains(@class,'user-name')]")
	public WebElement Username_Underwriter;
	
	@FindBy(xpath = "(//*[contains(text(),'CANCEL')])[1]")
	public WebElement Genericpage_Cancel_button;
	
	@FindBy(xpath = "//*[contains(text(),'SAVE')]")
	public WebElement Genericpage_Save_button;
	
	@FindBy(xpath = "//div[@class='table-top-bar']")
	public WebElement GenericPage_countOfLoanNumbersList;
	
	
	
	
	
	

}
