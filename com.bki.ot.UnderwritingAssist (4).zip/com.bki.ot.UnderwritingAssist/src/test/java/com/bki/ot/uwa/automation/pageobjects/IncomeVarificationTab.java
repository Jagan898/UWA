package com.bki.ot.uwa.automation.pageobjects;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class IncomeVarificationTab {
	WebDriver driver;

	public IncomeVarificationTab(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);

	}


	/************************IncomeVerivication**************************/
	
	
	@FindBy(xpath = "//table/tbody/tr/td[4]")
	public List<WebElement> IncomeInformationTab_ListOfColumnsInIncoVerificationtable;
	
	@FindBy(xpath = "//button[@class='btn thumbnail__grid active']")
	public WebElement LoanLandingPage_DocumentsTab_GridView;
	
	
	@FindBy(xpath = "//table/tbody/tr/td[contains(text(),'Borrower')]/parent::tr/td[6]")
	public List<WebElement> IncomeInformationTab_ListOfPayStubValues;
	
	
	@FindBy(xpath = "//table/tbody/tr/td[contains(text(),'Borrower')]")
	public List<WebElement> IncomeInformationTab_AvailableListOfBorrowers;
}
