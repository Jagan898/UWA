package com.bki.ot.uwa.automation.stepdefinitions;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.GherkinKeyword;
import com.aventstack.extentreports.Status;
import com.bki.ot.uwa.automation.extentreport.ExtentReportConfig;
import com.bki.ot.uwa.automation.filereadermanager.FileReaderManager;
import com.bki.ot.uwa.automation.testcontext.TestContext;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class LoanOverviewTabStepDef extends ExtentReportConfig {

	Hooks hook;
	TestContext testContext;
	String url = null;
	public static String fname;
	Boolean iselementpresent1 = false;

	public LoanOverviewTabStepDef(TestContext context) {
		testContext = context;
		hook = new Hooks(context);
		url = FileReaderManager.getFileReaderManagerInstance().getConfigInstance().getUrl();

	}
	
	@Then("^Displays the count of income variances at \"(.*)\" widget$")
	public void displays_the_count_of_income_variances_at_Variances(String variances) throws Exception {
		ExtentTest loginfo = null;
		try {
			loginfo = test.createNode(new GherkinKeyword("When"), "Displays the count of income variances at "+variances+" widget");
			hook.wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='loanreview-container']//div[contains(text(),'"+variances+"')]")));
			if(hook.driver.findElement(By.xpath("//div[@class='loanreview-container']//div[contains(text(),'"+variances+"')]")).isDisplayed()) {
				String vaiancesUI=hook.driver.findElement(By.xpath("//div[@class='loanreview-container']//div[contains(text(),'"+variances+"')]/following-sibling::div")).getText();
				loginfo.log(Status.PASS, variances+" is Displayed and count is" + vaiancesUI);		
			}			
		} catch (Exception e) {
			fname = hook.cm.addScreenshot(testContext);
			loginfo.log(Status.FAIL, e.getMessage());
			loginfo.addScreenCaptureFromPath(fname);

		}	
	}
	@And("^Displays red color circle with exclamatory icon$")
	public void displays_red_color_circle_with_exclamatoryIcon() throws Exception {
		ExtentTest loginfo = null;
		try {
			loginfo = test.createNode(new GherkinKeyword("And"), "Displays red color circle with exclamatory icon");
			if(hook.lo.LoanLandingPage_LoanOverview_exclamation_circle.isDisplayed()) {
				loginfo.log(Status.PASS, " Displayed exclamatory icon");
			}else {
				loginfo.log(Status.FAIL, " Not Displayed exclamatory icon");
			}
			
			String color=hook.lo.LoanLandingPage_LoanOverview_exclamation_circle.getCssValue("color");
			//hexa code for red is rgba(219, 55, 44, 1)
			if(color.contains("rgba(219, 55, 44, 1)")) {
				loginfo.log(Status.PASS, " Displayed exclamatory icon in RED color");
			}else {
				loginfo.log(Status.FAIL, " Not Displayed exclamatory icon in RED color");
			}
			
		} catch (Exception e) {
			fname = hook.cm.addScreenshot(testContext);
			loginfo.log(Status.FAIL, e.getMessage());
			loginfo.addScreenCaptureFromPath(fname);
		}	
	}
	@And("^Displays blue color with list-ol icon$")
	public void displays_blue_color_with_listIcon() throws Exception {
		ExtentTest loginfo = null;
		try {
			loginfo = test.createNode(new GherkinKeyword("And"), "Displays red color circle with exclamatory icon");
			if(hook.lo.LoanLandingPage_LoanOverview_list_ol_icon.isDisplayed()) {
				loginfo.log(Status.PASS, " Displayed exclamatory icon");
			}else {
				loginfo.log(Status.FAIL, " Not Displayed exclamatory icon");
			}		
			String color=hook.lo.LoanLandingPage_LoanOverview_list_ol_icon.getCssValue("color");
			//hexa code for blue rgba(0, 116, 217, 1)
			if(color.contains("rgba(0, 116, 217, 1)")) {
				loginfo.log(Status.PASS, " Displayed list ol icon in BLUE color");
			}else {
				loginfo.log(Status.FAIL, " Not Displayed list ol icon in BLUE color");
			}			
		} catch (Exception e) {
			fname = hook.cm.addScreenshot(testContext);
			loginfo.log(Status.FAIL, e.getMessage());
			loginfo.addScreenCaptureFromPath(fname);
		}
	}
		
@Then("^Loan Progress displays completion Percentage as per open conditions divided by sum of  open \"(.*)\" and closed \"(.*)\" conditions$")
public void validate_LoanProgress_Percentage(String incomeVariances, String clearedVariances) throws Exception {
	ExtentTest loginfo = null;
	try {
		loginfo = test.createNode(new GherkinKeyword("Then"), "Loan Progress displays completion Percentage as per open conditions divided by sum of  open "+incomeVariances+" and closed "+clearedVariances+" conditions");
		hook.wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@role='tablist']//span[text()='"+incomeVariances+"']")));
		int progressPercentageFronConditionTab=0;
		if(hook.driver.findElement(By.xpath("//*[@role='tablist']//span[text()='"+incomeVariances+"']")).isDisplayed()) {
			loginfo.log(Status.INFO, "Navigated to Conditions tab");
			String incomeOpenConditions=hook.driver.findElement(By.xpath("//*[@role='tablist']//span[text()='"+incomeVariances+"']/following-sibling::span")).getText();
			int openconditions=Integer.parseInt(incomeOpenConditions);
			String clearedConditions=hook.driver.findElement(By.xpath("//*[@role='tablist']//span[text()='"+clearedVariances+"']/following-sibling::span")).getText();
			int clearconditions=Integer.parseInt(clearedConditions);
			progressPercentageFronConditionTab=(clearconditions/(clearconditions+openconditions))*100;
		}
		hook.driver.findElement(By.xpath("//*[text()='Loan Overview']")).click();
		hook.actions.pause(2000).build().perform();
		String vaiancesProgress=hook.driver.findElement(By.xpath("//div[@class='loanreview-container']//div[contains(text(),'Loan Progress')]/following-sibling::div")).getText().replace("%", "");
		int loanProgress=Integer.parseInt(vaiancesProgress);
		if(loanProgress==progressPercentageFronConditionTab)
		loginfo.log(Status.PASS, progressPercentageFronConditionTab+" is Displayed as per open conditions divided by sum of  open "+incomeVariances+" and closed "+clearedVariances+" conditions");
	} catch (Exception e) {
		fname = hook.cm.addScreenshot(testContext);
		loginfo.log(Status.FAIL, e.getMessage());
		loginfo.addScreenCaptureFromPath(fname);
	}
}

@Then("^Below UI elements should be same as per wireframe specified dimension$")
public void verify_Elements_SpecifiedDimensions(DataTable elements) throws Exception {

	ExtentTest loginfo = null;
	try {
		loginfo = test.createNode(new GherkinKeyword("Then"), "Below UI elements should be same as per wireframe specified dimension");
		List<String> objects=elements.asList(String.class);	
		for(int i=0;i<objects.size();i++) {
			String height=hook.driver.findElement(By.xpath("//div[text()='"+objects.get(i)+"']/ancestor::mat-card")).getCssValue("height");
			String width=hook.driver.findElement(By.xpath("//div[text()='"+objects.get(i)+"']/ancestor::mat-card")).getCssValue("width");
			String margin_bottom=hook.driver.findElement(By.xpath("//div[text()='"+objects.get(i)+"']/ancestor::mat-card")).getCssValue("margin-bottom");
			if(height.contains("112px")&width.contains("310px")&margin_bottom.contains("24px")) {
				loginfo.log(Status.PASS, objects.get(i)+" contains height as "+height+" and width as"+width+" margin as "+margin_bottom);
				loginfo.log(Status.INFO, objects.get(i)+" contains valid widgets");
			}
		}
	} catch (Exception e) {
		fname = hook.cm.addScreenshot(testContext);
		loginfo.log(Status.FAIL, e.getMessage());
		loginfo.addScreenCaptureFromPath(fname);
	}

}
}
