package com.bki.ot.uwa.automation.stepdefinitions;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.GherkinKeyword;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.gherkin.model.Feature;
import com.aventstack.extentreports.gherkin.model.Scenario;
import com.bki.ot.uwa.automation.extentreport.ExtentReportConfig;
import com.bki.ot.uwa.automation.filereadermanager.FileReaderManager;
import com.bki.ot.uwa.automation.testcontext.TestContext;
import com.google.common.collect.Ordering;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.And;
import io.cucumber.java.en.When;
import io.cucumber.datatable.DataTable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;


public class GenericStepDef extends ExtentReportConfig {

	Hooks hook;
	TestContext testContext;
	String url = null;
	public static String fname;
	public String loanListTextAfterCancel = "";

	public GenericStepDef(TestContext context) {
		testContext = context;
		hook = new Hooks(context);
		url = FileReaderManager.getFileReaderManagerInstance().getConfigInstance().getUrl();

	}
	
	@Given("^Launch UWA URL$")
	public void LaunchUWAURL() throws Exception {
		ExtentTest loginfo = null;
		try {
			test = extent.createTest(Scenario.class, hook.getScenarioName())
					.createNode(Feature.class, hook.getFeatureFileNameFromScenarioId())
					.createNode(Scenario.class, hook.getScenarioName());
			loginfo = test.createNode(new GherkinKeyword("Given"), "Launch UWA URL");
			JavascriptExecutor js = (JavascriptExecutor) hook.driver;
			js.executeScript(url);
			loginfo.log(Status.PASS, "URL Launched successfully");
			String Browser = System.getProperty("browserType");
			String BrowserOption = System.getProperty("chromeOptionsArg");
			loginfo.log(Status.INFO, "Browser Type : " + Browser);
			if ("--headless".equalsIgnoreCase(BrowserOption)) {
				loginfo.log(Status.INFO, "Browser Option :" + BrowserOption);
			}
		} catch (Exception e) {
			fname = hook.cm.addScreenshot(testContext);
			loginfo.log(Status.FAIL, "URL not launched successfully");
			loginfo.addScreenCaptureFromPath(fname);

		}

	}

	@When("^Verify user is on \"(.*)\" page$")
	public void VerifyUserIsOn(String title) throws Exception {
		ExtentTest loginfo = null;		
		String actualText=null;
		try {
			loginfo = test.createNode(new GherkinKeyword("When"), "Verify user is on " + title + " page");
			hook.actions.pause(4000).build().perform();
			hook.wait.until(ExpectedConditions.visibilityOf(hook.gp.GenericPage_PageTitle));
			actualText = hook.gp.GenericPage_PageTitle.getText();
			Assert.assertEquals(title.trim(), actualText.trim());
			loginfo.log(Status.PASS, "Successfully user is on " + actualText + " page");
		} catch (AssertionError e) {
			fname = hook.cm.addScreenshot(testContext);
			loginfo.log(Status.FAIL, "user is on " + title + " page" + e);
			loginfo.addScreenCaptureFromPath(fname);
		}
	}
	
	@And("User should be able to verify \"(.*)\" text containing$")
	public void test(String message) throws Exception {
		ExtentTest loginfo = null;
		try {
			loginfo = test.createNode(new GherkinKeyword("Then"), message + " message should display");
			String actualMessage = hook.driver.findElement(By.xpath("//*[contains(text(),'" + message + "')]"))
					.getText();
			if(actualMessage.trim().contains(actualMessage)) {
				loginfo.log(Status.PASS, "Expected Message is displayed " + actualMessage);
			}else {
				loginfo.log(Status.FAIL, "Expected Message is not displayed " + actualMessage);
			}
			
		} catch (AssertionError e) {
			fname = hook.cm.addScreenshot(testContext);
			loginfo.log(Status.FAIL, "Fail- Popup message is not displayed" + e.getMessage());
			loginfo.addScreenCaptureFromPath(fname);
		}

	
	}

	@Then("^Data Grid Headers should display$")
	public void DataGridHeadersShouldDisplay(DataTable dt) throws Exception {
		ExtentTest loginfo = null;
		try {
			loginfo = test.createNode(new GherkinKeyword("Then"), "Data Grid Headers should display");
			List<String> list = dt.asList(String.class);
			for (int j = 0; j < list.size(); j++) {
				if (list.get(j).equalsIgnoreCase(hook.mp.Mypipelinepage_GridHeader_list.get(j).getText())) {
					loginfo.log(Status.PASS,
							"Grid Header field displayed : " + hook.mp.Mypipelinepage_GridHeader_list.get(j).getText());

				} else {
					loginfo.log(Status.FAIL, MarkupHelper
							.createLabel("Grid Header field not displayed : " + list.get(j), ExtentColor.RED));
				}
			}
			if (list.size() == hook.mp.Mypipelinepage_GridHeader_list.size()) {
				loginfo.log(Status.PASS, "All the Grid header fields displayed");
			} else {
				loginfo.log(Status.FAIL, "All the Grid header fields not displayed");
			}

		} catch (Exception e) {
			fname = hook.cm.addScreenshot(testContext);
			loginfo.log(Status.FAIL, e.getMessage());
			loginfo.addScreenCaptureFromPath(fname);

		}

	}

	@And("^Tabs should display in Mypipeline page$")
	public void TabsShouldDisplayInMypipelinePage(DataTable dt) throws Exception {
		ExtentTest loginfo = null;
		try {
			loginfo = test.createNode(new GherkinKeyword("And"), "Tabs should display in Mypipeline page");
			List<String> list = dt.asList(String.class);
			Assert.assertTrue(
					list.get(0).equalsIgnoreCase(hook.mp.Mypipelinepage_TabActiveInActive_list.get(0).getText()) && list
							.get(1).equalsIgnoreCase(hook.mp.Mypipelinepage_TabActiveInActive_list.get(1).getText()));
			loginfo.log(Status.PASS,
					"Tab displayed  : " + hook.mp.Mypipelinepage_TabActiveInActive_list.get(0).getText());
			loginfo.log(Status.PASS,
					"Tab displayed  : " + hook.mp.Mypipelinepage_TabActiveInActive_list.get(1).getText());
		} catch (AssertionError e) {
			fname = hook.cm.addScreenshot(testContext);
			loginfo.log(Status.FAIL, "Verify Tabs displayed in mypipeline" + e.getMessage());
			loginfo.addScreenCaptureFromPath(fname);
		}
	}

	@Then("^Verify the sorting icons for grid headers$")
	public void Verifythesortingiconsforgridheaders() throws Exception {
		ExtentTest loginfo = null;
		try {
			
			loginfo = test.createNode(new GherkinKeyword("Then"), "Verify the sorting icons for grid headers");
			hook.wait.until(ExpectedConditions
					.visibilityOfAllElements(hook.mp.Mypipelinepage_SortIcons_list_Of_Headers));
			if(hook.mp.Mypipelinepage_SortIcons_list_Of_Headers.size()>0) {
				loginfo.log(Status.PASS, "Sorting Icons displayed in My Pipeline page");
			}
			if(hook.mp.Mypipelinepage_SortIcons_list_Of_Headers.size()==hook.mp.Mypipelinepage_Headers_list.size()) {
				loginfo.log(Status.PASS, "Sorting Icons displayed for all the Grid headers");
			}			
		} catch (AssertionError e) {
			fname = hook.cm.addScreenshot(testContext);
			loginfo.log(Status.FAIL,
					"Verify Sorting Icon and By default sorting highlighted at Loan numbers :" + e.getMessage());
			loginfo.addScreenCaptureFromPath(fname);
		}
	}

	@And("^Verify bydefault Loan number is displayed in ASC order$")
	public void VerifybydefaultLoannumberisdisplayedinASCorder() throws Exception {
		ExtentTest loginfo = null;
		try {
			loginfo = test.createNode(new GherkinKeyword("And"),
					"Verify bydefault Loan numbers is displayed in ASC order");
			hook.mp.Mypipelinepage_LoanNumber_Header.click();			
			String orderType=hook.mp.Mypipelinepage_SortingOrder_Type.getAttribute("aria-sort");
			if(orderType.contains("ascending")) {
				loginfo.log(Status.INFO, "LoanNumbers aligned in ascending order");
			}else {
				hook.mp.Mypipelinepage_LoanNumber_Header.click();	
				loginfo.log(Status.INFO, "LoanNumbers aligned in ascending order");
			}
			List<String> list = new ArrayList<String>();
			for (int i = 0; i < hook.mp.Mypipelinepage_Grid_LoanNumber_Data_list.size(); i++) {
				list.add(hook.mp.Mypipelinepage_Grid_LoanNumber_Data_list.get(i).getText());
			}
			Assert.assertTrue(Ordering.natural().isOrdered(list));
			loginfo.log(Status.PASS, "By Default the Loan numbers are displayed in Ascending order");
		} catch (AssertionError e) {
			fname = hook.cm.addScreenshot(testContext);
			loginfo.log(Status.FAIL,
					"Verify by Default the Loan numbers are displayed in Ascending order" + e.getMessage());
		
			loginfo.addScreenCaptureFromPath(fname);
		} catch (Exception e) {
			fname = hook.cm.addScreenshot(testContext);
			loginfo.log(Status.FAIL, e.getMessage());
			loginfo.addScreenCaptureFromPath(fname);

		}

	}
	@When("^Click on button contains text \"(.*)\" in page \"(.*)\"$")
	public void Clickonbuttoncontainstextinpage(String text, String pageTitle) throws Exception {
		ExtentTest loginfo = null;
		try {	
			loginfo = test.createNode(new GherkinKeyword("When"), "Click on button contains text " + text);			
			hook.wait.until(	
					ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[text()='" + text + "']|//*[normalize-space(text())='" + text + "']|//span[contains(text(),'" + text + "')]")));
			if(hook.driver.getTitle().trim().contains(pageTitle)|hook.driver.getTitle().trim().contains("UWA — Underwriting Assist")) {
				WebElement element=hook.driver.findElement(By.xpath("//*[text()='" + text + "']|//*[normalize-space(text())='" + text + "']|//span[contains(text(),'" + text + "')]"));
				JavascriptExecutor js = (JavascriptExecutor) hook.driver;
	            js.executeScript("arguments[0].click();", element);
				hook.actions.pause(3000).build().perform();
				loginfo.log(Status.INFO, "Successfully clicked on : " + text);
			}
			
		} catch (Exception e) {
			fname = hook.cm.addScreenshot(testContext);
			loginfo.log(Status.FAIL, e.getMessage());
			loginfo.addScreenCaptureFromPath(fname);
		}

	}
	
	@When("^Click on label text equals \"(.*)\"$")
	public void click_on_Label_Text_Contains(String label) throws Exception {

		ExtentTest loginfo = null;
		try {
			loginfo = test.createNode(new GherkinKeyword("When"), "Click on label name contains " + label);
			hook.wait.until(
					ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[text()='" + label + "']|//*[normalize-space(text())='" + label + "']")));
			hook.driver.findElement(By.xpath("//*[text()='" + label + "']|//*[normalize-space(text())='" + label + "']")).click();
			hook.actions.pause(3000).build().perform();
			loginfo.log(Status.PASS, "Successfully clicked on : " + label);
		} catch (Exception e) {
			fname = hook.cm.addScreenshot(testContext);
			loginfo.log(Status.FAIL, e.getMessage());
			loginfo.addScreenCaptureFromPath(fname);

		}

	
	}
	
	@When("^Click on \"(.*)\" button$")
	public void Clickonbuttoncontainstext(String text) throws Exception {
		ExtentTest loginfo = null;
		try {
			loginfo = test.createNode(new GherkinKeyword("When"), "Click on " + text +"button");
			hook.wait.until(

					ExpectedConditions.visibilityOfElementLocated(
							By.xpath("//*[text()='" + text + "'] | //span[contains(text(),'" + text + "')]")));

			hook.driver.findElement(By.xpath("//*[text()='" + text + "'] | //span[contains(text(),'" + text + "')]"))
					.click();
			hook.actions.pause(3000).build().perform();
			loginfo.log(Status.INFO, "Successfully clicked on : " + text);
		} catch (Exception e) {
			fname = hook.cm.addScreenshot(testContext);
			loginfo.log(Status.FAIL, e.getMessage());
			loginfo.addScreenCaptureFromPath(fname);

		}

	}

	@Then("^Click on Borrower sort-icon and verify sorted in DSC order$")
	public void ClickonBorrowersorticonandverifysortedinDSCASCorder() throws Exception {
		ExtentTest loginfo = null;
		try {
			loginfo = test.createNode(new GherkinKeyword("Then"),
					"Click on Borrower sort-icon and verify sorted in DSC order");
			hook.wait.until(ExpectedConditions
					.visibilityOfAllElements(hook.mp.Mypipelinepage_GridHeader_Asscending_Sorting_icon));
			hook.mp.Mypipelinepage_GridHeader_Asscending_Sorting_icon.get(1).click();
			hook.mp.Mypipelinepage_GridHeader_Asscending_Sorting_icon.get(1).click();
			hook.actions.pause(3000).build().perform();
			List<String> list = new ArrayList<String>();
			for (int i = 0; i < hook.mp.Mypipelinepage_Grid_BarrowerName_Data_list.size(); i++) {
				list.add(hook.mp.Mypipelinepage_Grid_BarrowerName_Data_list.get(i).getText());
			}
			boolean sorted = Ordering.natural().isOrdered(list);
			if (sorted != true) {
				loginfo.log(Status.PASS,
						"By clicking one Borrower sort icon first time Borrower name sorted in DSC order");
			} else {
				loginfo.log(Status.FAIL,
						"By clicking one Borrower sort icon first time Borrower name not sorted in DSC order");
			}
		} catch (Exception e) {
			fname = hook.cm.addScreenshot(testContext);
			loginfo.log(Status.FAIL, e.getMessage());
			loginfo.addScreenCaptureFromPath(fname);
		}
	}

	@And("^Again click on Borrower sort-icon and verify sorted in ASC order$")
	public void AgainclickonBorrowersorticonandverifysortedinASCorder() throws Exception {
		ExtentTest loginfo = null;
		try {
			loginfo = test.createNode(new GherkinKeyword("And"),
					"Again click on Borrower sort-icon and verify sorted in ASC order");
			hook.wait.until(
					ExpectedConditions.visibilityOfElementLocated(By.xpath("//table[contains(@class,'mat-table')]//th//span[contains(text(),'loan number')]")));
			hook.mp.Mypipelinepage_BorrowerLastName_Header.click();			
			String orderType=hook.mp.Mypipelinepage_SortingOrder_Type.getAttribute("aria-sort");
			if(orderType.contains("ascending")) {
				loginfo.log(Status.INFO, "LoanNumbers aligned in ascending order");
			}else {
				hook.mp.Mypipelinepage_BorrowerLastName_Header.click();	
				loginfo.log(Status.INFO, "LoanNumbers aligned in ascending order");
			}
			hook.actions.pause(1000).build().perform();
			List<String> list = new ArrayList<String>();
			for (int i = 0; i < hook.mp.Mypipelinepage_Grid_BarrowerName_Data_list.size(); i++) {
				list.add(hook.mp.Mypipelinepage_Grid_BarrowerName_Data_list.get(i).getText());
			}
			boolean sorted = Ordering.natural().isOrdered(list);
			loginfo.log(Status.INFO, "srt :" + sorted);
			if (sorted == true) {
				loginfo.log(Status.PASS, "By clicking one Borrower sort icon again Borrower name sorted in ASC order");
			} else {
				loginfo.log(Status.FAIL,
						"By clicking one Borrower sort icon again Borrower name not sorted in ASC order");
			}
		} catch (Exception e) {
			fname = hook.cm.addScreenshot(testContext);
			loginfo.log(Status.FAIL, e.getMessage());
			loginfo.addScreenCaptureFromPath(fname);
		}
	}

	@When("^Click on Tab \"(.*)\"$")
	public void ClickonTabActiveInActive(String tab) throws Exception {
		ExtentTest loginfo = null;
		try {
			loginfo = test.createNode(new GherkinKeyword("When"), "Click on Tab " + tab);
			hook.wait.until(ExpectedConditions.visibilityOfAllElements(hook.mp.Mypipelinepage_TabActiveInActive_list));

			if (hook.mp.Mypipelinepage_TabActiveInActive_list.get(1).getCssValue("color").substring(5, 21)
					.equals("204, 204, 204, 1")) {
				loginfo.log(Status.PASS, "When " + tab + " tab is not active the color displayed properly :"
						+ hook.mp.Mypipelinepage_TabActiveInActive_list.get(1).getCssValue("color"));
			} else {
				loginfo.log(Status.PASS, "When " + tab + " tab is not active the color not displayed properly :"
						+ hook.mp.Mypipelinepage_TabActiveInActive_list.get(1).getCssValue("color"));
			}
			for (int i = 0; i < hook.mp.Mypipelinepage_TabActiveInActive_list.size(); i++) {
				if (hook.mp.Mypipelinepage_TabActiveInActive_list.get(i).getText().equalsIgnoreCase(tab)) {
					loginfo.log(Status.PASS, "Successfull clicked on Tab : "
							+ hook.mp.Mypipelinepage_TabActiveInActive_list.get(i).getText());
					hook.mp.Mypipelinepage_TabActiveInActive_list.get(i).click();
					break;
				}
			}
			if (hook.mp.Mypipelinepage_TabActiveInActive_list.get(1).getCssValue("color").substring(5, 21)
					.equals("255, 255, 255, 1")) {
				loginfo.log(Status.PASS, "When " + tab + " tab is active the color displayed properly :"
						+ hook.mp.Mypipelinepage_TabActiveInActive_list.get(1).getCssValue("color"));
			} else {
				loginfo.log(Status.PASS, "When " + tab + " tab is active the color not displayed properly :"
						+ hook.mp.Mypipelinepage_TabActiveInActive_list.get(1).getCssValue("color"));
			}
		} catch (Exception e) {
			fname = hook.cm.addScreenshot(testContext);
			loginfo.log(Status.FAIL, e.getMessage());
			loginfo.addScreenCaptureFromPath(fname);
		}
	}

	@And("^Verify the Grid icons and Elipse option$")
	public void VerifytheGridiconsandElipseoption() throws Exception {
		ExtentTest loginfo = null;
		try {
			loginfo = test.createNode(new GherkinKeyword("And"), "Verify the Grid icons and Elipse option");
			hook.wait.until(ExpectedConditions.visibilityOfAllElements(hook.mp.Mypipelinepage_Grid_Elipseoption_List));
			if (hook.mp.Mypipelinepage_Grid_Elipseoption_List.isEmpty()
					&& hook.mp.Mypipelinepage_Grid_Bellicons_List.isEmpty()
					&& hook.mp.Mypipelinepage_Grid_Exclamation_Icon_List.isEmpty()) {
				loginfo.log(Status.FAIL, "Elipse options are not displayed in Grid" + "<br />"
						+ "Grid Missing docs icons and System analysis icons not available to display in data");
			} else {
				loginfo.log(Status.PASS, "Elipse options are displayed in Grid successfully" + "<br />"
						+ "Grid Missing docs icons and System analysis icons are available and displayed in data");
			}
			if (hook.mp.Mypipelinepage_GridResults_Message.getText().contains("Showing")) {
				loginfo.log(Status.PASS, "Grid results message displayed successfully");
			} else {
				loginfo.log(Status.FAIL, "Grid results message not displayed");
			}
		} catch (Exception e) {
			fname = hook.cm.addScreenshot(testContext);
			loginfo.log(Status.FAIL, e.getMessage());
			loginfo.addScreenCaptureFromPath(fname);
		}
	}

	@Then("^Click on menu collapse icon and verify collapse mode$")
	public void Clickonmenucollapseiconandverifycollapsemode() throws Exception {
		ExtentTest loginfo = null;
		try {
			loginfo = test.createNode(new GherkinKeyword("Then"),
					"Click on menu collapse icon and verify collapse mode");
			hook.wait.until(ExpectedConditions.visibilityOf(hook.mp.Mypipelinepage_Menu_CollapseExpand_Icon));
			loginfo.log(Status.INFO,
					"Before collapsing menu width: " + hook.mp.Mypipeline_menu_sidebar.getSize().width);

			hook.mp.Mypipelinepage_Menu_CollapseExpand_Icon.click();
			hook.actions.pause(5000).build().perform();
			try {
				if (hook.mp.Mypipeline_menu_sidebar.getSize().width == 76) {

					loginfo.log(Status.PASS, "By clicking on Menu collapse Icon Menu section collapsed and width : "
							+ hook.mp.Mypipeline_menu_sidebar.getSize().width);
				}
			} catch (Exception e) {
				loginfo.log(Status.FAIL, "By clicking on Menu collapse Icon Menu section not collapsed");
			}

		} catch (Exception e) {
			fname = hook.cm.addScreenshot(testContext);
			loginfo.log(Status.FAIL, e.getMessage());
			loginfo.addScreenCaptureFromPath(fname);
		}
	}

	@And("^Again click on menu Expand icon verify Expand mode$")
	public void AgainclickonmenuExpandiconverifyExpandmode() throws Exception {
		ExtentTest loginfo = null;
		try {
			loginfo = test.createNode(new GherkinKeyword("Then"), "Again click on menu Expand icon verify Expand mode");
			hook.wait.until(ExpectedConditions.visibilityOf(hook.mp.Mypipelinepage_Menu_CollapseExpand_Icon));
			hook.mp.Mypipelinepage_Menu_CollapseExpand_Icon.click();
			try {
				if (hook.mp.Mypipelinepage_Menu_section.isDisplayed()) {
					loginfo.log(Status.PASS, "Again clicking on Menu collapse Icon Menu section Expanded successfully");

				}
			} catch (Exception e) {
				loginfo.log(Status.FAIL, "Again clicking on Menu collapse Icon Menu section not Expanded");
			}
		} catch (Exception e) {
			fname = hook.cm.addScreenshot(testContext);
			loginfo.log(Status.FAIL, e.getMessage());
			loginfo.addScreenCaptureFromPath(fname);
		}

	}

	@Then("^verify the footer information$")
	public void verifythefooterinformation() throws Exception {
		ExtentTest loginfo = null;
		try {
			loginfo = test.createNode(new GherkinKeyword("Given"), "Verify footer in pipelinepage");
			hook.actions.pause(5000).build().perform();
			hook.wait.until(ExpectedConditions.visibilityOf(hook.mp.Mypipelinepage_footer));
			try {
				List<String> exp = Arrays.asList("© WeBank 2020", "Terms | Privacy Notice", "1-800-555-1234");
				for (int i = 0; i < hook.mp.Mypipelinepage_footer_list.size(); i++) {
					if (hook.mp.Mypipelinepage_footer_list.get(i).getText().equalsIgnoreCase(exp.get(i)))

					{
						loginfo.log(Status.PASS,
								"footer information is valid " + hook.mp.Mypipelinepage_footer_list.get(i).getText());

					}

				}
			} catch (Exception e) {

				loginfo.log(Status.FAIL, "footer information is invalid ");

			}
		}

		catch (Exception e) {
			fname = hook.cm.addScreenshot(testContext);
			loginfo.log(Status.FAIL, e.getMessage());
			loginfo.addScreenCaptureFromPath(fname);
		}

	}

	@When("^user should hover mouse on menu items$")
	public void usershouldhovermouseonmenuitems() throws Exception {
		ExtentTest loginfo = null;
		try {
			loginfo = test.createNode(new GherkinKeyword("When"), "\"user should hover mouse on menu items");
			hook.wait.until(ExpectedConditions.visibilityOfAllElements(hook.mp.Mypipelinepage_Menu_section));
			hook.actions.moveToElement(hook.mp.Mypipeline_menu_pipeline).perform();
			loginfo.log(Status.PASS, "Mouse hovered to element");
		} catch (Exception e) {

			fname = hook.cm.addScreenshot(testContext);
			loginfo.log(Status.FAIL, "Mouse not hovered to element");
			loginfo.addScreenCaptureFromPath(fname);

		}
	}

	@Then("^verify elements get highlited upon mousehover$")
	public void verifyelementsgethighliteduponmousehover() throws Exception {
		ExtentTest loginfo = null;
		try {
			loginfo = test.createNode(new GherkinKeyword("Then"), "verify elements get highlited upon mousehover ");
			hook.wait.until(ExpectedConditions.visibilityOfAllElements(hook.mp.Mypipelinepage_Menu_section));
			Assert.assertTrue(hook.mp.Mypipeline_menu_pipeline.getCssValue("background-color").substring(5, 18)
					.equals("43, 46, 76, 1"));
			loginfo.log(Status.PASS, "Element is getting highlited");
		} catch (AssertionError e) {
			fname = hook.cm.addScreenshot(testContext);
			loginfo.log(Status.FAIL, "Element is not getting highlited");
			loginfo.addScreenCaptureFromPath(fname);

		}

	}
	
	@Then("^Wait for \"(.*)\" seconds to synchronize page$")
	public void waitForPageToSynhronize(String seconds) {
		try {
			for(int i=0;i<Integer.parseInt(seconds);i++)
			Thread.sleep(1000);
		}catch(Exception e) {
			e.printStackTrace();
		}
	}

	@Then("^Enter \"(.*)\" in \"(.*)\" field$")
	public void enterValueInEditbox(String text, String field) throws Exception {
		ExtentTest loginfo = null;
		try {
			loginfo = test.createNode(new GherkinKeyword("Then"), "Enter "+text+" in "+field+" field");
			hook.wait.until(ExpectedConditions.visibilityOf(hook.driver.findElement(By.xpath("//*[@placeholder='"+field+"']"))));
			if(hook.driver.findElement(By.xpath("//*[@placeholder='"+field+"']")).isDisplayed()) {
				loginfo.log(Status.PASS, field+" Element is available to enter text");
				hook.driver.findElement(By.xpath("//*[@placeholder='"+field+"']")).clear();
				hook.driver.findElement(By.xpath("//*[@placeholder='"+field+"']")).sendKeys(text);
			}else {
				loginfo.log(Status.FAIL, field+" Element not is available to enter text");
			}
			
		} catch (AssertionError e) {
			fname = hook.cm.addScreenshot(testContext);
			loginfo.log(Status.FAIL, "Element is not getting highlited");
			loginfo.addScreenCaptureFromPath(fname);

		}

	
	}
	
	@Then("^Enter values in text field as per below fieldName and value$")
	public void enter_values_as_per_below_field_and_value(DataTable textBoxes) throws Exception {
		ExtentTest loginfo = null;
		try {
			loginfo = test.createNode(new GherkinKeyword("Then"), "Enter values as per below field and value");
			List<Map<String, String>>list = textBoxes.asMaps(String.class, String.class);
            for (Map<String, String> data : list) {             
                   Set<String> keys=data.keySet();
                   Iterator<String> it = keys.iterator();
                   while(it.hasNext()) {
                         String textBoxfieldName=it.next();
                         String textBoxFieldvalue=data.get(textBoxfieldName); 
                         hook.wait.until(ExpectedConditions.visibilityOf(hook.driver.findElement(By.xpath("//*[@placeholder='"+textBoxfieldName+"']"))));
             			if(hook.driver.findElement(By.xpath("//*[@placeholder='"+textBoxfieldName+"']")).isDisplayed()) {
             				loginfo.log(Status.PASS, textBoxfieldName+" Element is available to enter text");
             				loginfo.log(Status.INFO, "Entered "+textBoxFieldvalue+": in "+textBoxfieldName.toUpperCase()+ "Text box");
             				hook.driver.findElement(By.xpath("//*[@placeholder='"+textBoxfieldName+"']")).clear();
             				hook.driver.findElement(By.xpath("//*[@placeholder='"+textBoxfieldName+"']")).sendKeys(textBoxFieldvalue);
             			}else {
             				loginfo.log(Status.FAIL, textBoxfieldName+" Element not is available to enter the text");
             			}
                   }
            }

		} catch (AssertionError e) {
			fname = hook.cm.addScreenshot(testContext);
			loginfo.log(Status.FAIL, "Element is not getting highlited");
			loginfo.addScreenCaptureFromPath(fname);

		}
	}
	
	@When("^Click on \"(.*)\" button in page \"(.*)\"$")
	public void ClickOnCancelButton(String text, String pageTitle) throws Exception {
		ExtentTest loginfo = null;
		try {
			loginfo = test.createNode(new GherkinKeyword("When"), "Click on " + text +"button");
			hook.wait.until(

					ExpectedConditions.visibilityOfElementLocated(
							By.xpath("//button[contains(@class,'mat-focus-indicator cancel')]//span[contains(text(),'CANCEL')]")));

			hook.driver.findElement(By.xpath("//button[contains(@class,'mat-focus-indicator cancel')]//span[contains(text(),'CANCEL')]"))
					.click();
			hook.actions.pause(3000).build().perform();
			loginfo.log(Status.INFO, "Successfully clicked on : " + text);
			hook.driver.findElement(By.xpath("//span[contains(text(),'Cancel Upload')]")).click();
			hook.actions.pause(3000).build().perform();
			loanListTextAfterCancel = hook.gp.GenericPage_countOfLoanNumbersList.getText();
			System.out.println(loanListTextAfterCancel);
			if(ImportFileStepDef.loanListText.equalsIgnoreCase(loanListTextAfterCancel)) {
				System.out.println("Loan Upload has been cancelled");
			}
		} catch (Exception e) {
			fname = hook.cm.addScreenshot(testContext);
			loginfo.log(Status.FAIL, e.getMessage());
			loginfo.addScreenCaptureFromPath(fname);

		}

	}
}