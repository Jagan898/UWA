package com.bki.ot.uwa.automation.stepdefinitions;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.GherkinKeyword;
import com.aventstack.extentreports.Status;
import com.bki.ot.uwa.automation.extentreport.ExtentReportConfig;
import com.bki.ot.uwa.automation.filereadermanager.FileReaderManager;
import com.bki.ot.uwa.automation.testcontext.TestContext;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class ImportFileStepDef extends ExtentReportConfig {

	Hooks hook;
	TestContext testContext;
	String url = null;
	public static String fname;
	public static String loanListText = "";

	public ImportFileStepDef(TestContext context) {
		testContext = context;
		hook = new Hooks(context);
		url = FileReaderManager.getFileReaderManagerInstance().getConfigInstance().getUrl();

	}

	@And("^Click on New Loan verify pop UploadYourLoanFiles display$")
	public void ClickonNewLoanverifypopUploadYourLoanFilesdisplay() throws Exception {
		ExtentTest loginfo = null;
		try {
			loginfo = test.createNode(new GherkinKeyword("And"),
					"Click on New Loan verify pop UploadYourLoanFiles display");
			hook.actions.pause(8000).build().perform();
			hook.wait.until(ExpectedConditions.visibilityOf(hook.mp.Mypipelinepage_NewLoan_button));
			hook.mp.Mypipelinepage_NewLoan_button.click();
			hook.wait.until(ExpectedConditions.visibilityOf(hook.gp.GenericPage_Upload_PopUp_title));
			loginfo.log(Status.PASS, "Utest: " + hook.gp.GenericPage_Upload_PopUp_title.getText());
			if (hook.gp.GenericPage_Upload_PopUp_title.getText().equalsIgnoreCase("Upload Your Loan Files")) {
				loginfo.log(Status.PASS,
						"Upload PopUp title displayed properly: " + hook.gp.GenericPage_Upload_PopUp_title.getText());
			} else {
				loginfo.log(Status.FAIL,
						"Upload PopUp title not displayed : " + hook.gp.GenericPage_Upload_PopUp_title.getText());
			}
		} catch (Exception e) {
			fname = hook.cm.addScreenshot(testContext);
			loginfo.log(Status.FAIL, e.getMessage());
			loginfo.addScreenCaptureFromPath(fname);
		}
	}

	@And("^User selects Browse 3.4 file \"(.*)\"$")
	public void UserselectsBrowsefile(String filename) throws Exception {
		ExtentTest loginfo = null;
		try {
			loginfo = test.createNode(new GherkinKeyword("And"), "User selects Browse 3.4 file"+filename);
			hook.actions.pause(5000).build().perform();
			hook.wait.until(ExpectedConditions.visibilityOf(hook.gp.GenericPage_Upload_PopUp_title));
			String path = System.getProperty("user.dir") + "/src/test/resources/files/" + filename;
			hook.driver.findElement(By.xpath("//input[@type='file']")).sendKeys(path);
			loginfo.log(Status.INFO, "file selected successfully");
			hook.actions.pause(20000).build().perform();
			hook.wait.until(ExpectedConditions.visibilityOf(hook.mp.Mypipelinepage_UploadPopup_Save_button));
			hook.wait.until(ExpectedConditions.visibilityOf(hook.mp.Mypipelinepage_UploadPopup_FirstFileName_text));
			if (hook.mp.Mypipelinepage_UploadPopup_FirstFileName_text.isDisplayed()) {
				loginfo.log(Status.PASS, "Mismo File name displayed : "
						+ hook.mp.Mypipelinepage_UploadPopup_FirstFileName_text.getText());
			} else {
				loginfo.log(Status.FAIL,
						"Mismo File name and Uploading text,Estimation time and uploading bar are not displayed");
			}
			if (hook.mp.Mypipelinepage_UploadPopup_FirstMismo_Delete_icon.isDisplayed()
					&& hook.mp.Mypipelinepage_UploadPopup_FirstMismoCheckcircle_icon.isDisplayed()) {
				loginfo.log(Status.PASS, "check mark and Delete icon displayed");
			} else {
				loginfo.log(Status.FAIL, "check mark and Delete icon are not displayed");
			}
			hook.wait.until(ExpectedConditions.visibilityOf(hook.mp.Mypipelinepage_UploadPopup_first_Loannumber));
			Hooks.loannum = hook.mp.Mypipelinepage_UploadPopup_first_Loannumber.getText();

		} catch (Exception e) {
			fname = hook.cm.addScreenshot(testContext);
			loginfo.log(Status.FAIL, e.getMessage());
			loginfo.addScreenCaptureFromPath(fname);
		}
		
	}

	@Then("^User selects Browse to upload a file \"(.*)\"$")
	public void uploadFileToValidateDiffSetOfData(String fileName) throws Exception {

		ExtentTest loginfo = null;
		try {
			loginfo = test.createNode(new GherkinKeyword("Then"), "User selects Browse to upload a file " + fileName);
			hook.actions.pause(5000).build().perform();
			hook.wait.until(ExpectedConditions.visibilityOf(hook.gp.GenericPage_Upload_PopUp_title));
			String path = System.getProperty("user.dir") + "/src/test/resources/files/" + fileName;
			hook.driver.findElement(By.xpath("//input[@type='file']")).sendKeys(path);
			loginfo.log(Status.INFO, "file selected successfully");
			if (fileName.contains("corrupted") | fileName.contains("10")) {
				hook.actions.pause(10000).build().perform();
			}else {
				hook.actions.pause(10000).build().perform();
			}
			hook.actions.pause(18000).build().perform();
			loginfo.log(Status.PASS, fileName + " uploaded successfully");
		} catch (Exception e) {
			fname = hook.cm.addScreenshot(testContext);
			loginfo.log(Status.FAIL, e.getMessage());
			loginfo.addScreenCaptureFromPath(fname);
		}

	}
	@Then("^User should click on Browse link and upload \"(.*)\"$")
	public void user_should_click_on_Browse_link_and_upload(String fileName) throws Exception {
		ExtentTest loginfo = null;
		try {
			loginfo = test.createNode(new GherkinKeyword("Then"), "User selects Browse to upload a file " + fileName);
			hook.actions.pause(5000).build().perform();
			hook.wait.until(ExpectedConditions.visibilityOf(hook.gp.GenericPage_Upload_PopUp_title));
			String path = System.getProperty("user.dir") + "/src/test/resources/files/" + fileName;
			if(hook.driver.findElement(By.xpath("//span[text()='browse']")).isDisplayed()) {
				hook.driver.findElement(By.xpath("//input[@type='file']")).sendKeys(path);			
				loginfo.log(Status.PASS, "Browse option is available and uploaded : "+fileName+"documnet successfully");
			}else {
				loginfo.log(Status.PASS, "Browse option is not available and not uploaded : "+fileName+"document");
			}
			
		} catch (Exception e) {
			fname = hook.cm.addScreenshot(testContext);
			loginfo.log(Status.FAIL, e.getMessage());
			loginfo.addScreenCaptureFromPath(fname);
		}

	}
	@Then("^User verifies the documents availability in application and then upload a file to verify \"(.*)\" scroll bar$")
	public void verifyTheDocumentAvailabilityAndThenUploadDoc(String documentsView, DataTable documents) throws Exception {

		ExtentTest loginfo = null;
		int noOfDocumemts;
		String[] docsSplit=null;
		try {
			loginfo = test.createNode(new GherkinKeyword("Then"),
					"User verifies the documents availability in application and then upload a file to verify scroll bar when we are in "+documentsView);

			List<String> PDFDocuments = documents.asList(String.class);
			hook.wait.until(ExpectedConditions.visibilityOf(hook.lp.LoanLandingPage_UploadDocuments_button));
			JavascriptExecutor javascript = (JavascriptExecutor) hook.driver;
			Boolean b2 = (Boolean) javascript.executeScript("return document.documentElement.scrollHeight>document.documentElement.clientHeight;");
			System.out.println(b2);
			String docs = PDFDocuments.get(0);
			docsSplit = docs.split(",");
			for (int i = 0; i < docsSplit.length; i++) {
				if (hook.lp.LoanLandingPag_DocumentsTab_Documents_List.size() >= docsSplit.length) {
					if(hook.lp.LoanLandingPag_DocumentsTab_DocumentsScrollBar.isDisplayed()) {
						loginfo.log(Status.PASS, "Scroll bar is available when we upload "+docsSplit.length+" documents");
					}else {
						loginfo.log(Status.FAIL, "Scroll bar is not available when we upload "+docsSplit.length+" documents");
					}
				}else {
					hook.lp.LoanLandingPage_UploadDocuments_button.click();
					hook.actions.pause(2000).build().perform();
					String path = System.getProperty("user.dir") + "/src/test/resources/files/" + docsSplit[i]+".pdf";
					hook.driver.findElement(By.xpath("//input[@type='file']")).sendKeys(path);
					hook.actions.pause(15000).build().perform();
					WebElement element=hook.driver.findElement(By.xpath("//*[text()='ADD']|//span[contains(text(),'ADD')]"));
					JavascriptExecutor js = (JavascriptExecutor) hook.driver;
		            js.executeScript("arguments[0].click();", element);
				}
								
			}
			
			Boolean b1 = (Boolean) javascript.executeScript("return document.documentElement.scrollHeight>document.documentElement.clientHeight;");
			loginfo.log(Status.PASS,"Boolean Value : "+b1);
		} catch (Exception e) {
			fname = hook.cm.addScreenshot(testContext);
			loginfo.log(Status.FAIL, "Scroll bar is not available when we upload "+docsSplit.length+" documents "+e.getMessage());
			loginfo.addScreenCaptureFromPath(fname);

		}

	}

	@Then("^Verify below fields display in the page$")
	public void VerifyUploadpopupoptions(DataTable dt) throws Exception {
		ExtentTest loginfo = null;
		try {
			loginfo = test.createNode(new GherkinKeyword("Then"), "Verify below fields display in the page");
			hook.wait.until(ExpectedConditions.visibilityOf(hook.mp.Mypipelinepage_UploadPopup_Upload_icon));
			List<String> List = dt.asList(String.class);
			if (List.get(0).equalsIgnoreCase(hook.mp.Mypipelinepage_UploadPopup_Upload_icon.getAttribute("data-icon"))
					&& List.get(1).contains(hook.mp.Mypipelinepage_UploadPopup_DragDrop_text.getText().trim())) {
				loginfo.log(Status.PASS, "Upload Icon and text displayed :"
						+ hook.mp.Mypipelinepage_UploadPopup_DragDrop_text.getText());
			} else {
				loginfo.log(Status.FAIL, "Upload Icon and text not displayed ");
			}
			if (List.get(2).equalsIgnoreCase(hook.mp.Mypipelinepage_UploadPopup_BrowseFiles_link.getText())
					&& List.get(3).equalsIgnoreCase(hook.mp.Mypipelinepage_Upload_FileHeading_yourUploads.getText())) {
				loginfo.log(Status.PASS,
						"Option displayed : " + hook.mp.Mypipelinepage_UploadPopup_BrowseFiles_link.getText());
				loginfo.log(Status.PASS,
						"File Header displayed : " + hook.mp.Mypipelinepage_Upload_FileHeading_yourUploads.getText());
			} else {
				loginfo.log(Status.FAIL, "Browse file,Drag and drop and File Header your uploads not displayed ");
			}
			if (List.get(4).equalsIgnoreCase(hook.mp.Mypipelinepage_UploadPopup_Save_button.getText())
					&& List.get(5).equalsIgnoreCase(hook.mp.Mypipelinepage_UploadPopup_Cancel_button.getText())) {
				loginfo.log(Status.PASS,
						"Buttons displayed : " + hook.mp.Mypipelinepage_UploadPopup_Save_button.getText() + ","
								+ hook.mp.Mypipelinepage_UploadPopup_Cancel_button.getText());
			} else {
				loginfo.log(Status.FAIL, "SAVE and CANCEL buttons are not displayed ");
			}
		} catch (Exception e) {
			fname = hook.cm.addScreenshot(testContext);
			loginfo.log(Status.FAIL, e.getMessage());
			loginfo.addScreenCaptureFromPath(fname);

		}

	}

	@When("^User clicks on delete icon in Upload pop up$")
	public void UserclicksondeleteiconinUploadpopup() throws Exception {
		ExtentTest loginfo = null;
		try {
			loginfo = test.createNode(new GherkinKeyword("When"), "User clicks on delete icon in Upload pop up");
			hook.wait.until(ExpectedConditions
					.visibilityOfAllElements(hook.mp.Mypipelinepage_UploadPopup_FirstMismo_Delete_icon));
			if (hook.mp.Mypipelinepage_UploadPopup_FirstMismo_Delete_icon.isDisplayed()) { 
				loginfo.log(Status.PASS, "Successfully clicked on Delete icon and clicked");
			} else {
				loginfo.log(Status.FAIL, "Delete icon not displayed");
			}
			hook.mp.Mypipelinepage_UploadPopup_FirstMismo_Delete_icon.click();
			hook.actions.pause(3000).build().perform();
		} catch (Exception e) {
			fname = hook.cm.addScreenshot(testContext);
			loginfo.log(Status.FAIL, e.getMessage());
			loginfo.addScreenCaptureFromPath(fname);

		}

	}

	@Then("^Verify Delete pop up display message and buttons$")
	public void VerifyDeletepopupdisplaymessageandbuttons(DataTable dt) throws Exception {
		ExtentTest loginfo = null;
		try {
			loginfo = test.createNode(new GherkinKeyword("Then"), "Verify Delete pop up display message and buttons");
			hook.wait.until(
					ExpectedConditions.visibilityOfAllElements(hook.mp.Mypipelinepage_Deletepopper_Cancel_button));
			List<String> list = dt.asList(String.class);
			if (list.get(0).equalsIgnoreCase(hook.mp.Mypipelinepage_Deletepopper_Cancel_button.getText())
					&& list.get(1).equalsIgnoreCase(hook.mp.Mypipelinepage_UploadPopup_Delete_button.getText())
					&& list.get(2).equalsIgnoreCase(hook.mp.Mypipelinepage_UploadPopup_Deletepop_message.getText())) {
				loginfo.log(Status.PASS,
						"Successfully Buttons and message displayed in Delete popper" + "<br />"
								+ hook.mp.Mypipelinepage_Deletepopper_Cancel_button.getText() + "<br />"
								+ hook.mp.Mypipelinepage_UploadPopup_Delete_button.getText() + "<br />"
								+ hook.mp.Mypipelinepage_UploadPopup_Deletepop_message.getText());
			} else {
				loginfo.log(Status.FAIL, "Buttons and message text not displayed in Delete popper");
			}
		} catch (Exception e) {
			fname = hook.cm.addScreenshot(testContext);
			loginfo.log(Status.FAIL, e.getMessage());
			loginfo.addScreenCaptureFromPath(fname);

		}

	}

	@Then("^Delete popper closed and file deleted in upload popup$")
	public void Deletepopperclosedandfiledeletedinuploadpopup() throws Exception {
		ExtentTest loginfo = null;
		try {
			loginfo = test.createNode(new GherkinKeyword("Then"),
					"Delete popper closed and file deleted in upload popup");
			hook.wait.until(ExpectedConditions.visibilityOf(hook.gp.GenericPage_Upload_PopUp_title));
			try {
				if (hook.mp.Mypipelinepage_UploadPopup_Deletepop_message.isDisplayed()
						&& hook.mp.Mypipelinepage_UploadPopup_FirstFileName_text.isDisplayed()) {
					loginfo.log(Status.FAIL, " Delete popup not closed and file not deleted"
							+ hook.mp.Mypipelinepage_UploadPopup_FirstFileName_text.getText());
				}else {
					loginfo.log(Status.FAIL, " Delete popup closed and file deleted"
							+ hook.mp.Mypipelinepage_UploadPopup_FirstFileName_text.getText());
				}
			} catch (Exception e) {

				loginfo.log(Status.PASS, "Successfully Delete popper closed and file Deleted in upload");
			}
			Assert.assertTrue(hook.gp.GenericPage_Upload_PopUp_title.isDisplayed());
			loginfo.log(Status.PASS, "Successfully upload popup retained ");
		} catch (AssertionError e) {
			fname = hook.cm.addScreenshot(testContext);
			loginfo.log(Status.FAIL, "Verify upload popup retained" + e.getMessage());
			loginfo.addScreenCaptureFromPath(fname);
		}
	}

	@Then("^Delete popper closed and file remained same$")
	public void Deletepopperclosedandfileremainedsame() throws Exception {
		ExtentTest loginfo = null;
		try {
			loginfo = test.createNode(new GherkinKeyword("Then"), "Delete popper closed and file remained same");
			hook.wait.until(ExpectedConditions.visibilityOf(hook.gp.GenericPage_Upload_PopUp_title));

			if (hook.gp.GenericPage_Upload_PopUp_title.isDisplayed()
					&& hook.mp.Mypipelinepage_UploadPopup_FirstFileName_text.isDisplayed()) {
				loginfo.log(Status.PASS, "Upload pop up displayed and file not deleted : "
						+ hook.mp.Mypipelinepage_UploadPopup_FirstFileName_text.getText());
			} else {
				loginfo.log(Status.FAIL, "Upload pop up not displayed and file deleted");
			}

			hook.actions.pause(3000).build().perform();
			if (hook.mp.Mypipelinepage_UploadPopup_Deletepop_message.isDisplayed()) {
				loginfo.log(Status.FAIL, "Delete popper not closed ");

			} else {
				loginfo.log(Status.PASS, "Successfully Delete popper closed ");
			}
		} catch (Exception e) {
			fname = hook.cm.addScreenshot(testContext);
			loginfo.log(Status.FAIL, e.getMessage());
			loginfo.addScreenCaptureFromPath(fname);
		}

	}

	@Then("^Verify upload selection area is in collapse mode$")
	public void Verifyuploadselectionareaisincollapsemode() throws Exception {
		ExtentTest loginfo = null;
		Thread.sleep(10000);
		try {
			loginfo = test.createNode(new GherkinKeyword("Then"), "Verify upload selection area is in collapse mode");
			int Height = hook.mp.Mypipelinepage_UploadPopup_uploadsection.getSize().getHeight();
			int Width = hook.mp.Mypipelinepage_UploadPopup_uploadsection.getSize().getWidth();

			if (Height == 78 | Height == 82 | Height == 83) {
				loginfo.log(Status.PASS, "Matching the Height");

			} else {
				loginfo.log(Status.FAIL, "Not Matching the Height ");
			}

			if (Width == 464) {
				loginfo.log(Status.PASS, "Matching the Width");

			} else {
				loginfo.log(Status.FAIL, "Not Matching the Width ");
			}

			loginfo.log(Status.PASS, "Successfully the upload selection is in Collapse mode");
			loginfo.log(Status.PASS, "Height:" + hook.mp.Mypipelinepage_UploadPopup_uploadsection.getSize().height);
			loginfo.log(Status.PASS, "Width:" + hook.mp.Mypipelinepage_UploadPopup_uploadsection.getSize().width);
		} catch (Exception e) {
			fname = hook.cm.addScreenshot(testContext);
			loginfo.log(Status.FAIL, "Verify the upload selection Collapse mode" + e.getMessage());
			loginfo.addScreenCaptureFromPath(fname);

		}

	}

	@Then("^Verify upload selection area is in Expanded mode$")
	public void VerifyuploadselectionareaisinExpandedmode() throws Exception {
		ExtentTest loginfo = null;
		Thread.sleep(10000);
		try {
			loginfo = test.createNode(new GherkinKeyword("Then"), "Verify upload selection area is in Expanded mode");
			int Height = hook.mp.Mypipelinepage_UploadPopup_uploadsection.getSize().getHeight();
			int Width = hook.mp.Mypipelinepage_UploadPopup_uploadsection.getSize().getWidth();

			if (Height == 158 | Height == 159 | Height == 167) {
				loginfo.log(Status.PASS, "Matching the Height");
				Assert.assertTrue(hook.mp.Mypipelinepage_UploadPopup_uploadsection.isDisplayed());

			} else {
				loginfo.log(Status.FAIL, "Not Matching the Height ");
			}

			if (Width == 464) {
				loginfo.log(Status.PASS, "Matching the Width");

			} else {
				loginfo.log(Status.FAIL, "Not Matching the Width ");
			}

			loginfo.log(Status.PASS, "Successfully the upload selection is in Expand mode");
			loginfo.log(Status.PASS, "Height:" + hook.mp.Mypipelinepage_UploadPopup_uploadsection.getSize().height);
			loginfo.log(Status.PASS, "Width:" + hook.mp.Mypipelinepage_UploadPopup_uploadsection.getSize().width);
		} catch (Exception e) {
			fname = hook.cm.addScreenshot(testContext);
			loginfo.log(Status.FAIL, "Verify the upload selection Expand mode" + e.getMessage());
			loginfo.addScreenCaptureFromPath(fname);

		}

	}

	@Then("^Verify the file success message and Loan no in mypipeline$")
	public void VerifythefilesuccessmessageandLoannoinmypipeline() throws Exception {
		ExtentTest loginfo = null;
		try {
			loginfo = test.createNode(new GherkinKeyword("Then"),
					"Verify the file success message and Loan no in mypipeline");
			int flag = 0;
			hook.actions.pause(8000).build().perform();
			hook.wait.until(ExpectedConditions.visibilityOf(hook.mp.Mypipelinepage_UploadPopup_Save_button));
			hook.wait.until(ExpectedConditions.visibilityOf(hook.mp.Mypipelinepage_UploadPopup_first_Loannumber));
			String loanno = hook.mp.Mypipelinepage_UploadPopup_first_Loannumber.getText();
			hook.mp.Mypipelinepage_UploadPopup_Save_button.click();
			hook.wait.until(ExpectedConditions.visibilityOf(hook.mp.Mypipeline_File_validation_message));
			String msg = hook.mp.Mypipeline_File_validation_message.getText();
			if (msg.contains("file have been added to your pipeline")) {
				loginfo.log(Status.PASS, "File upload success message displayed properly " + msg);
			} else {
				loginfo.log(Status.FAIL, "File upload success message not displayed ");
			}
			hook.actions.pause(3000).build().perform();
			hook.wait.until(
					ExpectedConditions.visibilityOfAllElements(hook.mp.Mypipelinepage_Grid_LoanNumber_Data_list));
			for (int i = 0; i < hook.mp.Mypipelinepage_Grid_LoanNumber_Data_list.size(); i++) {
				if (loanno.equalsIgnoreCase(hook.mp.Mypipelinepage_Grid_LoanNumber_Data_list.get(i).getText())) {

					flag = 1;
					break;
				}else {
					continue;
				}
			}
			if (flag == 1) {
				loginfo.log(Status.PASS, "Loan number displayed successfully :" + loanno);
			} else {
				loginfo.log(Status.FAIL, "Loan number not displayed");
			}

		} catch (Exception e) {
			fname = hook.cm.addScreenshot(testContext);
			loginfo.log(Status.FAIL, "Verify the file success message and loan no " + e.getMessage());
			loginfo.addScreenCaptureFromPath(fname);

		}

	}

	@When("^Click Cancel in upload pop up$")
	public void ClickCancelinuploadpopup() throws Exception {
		ExtentTest loginfo = null;
		try {
			loginfo = test.createNode(new GherkinKeyword("When"), "Click Cancel in upload pop up");
			hook.wait.until(ExpectedConditions.visibilityOf(hook.mp.Mypipelinepage_UploadPopup_Cancel_button));
			hook.mp.Mypipelinepage_UploadPopup_Cancel_button.click();
			hook.wait.until(
					ExpectedConditions.visibilityOf(hook.mp.Mypipelinepage_UploadPopup_uploadsection_Header_Text));
			Assert.assertTrue(hook.mp.Mypipelinepage_UploadPopup_uploadsection_Header_Text.isDisplayed());
			loginfo.log(Status.PASS, "Successfully clicked on Cancel button in upload file popup:");
		} catch (AssertionError e) {
			fname = hook.cm.addScreenshot(testContext);
			loginfo.log(Status.FAIL, e.getMessage());
			loginfo.addScreenCaptureFromPath(fname);

		}
	}

	@When("^Verify file cancel validation message$")
	public void Verifyfilecancelvalidationmessage() throws Exception {
		ExtentTest loginfo = null;
		try {
			loginfo = test.createNode(new GherkinKeyword("When"), "Verify file cancel validation message");
			String msg = hook.mp.Mypipeline_File_validation_message.getText();
			if (hook.mp.Mypipeline_File_validation_message.getText()
					.contains("Loan file upload has been cancelled")) {
				loginfo.log(Status.PASS, "File cancel validation message displayed properly "
						+ hook.mp.Mypipeline_File_validation_message.getText());
			} else {
				loginfo.log(Status.FAIL, "File cancel validation message not displayed ");
			}
		} catch (Exception e) {
			fname = hook.cm.addScreenshot(testContext);
			loginfo.log(Status.FAIL, e.getMessage());
			loginfo.addScreenCaptureFromPath(fname);

		}
	}

	@Then("^Verify Cancel your File Upload$")
	public void VerifyCancelyourFileUpload() throws Exception {
		ExtentTest loginfo = null;
		try {
			loginfo = test.createNode(new GherkinKeyword("Then"), "Verify Cancel your File Upload");
			hook.wait.until(
					ExpectedConditions.visibilityOf(hook.mp.Mypipelinepage_UploadPopup_uploadsection_Header_Text));
			Assert.assertTrue(hook.mp.Mypipelinepage_UploadPopup_uploadsection_Header_Text.getText()
					.contains("Cancel your File Upload?"));
			Assert.assertTrue(hook.mp.Mypipelinepage_UploadPopup_uploadsection_Middel_Text.getText()
					.contains("All the loan files you added will be deleted if you quit the upload process now."));
			loginfo.log(Status.PASS, "Successfully the Cancel upload header displayed in cancel popup:"
					+ hook.mp.Mypipelinepage_UploadPopup_uploadsection_Header_Text.getText());
			loginfo.log(Status.PASS, "Successfully cancel text displayed in cancel popup:"
					+ hook.mp.Mypipelinepage_UploadPopup_uploadsection_Middel_Text.getText());
		} catch (AssertionError e) {
			fname = hook.cm.addScreenshot(testContext);
			loginfo.log(Status.FAIL, "Verify the upload selection Expand mode" + e.getMessage());
			loginfo.addScreenCaptureFromPath(fname);

		}

	}

	@Then("^Verify LoanDetails in Upload pop up$")
	public void VerifyLoanNumberinUploadpopup() throws Exception {
		ExtentTest loginfo = null;
		try {
			loginfo = test.createNode(new GherkinKeyword("Then"), "Then Verify LoanDetails in Upload pop up");
			hook.wait.until(ExpectedConditions.visibilityOf(hook.gp.GenericPage_Upload_PopUp_title));

			if (hook.mp.Mypipelinepage_UploadPopup_first_Loannumber.isDisplayed()
					&& hook.mp.Mypipelinepage_UploadPopup_BorrowerName.isDisplayed()
					&& hook.mp.Mypipelinepage_UploadPopup_LoanType.isDisplayed()) {
				loginfo.log(Status.PASS,
						"LoanNumber :  " + hook.mp.Mypipelinepage_UploadPopup_first_Loannumber.getText());
				loginfo.log(Status.PASS,
						"BorrowerName :   " + hook.mp.Mypipelinepage_UploadPopup_BorrowerName.getText());
				loginfo.log(Status.PASS, "LoanType :  " + hook.mp.Mypipelinepage_UploadPopup_LoanType.getText());
			} else {
				loginfo.log(Status.FAIL, "first_Loannumber, BorrowerName and  Borrowerstate is not displayed");

			}

		} catch (Exception e) {
			fname = hook.cm.addScreenshot(testContext);
			loginfo.log(Status.FAIL, e.getMessage());
			loginfo.addScreenCaptureFromPath(fname);

		}
	}

	@When("^Click on New Loan and verify popup$")
	public void clickOnNewLoanButtonVerifyPopup() throws Exception {

		ExtentTest loginfo = null;
		try {
			loginfo = test.createNode(new GherkinKeyword("When"), "Click on New Loan and verify popup");
			hook.wait.until(ExpectedConditions.visibilityOf(hook.mp.Mypipelinepage_NewLoan_button));
			hook.actions.pause(8000).build().perform();
			hook.wait.until(ExpectedConditions.visibilityOf(hook.mp.Mypipelinepage_NewLoan_button));
			hook.mp.Mypipelinepage_NewLoan_button.click();
			hook.actions.pause(2000).build().perform();
			if (hook.gp.GenericPage_Upload_PopUp_title.isDisplayed()) {
				loginfo.log(Status.PASS, "Popup Title :  " + hook.gp.GenericPage_Upload_PopUp_title.getText());

			} else {
				loginfo.log(Status.FAIL, "Popup not displayed to upload a file");

			}

		} catch (Exception e) {
			fname = hook.cm.addScreenshot(testContext);
			loginfo.log(Status.FAIL, e.getMessage());
			loginfo.addScreenCaptureFromPath(fname);

		}

	}

	@Then("^User verify \"(.*)\" message$")
	public void verifyMessage(String message) throws Exception {

		ExtentTest loginfo = null;
		try {
			loginfo = test.createNode(new GherkinKeyword("Then"), "Then Verify " + message + "message");
			hook.wait.until(ExpectedConditions.visibilityOf(hook.mp.Mypipelinepage_UploadPopup_ErrorMessage_text));
			String actualText = hook.mp.Mypipelinepage_UploadPopup_ErrorMessage_text.getText();
			if (message.equalsIgnoreCase(actualText)) {
				loginfo.log(Status.PASS,
						"Expected Message :  " + hook.mp.Mypipelinepage_UploadPopup_ErrorMessage_text.getText());
			} else {
				loginfo.log(Status.FAIL, message + " Not disaplayed");
			}

		} catch (Exception e) {
			fname = hook.cm.addScreenshot(testContext);
			loginfo.log(Status.FAIL, e.getMessage());
			loginfo.addScreenCaptureFromPath(fname);

		}

	}

	@Then("^Click on Browse icon$")
	public void clickOnBrowseIcon() throws Exception {
		ExtentTest loginfo = null;
		loginfo = test.createNode(new GherkinKeyword("Then"), "Click on Browse icon");
		hook.actions.pause(2000).build().perform();
		hook.wait.until(ExpectedConditions.visibilityOf(hook.mp.Mypipelinepage_UploadPopup_BrowseFiles_link));
		try {
			if (hook.mp.Mypipelinepage_UploadPopup_BrowseFiles_link.isDisplayed()) {
				hook.mp.Mypipelinepage_UploadPopup_BrowseFiles_link.click();
			} else {
				loginfo.log(Status.PASS, "Clicked on Browse icon to uplad a file");
			}

		} catch (Exception e) {
			fname = hook.cm.addScreenshot(testContext);
			loginfo.log(Status.FAIL, e.getMessage());
			loginfo.addScreenCaptureFromPath(fname);

		}
	}

	@Then("^I verify the Loan List count in the home page$")
	public void verifytheLoanListCountinHomePage() throws Exception {
		ExtentTest loginfo = null;
		try {
			loginfo = test.createNode(new GherkinKeyword("Then"), "verify the Loan List count in the home page");
			hook.actions.pause(5000).build().perform();
			hook.wait.until(ExpectedConditions.visibilityOf(hook.gp.GenericPage_countOfLoanNumbersList));
			loanListText = hook.gp.GenericPage_countOfLoanNumbersList.getText();
			System.out.println(loanListText);
		} catch (Exception e) {

			fname = hook.cm.addScreenshot(testContext);
			loginfo.log(Status.FAIL, e.getMessage());
			loginfo.addScreenCaptureFromPath(fname);
		}
	}
	
}
