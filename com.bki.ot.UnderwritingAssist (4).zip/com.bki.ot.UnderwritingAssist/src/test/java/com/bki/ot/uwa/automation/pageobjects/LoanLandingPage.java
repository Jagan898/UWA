package com.bki.ot.uwa.automation.pageobjects;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.FindBy;

import org.openqa.selenium.support.PageFactory;
import java.util.List;

public class LoanLandingPage {

	WebDriver driver;

	public LoanLandingPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);

	}

	// *************************************Loan Details Elements
	// ********************************
	@FindBy(xpath = "//*[@class='header']/ul/li/a")
	public WebElement LoanLandingPage_BreadcrumbLink;
	@FindBy(xpath = "//*[@class='status']/descendant::span[contains(@class,'status')]")
	public WebElement LoanLandingPage_Loan_Status;
	@FindBy(xpath = "//*[@class='status']/descendant::div[contains(@class,'status__layout')]")
	public WebElement LoanLandingPage_Loan_Status_BGcolor;
	@FindBy(xpath = "//*[@data-icon='user-clock']")
	public WebElement LoanLandingPage_UserClock_icon;
	@FindBy(xpath = "//*[@data-icon='exclamation-triangle']")
	public WebElement LoanLandingPage_Triangle_icon;
	@FindBy(xpath = "//*[@class='mat-tab-links']/a")
	public List<WebElement> LoanLandingPage_Tabs_list;
	@FindBy(xpath = "//*[@class='content-container__title']")
	public List<WebElement> LoanLandingPage_InfoHeaders_list;
	@FindBy(xpath = "//thead[@role='rowgroup']//th")
	public List<WebElement> IncomeInformationTab_ColumnHeaders_list;

	@FindBy(xpath = "//*[@class='header']/ul/li[starts-with(text(),'DI')]")
	public WebElement LoanLandingPage_Breadcrumb_LoanNumber;

	@FindBy(xpath = "//*[@class='content-container__title']/following::div[contains(@class,'row-label__item')]")
	public List<WebElement> LoanLandingPage_SideInfoheading_list;

	@FindBy(xpath = "//*[@class='content-container__title']/following::div[contains(@class,'row-value__item')]")
	public List<WebElement> LoanLandingPage_SideInfovalue_list;

	@FindBy(xpath = "//*[contains(text(),'loan document')]")
	public WebElement LoanLandingPage_DocumentsHeader_text;

	@FindBy(xpath = "//*[@class='btn upload']")
	public WebElement LoanLandingPage_UploadDocuments_button;

	@FindBy(xpath = "//*[@id='fileDropRef']/following::div[@class='drag-drop']")
	public WebElement Mypipelinepage_DocUploadPopup_DragDrop_text;

	// **************************************************Loan Over view
	// Tab********************
	@FindBy(xpath = "//*[@class='variances__main' or @class='variance__content']")
	public List<WebElement> LoanLandingPage_Loan_overview_widget_title_list;

	@FindBy(xpath = "//*[@class='variances__count' or @class='variance__percent']")
	public List<WebElement> LoanLandingPage_Loan_overview_countorpercentage_list;

	@FindBy(css = ".fa-list-ol > path")
	public WebElement LoanLandingPage_Loan_overview_Open_Conditions_widget_icon;

	@FindBy(xpath = "//*[@data-icon='exclamation-circle']")
	public WebElement LoanLandingPage_Loan_overview_OpenVariances_icon;

	@FindBy(css = "circle-progress > .ng-star-inserted > path")
	public WebElement LoanLandingPage_Loan_overview_Loan_Process_widget_icon;

	// ------------My-To-Do-List Elements---------------------------

	@FindBy(xpath = "//div[@class='heading']/span[1]")
	public WebElement LoanLandingPage_My_to_list_name;

	@FindBy(xpath = "//*[@class='heading']/span[2]")
	public WebElement LoanLandingPage_My_to_list_number;

	@FindBy(xpath = "//*[@class='mat-card-content']/div/div/span[1]")
	public List<WebElement> LoanLandingPage_My_to_list_heaidngs;

	@FindBy(xpath = "//mat-card-content/div[1]/div[2]/button")
	public WebElement LoanLandingPage_My_to_list_varince_arrow;

	@FindBy(xpath = "//mat-card-content/div[2]/div[2]/button")
	public WebElement LoanLandingPage_My_to_list_conditions_arrow;
	// ----------Condition Tab------------------------------------------
	@FindBy(xpath = "//span[contains(text(),'loan document')]")
	public WebElement LoanLandingPage_condition_tab_loandocument;

	@FindBy(xpath = "//button[@class='btn thumbnail__table in-active']")
	public WebElement LoanLandingPage_condition_tab_tableGrid;

	@FindBy(xpath = "//span[text()='document name']")
	public WebElement LoanLandingPage_condition_tab_documentname;

	@FindBy(xpath = "//span[text()='clear']//ancestor::button")
	public WebElement LoanLandingPage_clear_button;

	@FindBy(xpath = "//table[@matsortactive='conditionType']//thead//tr//span[text()='Description']")
	public WebElement LoanLandingPage_grid_description_coloum_header;

	@FindBy(xpath = "//table[@matsortactive='conditionType']//thead//tr//span[text()='Created On']")
	public WebElement LoanLandingPage_grid_createdon_coloum_header;

	@FindBy(xpath = "//div[text()=' View All ']")
	public WebElement LoanLandingPage_grid_viewAll_button;

	@FindBy(xpath = "//span[text()='All Conditions']")
	public WebElement LoanLandingPage_aa_condition_button;

	@FindBy(xpath = "//a[text()='Conditions']")
	public WebElement LoanLandingPage_condition_tab;

	@FindBy(xpath = "//a[text()='Loan Overview']")
	public WebElement LoanLandingPage_loanoverview_tab;

	@FindBy(xpath = "//a[text()='Documents']")
	public WebElement LoanLandingPage_Documents_tab;

	@FindBy(xpath = "//*[contains(text(),'All Conditions')]")
	public WebElement LoanLandingPage_Loan_overview_AllConditionstext;

	@FindBy(xpath = "//button[contains(text(),' + Add condition ')]")
	public WebElement LoanLandingPage_addConditionButton;

	@FindBy(xpath = "//button[contains(text(),'NEW CONDITION')]")
	public WebElement LoanLandingPage_conditiontab_Newcondition_button;

	@FindBy(xpath = "//*[@class='mat-tab-label-content']/span[1]")
	public List<WebElement> LoanLandingPage_conditiontab_Allconditions_tabs_list;

	@FindBy(xpath = "//tbody[@role='rowgroup']/tr/descendant::button[@aria-label='more options']")
	public List<WebElement> LoanLandingPage_conditiontab_Allconditions_ClearTab_Ellipses_list;

	@FindBy(xpath = "//*[@role='menuitem']/child::*[@data-icon='undo-alt']")
	public WebElement LoanLandingPage_conditiontab_Allconditions_ClearTab_Ellipsesoption_Reopen;

	@FindBy(xpath = "//*[@class='mat-tab-body-wrapper']/descendant::*[contains(text(),'reopen')]")
	public WebElement LoanLandingPage_conditiontab_Allconditions_ClearTab_Reopen_button;

	// @FindBy(xpath = "//*[@class='mat-checkbox-layout']/div")
	@FindBy(xpath = "//*[@class='mat-checkbox-label']")
	public List<WebElement> LoanLandingPage_conditiontab_Allconditions_ClearTab_condition_checkbox_list;

	@FindBy(xpath = "//*[contains(text(),'All Conditions')]/following::*[contains(@class,'mat-column-Description')]")
	public List<WebElement> LoanLandingPage_conditiontab_Allconditions_Income_cleartab_descriptionList;
	
	@FindBy(xpath = "//*[@role='menu']/descendant::button[@role='menuitem']")
	public List<WebElement> LoanLandingPage_conditiontab_Allconditions_Income_cleartab_menuitems_list;
	
	@FindBy(xpath = "//span[contains(text(),'Cleared')]/parent::div/span[2]")
	public List<WebElement> LoanLandingPage_conditiontab_Allconditions_ClearTab_NumberOfOpenConditions;
	
	@FindBy(xpath = "//tbody/tr[contains(@class,'table-row')]/td//button/span")
	public List<WebElement> LoanLandingPage_conditiontab_Allconditions_ClearTab_NumberOfEllipses;
	
//-------------------Condition create condition--------------------------------
	@FindBy(xpath = "//*[@class='modal']/descendant::*[@class='heading']/h1")
	public WebElement LoanLandingPage_conditiontab_popup_heading;

	@FindBy(xpath = "//*[@formcontrolname='ConditionType' and  @role='listbox']")
	public WebElement LoanLandingPage_conditiontab_popup_conditiontype_Dropdown;

	@FindBy(xpath = "//input[@formcontrolname='Description' and @data-placeholder='Description']")
	public WebElement LoanLandingPage_conditiontab_popup_ConditionDescription_input;

	@FindBy(xpath = "//*[@formcontrolname='Documents' and @role='listbox']")
	public WebElement LoanLandingPage_conditiontab_popup_Documents_Dropdown;

	@FindBy(xpath = "//*[@class='my-notes']")
	public WebElement LoanLandingPage_conditiontab_popup_Mynotes_label;

	@FindBy(xpath = "//textarea[@formcontrolname='Notes']")
	public WebElement LoanLandingPage_conditiontab_popup_Mynotes_textarea;

	@FindBy(xpath = "//*[@formcontrolname='PriorTo' and @role='listbox']")
	public WebElement LoanLandingPage_conditiontab_popup_Priorto_Dropdown;

	@FindBy(xpath = "//*[@formcontrolname='PriorTo' and @role='listbox']/following::*[@class='mat-option-text']")
	public List<WebElement> LoanLandingPage_conditiontab_popup_Priorto_Dropdown_Values;

	@FindBy(xpath = "//*[@formcontrolname='ConditionType' and @role='listbox']/following::*[@class='mat-option-text']")
	public List<WebElement> LoanLandingPage_conditiontab_popup_ConditionType_DropdownValues;

	@FindBy(xpath = "//*[@formcontrolname='Borrower' and @role='listbox']")
	public WebElement LoanLandingPage_conditiontab_popup_Borrower_Dropdown;
	@FindBy(xpath = "//*[@formcontrolname='Borrower' and @role='listbox']/following::*[@class='mat-option-text']")
	public List<WebElement> LoanLandingPage_conditiontab_popup_Borrower_DropdownValues;
	//@FindBy(xpath = "//*[@formcontrolname='Employer' and @role='listbox']")
	@FindBy(xpath = "//*[@formcontrolname='Employer']/descendant::div[contains(@class,'mat-select-arrow')][1]")
	public WebElement LoanLandingPage_conditiontab_popup_Employer_Dropdown;
	@FindBy(xpath = "//*[@formcontrolname='Employer' and @role='listbox']/following::*[@class='mat-option-text']")
	public List<WebElement> LoanLandingPage_conditiontab_popup_Employer_DropdownValues;

	@FindBy(xpath = "//*[@formcontrolname='Documents' and @role='listbox']/following::*[@class='mat-option-text']")
	public List<WebElement> LoanLandingPage_conditiontab_popup_Documents_DropdownValues;
	
	@FindBy(xpath = "//tbody/tr[contains(@class,'table-row')] ")
	public List<WebElement> LoanLandingPage_conditiontab_NumberOfBorrowers;

	// ****************************************Documents Tab******************************
	@FindBy(xpath = "//*[@class='card ng-star-inserted']")
	public List<WebElement> LoanLandingPage_listOfUploadedDocs;

	@FindBy(xpath = "//div[@class='info-box']/div")
	public List<WebElement> LoanLandingPage_Uploaded_Documents;

	@FindBy(xpath = "//*[@class='upload-msg']")
	public WebElement UploadErrorMessage1;
	@FindBy(xpath = "//*[@class='upload-msg']")
	public WebElement UploadErrorMessage2;

	@FindBy(xpath = "//button[contains(@class,'btn thumbnail__grid')]")
	public WebElement LoanLandingPage_UploadDocuments_gridViewButton;
	@FindBy(xpath = "//*[contains(@class,'docName')]|//*[contains(@class,'card__title--text')]")
	public List<WebElement> LoanLandingPage_Uploaded_PDFDocuments;

	@FindBy(xpath = "//div[@class='card ng-star-inserted']/div/span")
	public List<WebElement> LoanLandingPage_Uploaded_PDFDocumentsInGridView;

	@FindBy(xpath = "//button[contains(@class,'btn-sort')]")
	public WebElement LoanLandingPage_UploadDocuments_GridViewButtonSortByButton;

	@FindBy(xpath = "//div[contains(text(),'new')]|//div[contains(text(),'Analyzing Docs')]")
	public List<WebElement> LoanLandingPage_Uploaded_PDFDocumentsStatus;
	@FindBy(xpath = "//button[contains(@class,'btn thumbnail__table')]")
	public WebElement LoanLandingPage_UploadDocuments_TableViewButton;

	@FindBy(xpath = "//*[@class='thumbnail']/button[2]")
	public WebElement DocumentsTab_Grid_Option;

	@FindBy(xpath = "//tbody/tr[1]/td[7]")
	public WebElement DocumentsTab_Elispses_Option;
	@FindBy(xpath = "//*[@data-icon='trash'][1]")
	public WebElement LoanLandingPage_DocumentsTab_TrashButton;
	@FindBy(xpath = "//*[@class='container']/descendant::*[@class='header']/descendant::*[@class='label']/span[2]")
	public WebElement LoanLandingPag_DocumentsTab_Heading_count;

	@FindBy(xpath = "//*[@class='filters']/descendant::*[@class='search-filter']/descendant::input[@type='search']")
	public WebElement LoanLandingPag_DocumentsTab_Searchdoc_input;

	@FindBy(xpath = "//*[@class='card__title--text']")
	public List<WebElement> LoanLandingPag_DocumentsTab_Documentlist_Gridview;

	@FindBy(xpath = "//*[@role='combobox']/following::*[contains(text(),'Document Status')]")
	public WebElement LoanLandingPag_DocumentsTab_DocumentStatus_Dropdown;

	@FindBy(xpath = "//*[@role='combobox']/following::*[contains(text(),'Document Status')]/following::*[@class='mat-option-text']")
	public List<WebElement> LoanLandingPag_DocumentsTab_DocumentStatus_DropdownValues;

	@FindBy(xpath = "//*[@class='card__body']/following::*[contains(@class,'ribon__left')]")
	public List<WebElement> LoanLandingPag_DocumentsTab_DocumentStatus_Gridview_RibbonList;

	@FindBy(xpath = "//*[@class='mat-chip-ripple']")
	public WebElement LoanLandingPag_DocumentsTab_SearchDocument_status;

	@FindBy(xpath = "//*[@class='container__table']/descendant::tr[@role='row']/td[2]")
	public List<WebElement> LoanLandingPag_DocumentsTab_Documentsname_TableviewList;

	@FindBy(xpath = "//span[@class='card__title--text']")
	public List<WebElement> LoanLandingPag_DocumentsTab_Documents_List;

	@FindBy(xpath = "//*[contains(@class,'card ng-star-inserted')]/parent::div")
	public WebElement LoanLandingPag_DocumentsTab_DocumentsView;

	@FindBy(xpath = "//style[contains(text(),'[_ngcontent-moi-c192]::-webkit-scrollbar-thumb, [_ngcontent-moi-c192]::-webkit-scrollbar-track')]")
	public WebElement LoanLandingPag_DocumentsTab_DocumentsScrollBar;

	@FindBy(xpath = "//th[contains(@class,'docName')]")
	public WebElement LoanLandingPag_DocumentsTab_DocumentsHeader;

	@FindBy(xpath = "//th[contains(@class,'lastOpened')]")
	public WebElement LoanLandingPag_DocumentsTab_LastOpenedHeader;

	@FindBy(xpath = "//table[@matsortactive='docName']/tbody/tr")
	public List<WebElement> LoanLandingPag_DocumentsTab_ListOfDocsInTable;

	@FindBy(xpath = "//span[contains(text(),'document name')]")
	public WebElement LoanLandingPag_DocumentsTab_HeaderDocName;
	@FindBy(xpath = "//span[contains(text(),'last opened')]")
	public WebElement LoanLandingPag_DocumentsTab_HeaderLastOpened;
	@FindBy(xpath = "//table[@matsortactive='docName']/tbody/tr/td[1]/mat-checkbox")
	public List<WebElement> LoanLandingPag_DocumentsTab_ListCheckBoxesInListView;
	
	/*******************Conditions Tab*************************************************************************************/
	
	@FindBy(xpath = "//table[@matsortactive='conditionType']/thead/tr[1]/th[2]")
	public WebElement LoanLandingPag_ConditionsTab_DaysOpenedsHeader;
	@FindBy(xpath = "//table[@matsortactive='conditionType']/thead/tr[1]/th[3]")
	public WebElement LoanLandingPag_ConditionsTab_ConditionHeader;

	@FindBy(xpath = "//table[@matsortactive='conditionType']/tbody/tr/td[3]")
	public List<WebElement> LoanLandingPag_ConditionsTab_ListOfConditions;
	@FindBy(xpath = "//span[contains(text(),'Income')]")
	public WebElement LoanLandingPag_ConditionsTab_IncomeLabel;
	@FindBy(xpath = "//table[@matsortactive='conditionType']/thead/tr/th/mat-checkbox")
	public WebElement LoanLandingPag_ConditionsTab_rootCheckBox;
	@FindBy(xpath = "//span[contains(text(),'clear')]")
	public WebElement LoanLandingPag_ConditionsTab_ClearButtom;
	@FindBy(xpath = "//span[contains(text(),'Cleared')]")
	public WebElement LoanLandingPag_ConditionsTab_ClearTAB;
	@FindBy(xpath = "//table[@matsortactive='conditionType']/tbody/tr/td/mat-checkbox")
	public List<WebElement> LoanLandingPag_ConditionsTab_ListOfConditionsCheckBoxes;
	
	@FindBy(xpath = "//div[contains(text(),'rows')]")
	public WebElement LoanLandingPag_ConditionsTab_numberOfRowsOrRecords;
	
	
	//****************************************Income Verification Tab******************************
	@FindBy(xpath = "//tbody[@role='rowgroup']//td[8]//span[@class='mat-button-wrapper']")
	public List<WebElement> IncomeInformationTab_DropdownArrowsRowCount;
	@FindBy(xpath = "//button[contains(@class,'btn thumbnail__grid')]")
	public WebElement LoanLandingPage_DocumentsTab_GridView;
	
	@FindBy(xpath = "(//div[@class='status__success ng-star-inserted'])[1]")
	public WebElement LoanLandingPage_DocumentsTab_DocumentLink;
	
	@FindBy(xpath = "//button[@class='btn thumbnail__table active']")
	public WebElement LoanLandingPage_DocumentsTab_TableView;

}
