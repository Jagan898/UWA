package com.bki.ot.uwa.automation.stepdefinitions;

import java.util.List;
import java.util.Map;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.GherkinKeyword;
import com.aventstack.extentreports.Status;
import com.bki.ot.uwa.automation.extentreport.ExtentReportConfig;
import com.bki.ot.uwa.automation.filereadermanager.FileReaderManager;
import com.bki.ot.uwa.automation.testcontext.TestContext;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.cucumber.java.it.Data;

public class UploadDocStepDef extends ExtentReportConfig {

	Hooks hook;
	TestContext testContext;
	String url = null;
	public static String fname;

	public UploadDocStepDef(TestContext context) {
		testContext = context;
		hook = new Hooks(context);
		url = FileReaderManager.getFileReaderManagerInstance().getConfigInstance().getUrl();

	}

	@Then("^Verify Header and Upload button in Documents Tab$")
	public void VerifyHeaderandUploadbuttoninDocumentsTab(DataTable dt) throws Exception {
		ExtentTest loginfo = null;
		try {
			loginfo = test.createNode(new GherkinKeyword("Then"), "Verify Header and Upload button in Documents Tab");
			List<String> data = dt.asList(String.class);
			Assert.assertTrue(hook.lp.LoanLandingPage_DocumentsHeader_text.isDisplayed()
					&& data.get(0).equalsIgnoreCase(hook.lp.LoanLandingPage_DocumentsHeader_text.getText())
					&& data.get(1).equalsIgnoreCase(hook.lp.LoanLandingPage_UploadDocuments_button.getText()));
			loginfo.log(Status.INFO, " Header displayed :" + hook.lp.LoanLandingPage_DocumentsHeader_text.getText());
			loginfo.log(Status.PASS,
					"Upload button displayed  : " + hook.lp.LoanLandingPage_UploadDocuments_button.getText());
		} catch (AssertionError e) {
			fname = hook.cm.addScreenshot(testContext);
			loginfo.log(Status.FAIL, "Verify Header and upload documents button" + e.getMessage());
			loginfo.addScreenCaptureFromPath(fname);

		}
	}

	@When("^Click on Uploaddocument and verify popup \"(.*)\"$")
	public void ClickonUploaddocumentandverifypopupUploadDocuments(String title) throws Exception {
		ExtentTest loginfo = null;
		try {
			loginfo = test.createNode(new GherkinKeyword("When"),
					"Click on Uploaddocument and verify popup Upload Documents");
			hook.wait.until(ExpectedConditions.visibilityOf(hook.lp.LoanLandingPage_UploadDocuments_button));
			hook.lp.LoanLandingPage_UploadDocuments_button.click();
			hook.wait.until(ExpectedConditions.visibilityOf(hook.gp.GenericPage_Upload_PopUp_title));
			if (hook.gp.GenericPage_Upload_PopUp_title.getText().contains(title)) {
				loginfo.log(Status.PASS, "Upload documents PopUp title displayed properly: "
						+ hook.gp.GenericPage_Upload_PopUp_title.getText());
			} else {
				loginfo.log(Status.FAIL, "Upload Documents PopUp title not displayed : "
						+ hook.gp.GenericPage_Upload_PopUp_title.getText());
			}

		} catch (Exception e) {
			fname = hook.cm.addScreenshot(testContext);
			loginfo.log(Status.FAIL, e.getMessage());
			loginfo.addScreenCaptureFromPath(fname);
		}

	}

	@And("^User Browses income document pdfs$")
	public void UserBrowsesincomedocumentpdfs() throws Exception {
		ExtentTest loginfo = null;
		try {
			loginfo = test.createNode(new GherkinKeyword("And"), "User Browses income document pdfs");
			hook.actions.pause(6000).build().perform();
			hook.wait.until(ExpectedConditions.visibilityOf(hook.mp.Mypipelinepage_UploadPopup_BrowseFiles_link));
			String f1 = FileReaderManager.getFileReaderManagerInstance().getConfigInstance().getUploadDoc1();
			hook.driver.findElement(By.cssSelector("input[type='file']")).sendKeys(f1);
			hook.wait.until(ExpectedConditions.visibilityOf(hook.mp.Mypipelinepage_UploadPopup_FirstFileName_text));
			hook.actions.pause(3000).build().perform();
			String f2 = FileReaderManager.getFileReaderManagerInstance().getConfigInstance().getUploadDoc2();
			// hook.driver.findElement(By.cssSelector(".filedrop")).clear();
			hook.driver.findElement(By.cssSelector("input[type='file']")).sendKeys(f2);
			if (hook.mp.Mypipelinepage_UploadPopup_FirstFileName_text.isDisplayed()
					&& hook.mp.Mypipelinepage_UploadPopup_SecondFileName_text.isDisplayed()) {
				loginfo.log(Status.INFO, "Files uploaded Successfully");
				loginfo.log(Status.PASS,
						"Uploaded Document Files  displayed : "
								+ hook.mp.Mypipelinepage_UploadPopup_FirstFileName_text.getText() + "<b />"
								+ hook.mp.Mypipelinepage_UploadPopup_SecondFileName_text.getText());
			} else {
				loginfo.log(Status.FAIL, "Mismo File names are not displayed");
			}

		} catch (Exception e) {
			fname = hook.cm.addScreenshot(testContext);
			loginfo.log(Status.FAIL, e.getMessage());
			loginfo.addScreenCaptureFromPath(fname);

		}

	}

	@And("^Verify Browsing Invalid income document format$")
	public void VerifyBrowsingInvalidincomedocumentformat() throws Exception {
		ExtentTest loginfo = null;
		try {
			loginfo = test.createNode(new GherkinKeyword("And"), "Verify Browsing Invalid income document format");
			hook.actions.pause(6000).build().perform();
			hook.wait.until(ExpectedConditions.visibilityOf(hook.mp.Mypipelinepage_UploadPopup_BrowseFiles_link));
			String f1 = FileReaderManager.getFileReaderManagerInstance().getConfigInstance().getUploadFile();
			hook.driver.findElement(By.cssSelector("input[type='file']")).sendKeys(f1);
			hook.actions.pause(3000).build().perform();
			try {
				if (hook.mp.Mypipelinepage_UploadPopup_FirstFileName_text.isDisplayed()
						&& hook.mp.Mypipelinepage_UploadPopup_SecondFileName_text.isDisplayed()) {

					loginfo.log(Status.FAIL, "Invalid format document got uploaded ");
				}
			} catch (Exception e) {
				loginfo.log(Status.PASS, "In upload documents Invalid format(other than PDF) document not uploaded ");
			}

		} catch (Exception e) {
			fname = hook.cm.addScreenshot(testContext);
			loginfo.log(Status.FAIL, e.getMessage());
			loginfo.addScreenCaptureFromPath(fname);

		}

	}

	@Then("^Verify uploaded document \"(.*)\" name alignment in grid$")
	public void verifyDocumentLoanAlignmentInGrid(String documentName) throws Exception {

		ExtentTest loginfo = null;
		try {
			loginfo = test.createNode(new GherkinKeyword("Then"),
					"Verify uploaded document " + documentName + " name alignment in grid");
			hook.wait.until(ExpectedConditions.visibilityOf(hook.lp.LoanLandingPage_UploadDocuments_button));
			hook.wait.until(ExpectedConditions.visibilityOf(hook.gp.GenericPage_Upload_PopUp_title));
//			System.out.println(hook.lp.LoanLandingPage_Uploaded_Documents.size() + " documents uploaded");
			List<WebElement> listOfDocs = hook.driver.findElements(By.xpath("//div[@class='info-box']/div"));
			loginfo.log(Status.INFO, hook.lp.LoanLandingPage_Uploaded_Documents.size() + " documents uploaded");
			int listOfDocsSize = hook.lp.LoanLandingPage_Uploaded_Documents.size();
			String uploadedMismoFileName = listOfDocs.get(listOfDocs.size() - 1)
					.getText();
			System.out.println(uploadedMismoFileName + " document is uploaded");
			//div[@class='info-box']/div
			if (uploadedMismoFileName.length() > 22) {
				String attributeValue1 = listOfDocs.get(0).getAttribute("class");
				Assert.assertEquals(attributeValue1, "tooltip");
				loginfo.log(Status.PASS, "File size is larger than the Grid and displayed tooltip");
			} else if (uploadedMismoFileName.length() < 23) {
				String attributeValue1 = listOfDocs.get(listOfDocs.size() - 1).getAttribute("class");
				Assert.assertEquals(attributeValue1, "");
				loginfo.log(Status.PASS, "File name displayed with in the Grid length");
				loginfo.log(Status.INFO, "File size is lesser or equal to Grid supported lenght");
			} else {
				loginfo.log(Status.FAIL, "File not uploaded successfully");
			}
		} catch (Exception e) {
			fname = hook.cm.addScreenshot(testContext);
			loginfo.log(Status.FAIL, e.getMessage());
			loginfo.addScreenCaptureFromPath(fname);
		}
	}

	@Then("^Verify Grid view with uploaded documents and then Change to List view$")
	public void VerifyGridviewwithuploadeddocumentsandthenChangetoListview() throws Exception {
		ExtentTest loginfo = null;
		try {
			loginfo = test.createNode(new GherkinKeyword("Then"),
					"Verify Grid view with uploaded documents and then Change to List view");
			hook.wait.until(ExpectedConditions.visibilityOf(hook.lp.LoanLandingPage_UploadDocuments_gridViewButton));
			hook.lp.LoanLandingPage_UploadDocuments_gridViewButton.click();
			hook.actions.pause(2000).build().perform();
			String gridAttributeValue = hook.lp.LoanLandingPage_UploadDocuments_gridViewButton.getAttribute("class");
			loginfo.log(Status.INFO,
					"Grid view attribute value is" + gridAttributeValue + " once we clicked on Grid view");
			if (gridAttributeValue.contains("grid active") & hook.lp.LoanLandingPage_Uploaded_PDFDocuments.size() > 0
					& hook.lp.LoanLandingPage_Uploaded_PDFDocumentsStatus.size() >= 0) {
				loginfo.log(Status.PASS, "Clicked on Grid view and "
						+ hook.lp.LoanLandingPage_Uploaded_PDFDocuments.size() + " documents displayed in grid view");
			} else {
				loginfo.log(Status.FAIL, "Clicked on Grid view and but Grid view is not enabled");
			}
			hook.actions.pause(2000).build().perform();
			hook.lp.LoanLandingPage_UploadDocuments_TableViewButton.click();
			String tableAttributeVal = hook.lp.LoanLandingPage_UploadDocuments_TableViewButton.getAttribute("class");
			if (tableAttributeVal.contains("table active") & hook.lp.LoanLandingPage_Uploaded_PDFDocuments.size() > 0) {
				loginfo.log(Status.PASS, "Clicked on Table view and "
						+ hook.lp.LoanLandingPage_Uploaded_PDFDocuments.size() + " documents displayed in Table view");
			} else {
				loginfo.log(Status.FAIL, "Clicked on Table view and but Table view is not enabled");
			}
		} catch (Exception e) {
			fname = hook.cm.addScreenshot(testContext);
			loginfo.log(Status.FAIL, e.getMessage());
			loginfo.addScreenCaptureFromPath(fname);
		}
	}

	@Then("^Click on Grid button then verify \"(.*)\" ribbon for newly uploaded \"(.*)\" document$")
	public void Click_on_Grid_button_then_verify_New_ribbon_in_listed_documents(String ribbonMsg, String docName)
			throws Exception {
		ExtentTest loginfo = null;
		try {
			loginfo = test.createNode(new GherkinKeyword("Then"),
					"Click on Grid button then verify new ribbon in listed documents");
			hook.actions.pause(4000).build().perform();
			hook.wait.until(ExpectedConditions.visibilityOf(hook.lp.LoanLandingPage_UploadDocuments_gridViewButton));
			hook.lp.LoanLandingPage_UploadDocuments_gridViewButton.click();
			String gridAttributeValue = hook.lp.LoanLandingPage_UploadDocuments_gridViewButton.getAttribute("class");
			loginfo.log(Status.INFO,
					"Grid view attribute value is" + gridAttributeValue + " once we clicked on Grid view");
			if (gridAttributeValue.contains("grid active")
					& hook.lp.LoanLandingPage_Uploaded_PDFDocumentsStatus.size() >= 0) {
				List<WebElement> ribons = hook.driver.findElements(By.xpath("//*[contains(text(),'"+docName+"')]"
						+ "/ancestor::bki-grid-view//div[contains(text(),'"+ribbonMsg+"')]"));
				if (ribons.get(ribons.size() - 1).getText().contains(ribbonMsg)) {
					loginfo.log(Status.INFO,
							"Clicked on Grid view and " + hook.lp.LoanLandingPage_Uploaded_PDFDocuments.size()
									+ " documents displayed in grid view");
					loginfo.log(Status.PASS,
							" New ribbon is displayed and there are "
									+ hook.lp.LoanLandingPage_Uploaded_PDFDocumentsStatus.size()
									+ " documents available with " + ribbonMsg + " ribbon");
				}

			} else {
				loginfo.log(Status.FAIL, "Clicked on Grid view and but there are no new document with New ribbon");
			}
		} catch (Exception e) {
			fname = hook.cm.addScreenshot(testContext);
			loginfo.log(Status.FAIL, e.getMessage());
			loginfo.addScreenCaptureFromPath(fname);
		}
	}

	@Then("^Verify invalid file upload error message \"(.*)\"$")
	public void VeryErrorMessageWithInvalidDoc(String expectedErrMsg) throws Exception {
		ExtentTest loginfo = null;
		try {
			loginfo = test.createNode(new GherkinKeyword("Then"), "Verify invalid file upload error message");
			hook.wait.until(ExpectedConditions.visibilityOf(hook.lp.LoanLandingPage_UploadDocuments_button));
			hook.wait.until(ExpectedConditions.visibilityOf(hook.gp.GenericPage_Upload_PopUp_title));
			System.out.println(hook.lp.LoanLandingPage_Uploaded_Documents.size() + " documents uploaded");
			List<WebElement> listOfDocuments = hook.driver.findElements(By.xpath("//div[@class='mismo-file']"));
			loginfo.log(Status.INFO, hook.lp.LoanLandingPage_Uploaded_Documents.size() + " documents uploaded");

			for (int i = 0; i < listOfDocuments.size(); i++) {
				String documentName = listOfDocuments.get(i).getText();
				if (!documentName.contains("corrupted")) {
					hook.wait.until(ExpectedConditions.visibilityOf(hook.lp.UploadErrorMessage1));
					String errorMessage = hook.lp.UploadErrorMessage1.getText();
					String errorMessage2 = hook.lp.UploadErrorMessage2.getText();
					if (expectedErrMsg.contains(errorMessage) & expectedErrMsg.contains(errorMessage2)) {
						loginfo.log(Status.PASS, "Error message displayed when we upload Invalid documents");
					} else {
						loginfo.log(Status.FAIL, "Error message is not displaying when we upload invalid document");
					}

				}
			}
		} catch (Exception e) {
			fname = hook.cm.addScreenshot(testContext);
			loginfo.log(Status.FAIL, e.getMessage());
			loginfo.addScreenCaptureFromPath(fname);
		}

	}

	@When("^User Selects Grid Doc option$")
	public void UserclicksGridDoc() throws Exception {
		ExtentTest loginfo = null;
		try {
			loginfo = test.createNode(new GherkinKeyword("And"), "User Selects Grid Doc option");
			hook.lp.DocumentsTab_Grid_Option.click();
			loginfo.log(Status.PASS, "User Selects Grid Doc option");

		} catch (AssertionError e) {
			fname = hook.cm.addScreenshot(testContext);
			loginfo.log(Status.FAIL, "Fail- Grid option is not displayed" + e.getMessage());
			loginfo.addScreenCaptureFromPath(fname);
		}

	}

	@And("^User clicks Ellipses Document option$")
	public void UserclicksEllipsesDocumentoption() throws Exception {
		ExtentTest loginfo = null;
		try {
			loginfo = test.createNode(new GherkinKeyword("And"), "User clicks Ellipses Document option");
			hook.wait.until(ExpectedConditions.visibilityOf(hook.lp.DocumentsTab_Elispses_Option));
			hook.lp.DocumentsTab_Elispses_Option.click();
			loginfo.log(Status.PASS, "User clicks Ellipses Document option");

		} catch (AssertionError e) {
			fname = hook.cm.addScreenshot(testContext);
			loginfo.log(Status.FAIL, "Fail- User clicks Ellipses Document option not displayed" + e.getMessage());
			loginfo.addScreenCaptureFromPath(fname);
		}

	}

	@Then("^User should be able to view \"(.*)\" message in UI$")
	public void deletePopupshoulddisplay(String message) throws Exception {
		ExtentTest loginfo = null;
		try {
			if(message.contains("Clear Condition?")) {
				System.out.println("Debug");
			}
			loginfo = test.createNode(new GherkinKeyword("Then"), message + " message should display");
			String actualMessage = hook.driver.findElement(By.xpath("//*[contains(text(),'" + message + "')]"))
					.getText();
			if(actualMessage.trim()!=null) {
				Assert.assertEquals(message.trim(), actualMessage.trim());
				loginfo.log(Status.PASS, "Expected Message is displayed " + actualMessage);
			}else {
				loginfo.log(Status.FAIL, "Expected Message is not displayed " + actualMessage);
			}
			
		} catch (AssertionError e) {
			fname = hook.cm.addScreenshot(testContext);
			loginfo.log(Status.FAIL, "Fail- Popup message is not displayed" + e.getMessage());
			loginfo.addScreenCaptureFromPath(fname);
		}

	}

	@And("^Verify button \"(.*)\" on the page$")
	public void verifyWebButton(String buttonName) throws Exception {
		ExtentTest loginfo = null;
		try {
			loginfo = test.createNode(new GherkinKeyword("And"), "Verify button "+buttonName+" on the page");
			String changingNameToUCase = buttonName.toLowerCase();
			WebElement button = hook.driver.findElement(By.xpath("//button[contains(@class,'button')]/span[contains(text(),'"+ changingNameToUCase + "')]|//*[contains(text(),'" + buttonName + "')]|//button[contains(@class,'button')]/span[contains(text(),'"+ changingNameToUCase + "')]|//span[contains(text(),'" + buttonName + "')]"));
			
			if (button.isDisplayed()|button.isEnabled()) {
				loginfo.log(Status.PASS, "Button " + buttonName + " is displayed ");
			}
			else
			{
				loginfo.log(Status.FAIL, "Button " + buttonName + " is not displayed ");
			}
		} catch (Exception e) {
			fname = hook.cm.addScreenshot(testContext);
			loginfo.log(Status.FAIL, "Fail- Popup message is not displayed" + e.getMessage());
			loginfo.addScreenCaptureFromPath(fname);
		}

	}

	@Then("^Verify document count \"(.*)\" in document tab heading and icons$")
	public void Verifydocumentcountindocumenttabheading(String count) throws Exception {
		ExtentTest loginfo = null;
		try {
			loginfo = test.createNode(new GherkinKeyword("Then"),
					"Verify document count " + count + " in document tab heading");
			hook.wait.until(ExpectedConditions.visibilityOf(hook.lp.LoanLandingPag_DocumentsTab_Heading_count));
			if (hook.lp.LoanLandingPag_DocumentsTab_Heading_count.isDisplayed()
					&& hook.lp.LoanLandingPag_DocumentsTab_Heading_count.getText().equalsIgnoreCase(count)) {
				loginfo.log(Status.PASS, "Successfully document count displayed in document tab" + count);
			} else {
				loginfo.log(Status.FAIL, "Document count not displayed properly" + count);
			}
			if (hook.lp.LoanLandingPage_UploadDocuments_gridViewButton.isDisplayed()
					&& hook.lp.LoanLandingPage_UploadDocuments_TableViewButton.isDisplayed()) {
				loginfo.log(Status.PASS, "Successfully Grid and Table icons displayed in document tab");
			} else {
				loginfo.log(Status.FAIL, "Grid and Table icons not displayed");
			}

		} catch (Exception e) {
			fname = hook.cm.addScreenshot(testContext);
			loginfo.log(Status.FAIL, e.getMessage());
			loginfo.addScreenCaptureFromPath(fname);
		}

	}

	@Then("^Verify search option and search doc in document tab \"(.*)\"$")
	public void Verifysearchoptionsearchdocindocumenttab(String doc) throws Exception {
		ExtentTest loginfo = null;
		try {
			loginfo = test.createNode(new GherkinKeyword("Then"), "Verify search option & search doc in document tab");
			hook.wait.until(ExpectedConditions.visibilityOf(hook.lp.LoanLandingPag_DocumentsTab_Searchdoc_input));
			if (hook.lp.LoanLandingPag_DocumentsTab_Searchdoc_input.isDisplayed()) {
				loginfo.log(Status.PASS, "Successfully search option displayed");
			} else {
				loginfo.log(Status.FAIL, "Search option not displayed");
			}
			hook.wait.until(ExpectedConditions.visibilityOf(hook.lp.LoanLandingPag_DocumentsTab_Searchdoc_input));
			hook.lp.LoanLandingPag_DocumentsTab_Searchdoc_input.click();
			hook.lp.LoanLandingPag_DocumentsTab_Searchdoc_input.clear();
			hook.lp.LoanLandingPag_DocumentsTab_Searchdoc_input.sendKeys(doc);
			hook.actions.pause(5000).build().perform();
			hook.wait.until(ExpectedConditions
					.visibilityOfAllElements(hook.lp.LoanLandingPag_DocumentsTab_Documentlist_Gridview));
			for (int i = 0; i < hook.lp.LoanLandingPag_DocumentsTab_Documentlist_Gridview.size(); i++) {
				if (hook.lp.LoanLandingPag_DocumentsTab_Documentlist_Gridview.get(i).getText().equalsIgnoreCase(doc)) {
					loginfo.log(Status.PASS, "Search results displayed properly: "
							+ hook.lp.LoanLandingPag_DocumentsTab_Documentlist_Gridview.get(i).getText());
				} else {
					loginfo.log(Status.FAIL, "Seacr results not displayed properly for : " + doc);
				}

			}
		} catch (Exception e) {
			fname = hook.cm.addScreenshot(testContext);
			loginfo.log(Status.FAIL, e.getMessage());
			loginfo.addScreenCaptureFromPath(fname);
		}
	}

	@Then("^Verify Document search status and search status \"(.*)\"$")
	public void VerifyDocumentsearchstausandsearchstatus(String status) throws Exception {
		ExtentTest loginfo = null;
		try {
			loginfo = test.createNode(new GherkinKeyword("Then"),
					"Verify Document search staus and search status" + status);
			hook.wait.until(
					ExpectedConditions.visibilityOf(hook.lp.LoanLandingPag_DocumentsTab_DocumentStatus_Dropdown));
			if (hook.lp.LoanLandingPag_DocumentsTab_DocumentStatus_Dropdown.isDisplayed()) {
				loginfo.log(Status.PASS, "Successfully Document search dropdown displayed");
			} else {
				loginfo.log(Status.FAIL, "Document search dropdown not displayed");
			}

			hook.wait.until(
					ExpectedConditions.visibilityOf(hook.lp.LoanLandingPag_DocumentsTab_DocumentStatus_Dropdown));
			hook.actions.pause(8000).build().perform();
			hook.wait.until(ExpectedConditions
					.elementToBeClickable(hook.lp.LoanLandingPag_DocumentsTab_DocumentStatus_Dropdown));
			WebElement element = hook.lp.LoanLandingPag_DocumentsTab_DocumentStatus_Dropdown;
			JavascriptExecutor js = (JavascriptExecutor) hook.driver;
			js.executeScript("arguments[0].click();", element);
			hook.wait.until(ExpectedConditions
					.visibilityOfAllElements(hook.lp.LoanLandingPag_DocumentsTab_DocumentStatus_DropdownValues));
			for (int i = 0; i < hook.lp.LoanLandingPag_DocumentsTab_DocumentStatus_DropdownValues.size(); i++) {
				if (hook.lp.LoanLandingPag_DocumentsTab_DocumentStatus_DropdownValues.get(i).getText()
						.equalsIgnoreCase(status)) {
					loginfo.log(Status.PASS, "Search results displayed properly: "
							+ hook.lp.LoanLandingPag_DocumentsTab_DocumentStatus_DropdownValues.get(i).getText());
					hook.lp.LoanLandingPag_DocumentsTab_DocumentStatus_DropdownValues.get(i).click();
					break;
				}
			}
			hook.wait.until(ExpectedConditions.visibilityOf(hook.lp.LoanLandingPag_DocumentsTab_SearchDocument_status));
			loginfo.log(Status.INFO, hook.lp.LoanLandingPag_DocumentsTab_SearchDocument_status.getText().trim());
			loginfo.log(Status.INFO, hook.lp.LoanLandingPag_DocumentsTab_SearchDocument_status.getText());
			if (status.contains(hook.lp.LoanLandingPag_DocumentsTab_SearchDocument_status.getText().trim())) {
				loginfo.log(Status.PASS,
						"After selecting dropdown search displayed with " + status + " option properly");
			} else {
				loginfo.log(Status.FAIL, "Search status" + status + " option not displayed as selection search option");
			}

		} catch (Exception e) {
			fname = hook.cm.addScreenshot(testContext);
			loginfo.log(Status.FAIL, e.getMessage());
			loginfo.addScreenCaptureFromPath(fname);
		}

	}

	@Then("^Verify document status search results in grid view \"(.*)\"$")
	public void Verifydocumentstatussearchresultsingridview(String status) throws Exception {
		ExtentTest loginfo = null;
		try {
			loginfo = test.createNode(new GherkinKeyword("Then"),
					"Verify document status search results in grid view " + status);

			if (hook.lp.LoanLandingPage_UploadDocuments_gridViewButton.getAttribute("class").contains("grid active")) {
				if (hook.lp.LoanLandingPag_DocumentsTab_DocumentStatus_Gridview_RibbonList.isEmpty()) {
					for (int j = 0; j < hook.lp.LoanLandingPag_DocumentsTab_Documentlist_Gridview.size(); j++) {
						loginfo.log(Status.PASS,
								"In Grid view search results displayed : " + "<br />" + "status :" + status
										+ "document :"
										+ hook.lp.LoanLandingPag_DocumentsTab_Documentlist_Gridview.get(j).getText());
					}
				} else {
					for (int j = 0; j < hook.lp.LoanLandingPag_DocumentsTab_Documentlist_Gridview.size(); j++) {
						if (status
								.equalsIgnoreCase(hook.lp.LoanLandingPag_DocumentsTab_DocumentStatus_Gridview_RibbonList
										.get(0).getText())) {
							loginfo.log(Status.PASS, "In Grid view search results displayed only " + status
									+ " status documents properly" + "<br />" + "status :" + status + "document :"
									+ hook.lp.LoanLandingPag_DocumentsTab_Documentlist_Gridview.get(j).getText());
						}
					}

				}
			} else

			{
				loginfo.log(Status.FAIL,"Grid view is not in active state");
			}
			
		} catch (Exception e) {

			fname = hook.cm.addScreenshot(testContext);
			loginfo.log(Status.FAIL, e.getMessage());
			loginfo.addScreenCaptureFromPath(fname);

		}
	}
	@Then("^Verify document status search results in Table view \"(.*)\"$")
	public void Verifydocumentstatussearchresultsintableview(String status) throws Exception {
		ExtentTest loginfo = null;
		try {
			loginfo = test.createNode(new GherkinKeyword("Then"),
					"Verify document status search results in Table view" + status);
						if (hook.lp.LoanLandingPage_UploadDocuments_TableViewButton.getAttribute("class").contains("table active"))
						{
				for (int j = 0; j < hook.lp.LoanLandingPag_DocumentsTab_Documentsname_TableviewList.size(); j++) {
					loginfo.log(Status.PASS, "Search results displayed in Table view  " + "document :"
							+ hook.lp.LoanLandingPag_DocumentsTab_Documentsname_TableviewList.get(j).getText());
				}
			}
						else
						{
							loginfo.log(Status.FAIL,"Table view is not in active state");
						}
		} catch (Exception e) {

			fname = hook.cm.addScreenshot(testContext);
			loginfo.log(Status.FAIL, e.getMessage());
			loginfo.addScreenCaptureFromPath(fname);

		}
	}
	
	@Then("^Click on trash button to delete the document$")
	public void clickInTrashButtonToDeleteDocument() throws Exception {
		ExtentTest loginfo = null;
		try {
			loginfo = test.createNode(new GherkinKeyword("Then"), "Click on trash button to delete the document");
			hook.wait.until(ExpectedConditions.visibilityOf(hook.lp.LoanLandingPage_DocumentsTab_TrashButton));
			if (hook.lp.LoanLandingPage_DocumentsTab_TrashButton.isDisplayed()) {
				hook.lp.LoanLandingPage_DocumentsTab_TrashButton.click();
				hook.actions.pause(4000).build().perform();
				loginfo.log(Status.PASS, "Successfully deleted the document");
			} else {
				loginfo.log(Status.FAIL, "Trash button not available to delete");
			}
		} catch (Exception e) {
			fname = hook.cm.addScreenshot(testContext);
			loginfo.log(Status.FAIL, e.getMessage());
			loginfo.addScreenCaptureFromPath(fname);
		}
	}

	@Then("^Select below documents from the list$")
	public void select_below_documents_from_the_List(DataTable documents) throws Exception {
		ExtentTest loginfo = null;
		try {
			loginfo = test.createNode(new GherkinKeyword("Then"), "Click on trash button to delete the document");
			List<String> docList = documents.asList(String.class);
			for (int i = 1; i <= docList.size(); i++) {
				for (int j = 1; j < hook.lp.LoanLandingPag_DocumentsTab_ListOfDocsInTable.size(); j++) {
					String docName = hook.driver
							.findElement(By.xpath("//table[@matsortactive='docName']/tbody/tr[" + j + "]/td[2]"))
							.getText();
					if (docList.get(i-1).equalsIgnoreCase(docName)) {
						loginfo.log(Status.PASS, "Document is avaliable in the list and selected");
						hook.driver.findElement(By.xpath("//table[@matsortactive='docName']/tbody/tr[" + i + "]/td[1]/mat-checkbox"))
								.click();
						break;
					}
				}

			}

		} catch (Exception e) {
			fname = hook.cm.addScreenshot(testContext);
			loginfo.log(Status.FAIL, e.getMessage());
			loginfo.addScreenCaptureFromPath(fname);
		}
	}

	@Then("^User will be on table view option$")
	public void user_will_be_on_Table_view() throws Exception {
		ExtentTest loginfo = null;
		try {
			loginfo = test.createNode(new GherkinKeyword("Then"), "User will be on table view option");
			hook.wait.until(ExpectedConditions.visibilityOf(hook.lp.LoanLandingPage_UploadDocuments_TableViewButton));
			String tableViewAttribute = hook.lp.LoanLandingPage_UploadDocuments_TableViewButton.getAttribute("class");
			if (tableViewAttribute.contains("table active")) {
				loginfo.log(Status.PASS, "User is in table view");
			}
		} catch (Exception e) {
			fname = hook.cm.addScreenshot(testContext);
			loginfo.log(Status.FAIL, e.getMessage());
			loginfo.addScreenCaptureFromPath(fname);
		}
	}

	@Then("^Verify below document unavailability$")
	public void verify_document_document_Unavailablity(DataTable documents) throws Exception {
		ExtentTest loginfo = null;
		try {
			loginfo = test.createNode(new GherkinKeyword("Then"), "User will be on table view option");
			List<String> docList = documents.asList(String.class);
			for (int i = 1; i <= docList.size(); i++) {
				List<WebElement> documentsPostDelete = hook.driver
						.findElements(By.xpath("//span[text()='" + docList.get(i) + "']"));
				if (documentsPostDelete.size() == 0) {
					loginfo.log(Status.PASS, docList.get(i) + " document has been deleted from the List view");
				}
			}
		} catch (Exception e) {
			fname = hook.cm.addScreenshot(testContext);
			loginfo.log(Status.FAIL, e.getMessage());
			loginfo.addScreenCaptureFromPath(fname);
		}
	}
	
	
}