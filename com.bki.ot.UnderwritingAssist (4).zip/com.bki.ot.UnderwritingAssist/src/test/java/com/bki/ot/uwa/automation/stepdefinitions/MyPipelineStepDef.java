package com.bki.ot.uwa.automation.stepdefinitions;

import java.util.List;
import java.util.Map;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.GherkinKeyword;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;
import com.bki.ot.uwa.automation.extentreport.ExtentReportConfig;
import com.bki.ot.uwa.automation.filereadermanager.FileReaderManager;
import com.bki.ot.uwa.automation.testcontext.TestContext;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class MyPipelineStepDef extends ExtentReportConfig {

	Hooks hook;
	TestContext testContext;
	String url = null;
	public static String fname;

	public MyPipelineStepDef(TestContext context) {
		testContext = context;
		hook = new Hooks(context);
		url = FileReaderManager.getFileReaderManagerInstance().getConfigInstance().getUrl();

	}

	@When("^Click Loan Number$")
	public void ClickonLoanNumber() throws Exception {
		ExtentTest loginfo = null;
		try {
			loginfo = test.createNode(new GherkinKeyword("When"), "Click on Loan Number " + Hooks.loannum);
			hook.actions.pause(6000).build().perform();
			hook.wait.until(
					ExpectedConditions.visibilityOfAllElements(hook.mp.Mypipelinepage_Grid_LoanNumber_Data_list));
			for (int i = 0; i < hook.mp.Mypipelinepage_Grid_LoanNumber_Data_list.size(); i++) {
				if (hook.mp.Mypipelinepage_Grid_LoanNumber_Data_list.get(i).getText().equalsIgnoreCase(Hooks.loannum)) {
					loginfo.log(Status.PASS, "Successfull clicked on Loan Number : "
							+ hook.mp.Mypipelinepage_Grid_LoanNumber_Data_list.get(i).getText());
				hook.mp.Mypipelinepage_Grid_LoanNumber_Data_list.get(i).click();
					break;
				}
			}
			hook.wait.until(ExpectedConditions.visibilityOf(hook.gp.GenericPage_PageTitle));
		} catch (Exception e) {
			fname = hook.cm.addScreenshot(testContext);
			loginfo.log(Status.FAIL, e.getMessage());
			loginfo.addScreenCaptureFromPath(fname);

		}

	}

	@When("^Loan number displayed with status in mypipeline \"(.*)\" \"(.*)\"$")
	public void Loannumberdisplayedwithstatusinmypipeline(String loan, String status) throws Exception {
		ExtentTest loginfo = null;
		try {
			loginfo = test.createNode(new GherkinKeyword("When"), "Loan number displayed with status in mypipeline");
			hook.wait.until(ExpectedConditions.visibilityOfAllElements(hook.mp.Mypipelinepage_Menu_section));
			WebElement lstatus = hook.driver.findElement(By.xpath("//*[@role='gridcell'][contains(text(),'" + loan
					+ "')]/following::span[contains(@class,'status')][1]"));
			if (lstatus.getText().equalsIgnoreCase(status)) {
				loginfo.log(Status.PASS,
						"The status displayed properly for Loan :" + loan + " status :" + lstatus.getText());
			} else {
				loginfo.log(Status.FAIL, "The status displayed not properly for Loan " + lstatus);
			}

		} catch (Exception e) {

			fname = hook.cm.addScreenshot(testContext);
			loginfo.log(Status.FAIL, e.getMessage());
			loginfo.addScreenCaptureFromPath(fname);

		}
	}

	@Then("^Display grid value as \"(.*)\"$")
	public void VerifygridvaluebyLoantype(String gridValue) throws Exception {
		ExtentTest loginfo = null;
		try {

			loginfo = test.createNode(new GherkinKeyword("Then"), "User Loantypes" + gridValue);
			hook.wait.until(ExpectedConditions.visibilityOf(hook.mp.Mypipeline_LoanType_DataList_WithGridValue));
			loginfo.log(Status.INFO,
					"Displayed " + hook.mp.Mypipeline_LoanType_DataList.size() + " number of results for " + gridValue);
			for (int i = 0; i < hook.mp.Mypipeline_LoanType_DataList.size(); i++) {
				String diplayeLoanTypeInGrid = hook.mp.Mypipeline_LoanType_DataList.get(0).getText();

				if (diplayeLoanTypeInGrid.equalsIgnoreCase(gridValue)) {
					loginfo.log(Status.PASS, "Matching the LoanType " + diplayeLoanTypeInGrid + " selected in grid");
				} else {
					loginfo.log(Status.FAIL,
							"Not Matching the LoanType " + diplayeLoanTypeInGrid + " selected in grid");
				}
			}

		} catch (Exception e) {
			fname = hook.cm.addScreenshot(testContext);
			loginfo.log(Status.FAIL, e.getMessage());
			loginfo.addScreenCaptureFromPath(fname);

		}
	}

	@And("^Search Header fields should display$")
	public void SearchHeaderFieldsShouldDisplay(DataTable dt) throws Exception {
		ExtentTest loginfo = null;
		try {
			loginfo = test.createNode(new GherkinKeyword("And"), "Search Header fields should display");
			List<String> list = dt.asList(String.class);

			for (int j = 0; j < list.size(); j++) {

				if (list.get(j).equalsIgnoreCase(hook.mp.Mypipelinepage_SearchOptions_list.get(j).getText())) {
					loginfo.log(Status.PASS, "Search Header field displayed : "
							+ hook.mp.Mypipelinepage_SearchOptions_list.get(j).getText());
				} else {
					loginfo.log(Status.FAIL, MarkupHelper
							.createLabel("Search Header field not displayed : " + list.get(j), ExtentColor.RED));
				}
			}
			if (list.size() == hook.mp.Mypipelinepage_SearchOptions_list.size()
					&& hook.mp.Mypipelinepage_ClearSearch_link.getText().equalsIgnoreCase("Clear search")) {
				loginfo.log(Status.PASS, "Clear Search link displayed and all the search header fields displayed");
			} else {
				loginfo.log(Status.FAIL, "Clear Search link not displayed and search header fields are not displayed");
			}

		} catch (Exception e) {
			fname = hook.cm.addScreenshot(testContext);
			loginfo.log(Status.FAIL, e.getMessage());
			loginfo.addScreenCaptureFromPath(fname);

		}

	}

	@Then("^MENU and Pipeline should display in left Panel$")
	public void MENUandPipelineshoulddisplayonleftside(DataTable dt) throws Exception {
		ExtentTest loginfo = null;
		try {
			loginfo = test.createNode(new GherkinKeyword("Then"), "MENU and Pipeline should display in left Panel");
			List<Map<String, String>> data = dt.asMaps(String.class, String.class);
			Assert.assertTrue(hook.mp.Mypipelinepage_Logo.isDisplayed()
					&& hook.mp.Mypipelinepage_Pipeline_Folder_icon.isDisplayed() && data.get(0).get("PanelHeading1")
							.equalsIgnoreCase(hook.mp.Mypipelinepage_LeftPanel_PipelineHeading.getText()));
			loginfo.log(Status.PASS, "Logo displayed and Folder icon displayed adjucent to pipeline section");
			loginfo.log(Status.PASS, "Left panel Heading displayed properly :" + "<br />"
					+ hook.mp.Mypipelinepage_LeftPanel_PipelineHeading.getText());
			if (data.get(0).get("Section").equalsIgnoreCase(hook.mp.Mypipelinepage_Menu_section.getText())
					&& data.get(0).get("Page Header").equals(hook.mp.Mypipelinepage_Logo_text.getText())) {
				loginfo.log(Status.PASS,
						"Page Header displayed successfully : " + hook.mp.Mypipelinepage_Logo_text.getText());
				loginfo.log(Status.PASS,
						"Menu section displayed successfully :" + hook.mp.Mypipelinepage_Menu_section.getText());
			} else {
				loginfo.log(Status.FAIL, "Menu section and page Header are not displayed");
			}
			if (hook.mp.Mypipelinepage_Menu_section.getCssValue("text-transform").equalsIgnoreCase("uppercase")) {
				loginfo.log(Status.PASS, "MENU section displayed in upper case");
			} else {
				loginfo.log(Status.FAIL, "Menu section not displayed in upper case"
						+ hook.mp.Mypipelinepage_Menu_section.getCssValue("text-transform"));
			}
			if (hook.mp.Mypipelinepage_Menu_section.getCssValue("padding-left").isEmpty()
					&& hook.mp.Mypipelinepage_LeftPanel_PipelineHeading.getCssValue("padding-left").isEmpty()) {
				loginfo.log(Status.FAIL, "Menu and pipeline sections not displayed in Left panel");
			} else {
				loginfo.log(Status.PASS, "Menu and pipeline sections successfully displayed in Left Panel");
			}
		} catch (AssertionError e) {
			fname = hook.cm.addScreenshot(testContext);
			loginfo.log(Status.FAIL, "Verify Logo,Folder Icon,Left panel Headings" + e.getMessage());
			loginfo.addScreenCaptureFromPath(fname);
		} catch (Exception e) {
			fname = hook.cm.addScreenshot(testContext);
			loginfo.log(Status.FAIL, e.getMessage());
			loginfo.addScreenCaptureFromPath(fname);

		}

	}

	@When("^User types invalid Loan Type in filter option and veriy in data grid$")
	public void validateInValidLoanTypeFilterDisplayInDataGrid(DataTable dt) throws Exception {
		ExtentTest loginfo = null;
		try {
			List<Map<String, String>> data = dt.asMaps(String.class, String.class);
			loginfo = test.createNode(new GherkinKeyword("When"),
					"User types invalid Loan Type in filter option and veriy in data gri");
			//String loanType = data.get(0).get("Loan Type").toString().toString();
			WebElement option=hook.mp.Mypipelinepage_filetType_dropdown;
			JavascriptExecutor js = (JavascriptExecutor) hook.driver;
			js.executeScript("arguments[0].click();", option);
			hook.actions.pause(2000).build().perform();
			hook.driver.findElement(By.xpath("//span[contains(text(),'" + data.get(0).get("Loan Type") + "')]"))
					.click();
			hook.mp.Mypipelinepage_filetType_dropdown.sendKeys(Keys.TAB);
			if (hook.mp.Mypipelinepage_filetType_dropdown.isDisplayed()) {
				hook.actions.pause(5000).build().perform();
				List<WebElement> loanTypeDataGridList = hook.driver
						.findElements(By.xpath("//td[contains(text(),'" + data.get(0).get("Loan Type") + "')]"));
				if (loanTypeDataGridList.size() > 0) {
					loginfo.log(Status.FAIL, "Loan Type  is sucessfully displayed in data grid");
				} else {
					loginfo.log(Status.PASS, "Loan Type  is not displayed in data grid");
				}

			} else {
				loginfo.log(Status.FAIL, "Loan Type  component is missing");
			}

		} catch (AssertionError e) {
			fname = hook.cm.addScreenshot(testContext);
			loginfo.log(Status.FAIL, "Loan Type component is missing" + e.getMessage());
			loginfo.addScreenCaptureFromPath(fname);

		}
	}

	@When("^Loan Type filter should display$")
	public void validateLoanTypeFilter() throws Exception {
		ExtentTest loginfo = null;
		try {
			loginfo = test.createNode(new GherkinKeyword("When"), "Loan Type filter should display");
			if (hook.mp.Mypipelinepage_filetType_dropdown.isDisplayed()) {
				loginfo.log(Status.PASS, "Loan Type component is displayed sucessfully");

			} else {
				loginfo.log(Status.FAIL, "Loan Type component is missing");
			}

		} catch (AssertionError e) {
			fname = hook.cm.addScreenshot(testContext);
			loginfo.log(Status.FAIL, "Loan Type component is missing" + e.getMessage());
			loginfo.addScreenCaptureFromPath(fname);

		}
	}

	@When("^User is on the My pipeline page$")
	public void userIsOnMyPipelinePage() throws Exception {
		ExtentTest loginfo = null;
		try {
			loginfo = test.createNode(new GherkinKeyword("When"), "User is on the My pipeline page");
			if (hook.mp.myPipeLinePageHeader.isDisplayed()) {

			} else {

			}
		} catch (AssertionError e) {
			fname = hook.cm.addScreenshot(testContext);
			loginfo.log(Status.FAIL, "Verify Loan status Inactive and Bg color is light purple" + e.getMessage());
			loginfo.addScreenCaptureFromPath(fname);

		}
	}

	@When("^Borrower Name filter should display$")
	public void BorrowerNamefiltershoulddisplay() throws Exception {
		ExtentTest loginfo = null;
		try {
			loginfo = test.createNode(new GherkinKeyword("When"), "Borrower Name filter should display");
			if (hook.mp.Mypipelinepage_FilterText_borrowerName.isDisplayed()) {
				loginfo.log(Status.PASS, "Borrower Name component is displayed sucessfully");

			} else {
				loginfo.log(Status.FAIL, "Borrower Name component is missing");
			}

		} catch (AssertionError e) {
			fname = hook.cm.addScreenshot(testContext);
			loginfo.log(Status.FAIL, "Verify Loan status Inactive and Bg color is light purple" + e.getMessage());
			loginfo.addScreenCaptureFromPath(fname);

		}
	}

	@When("^User types invalid Borrower Name in filter option and veriy in data grid$")
	public void validateInValidBrowserNameFilterDisplayInDataGrid(DataTable dt) throws Exception {
		ExtentTest loginfo = null;
		try {
			List<Map<String, String>> data = dt.asMaps(String.class, String.class);
			loginfo = test.createNode(new GherkinKeyword("When"),
					"User types invalid Borrower Name in filter option and veriy in data grid");
			if (hook.mp.Mypipelinepage_FilterText_borrowerName.isDisplayed()) {
				hook.actions.pause(5000).build().perform();
				List<WebElement> browserNameDataGridList = hook.driver
						.findElements(By.xpath("//td[contains(text(),'" + data.get(0).get("Browser Name") + "')]"));
				if (browserNameDataGridList.size() > 0) {
					loginfo.log(Status.FAIL, "Borrower Name is sucessfully displayed in data grid");
				} else {
					loginfo.log(Status.PASS, " Borrower Name is not displayed in data grid");
				}

			} else {
				loginfo.log(Status.FAIL, "Borrower Name component is missing");
			}

		} catch (AssertionError e) {
			fname = hook.cm.addScreenshot(testContext);
			loginfo.log(Status.FAIL, "Verify Loan status Inactive and Bg color is light purple" + e.getMessage());
			loginfo.addScreenCaptureFromPath(fname);

		}
	}

	@When("^Verify that User is able to filter valid Loan Type in data grid$")
	public void FilterbyLoanType(DataTable dt) throws Exception {
		ExtentTest loginfo = null;
		try {
			List<Map<String, String>> data = dt.asMaps(String.class, String.class);
			loginfo = test.createNode(new GherkinKeyword("When"),
					"Verify that User is able to filter valid Loan Type in data grid");
			WebElement option=hook.mp.Mypipelinepage_filetType_dropdown;
			JavascriptExecutor js = (JavascriptExecutor) hook.driver;
			js.executeScript("arguments[0].click();", option);
			hook.actions.pause(2000).build().perform();
			hook.driver.findElement(By.xpath("//span[contains(text(),'" + data.get(0).get("Loan Type") + "')]"))
					.click();
			hook.mp.Mypipelinepage_filetType_dropdown.sendKeys(Keys.TAB);
			if (hook.mp.Mypipelinepage_filetType_dropdown.isDisplayed()) {
				hook.actions.pause(5000).build().perform();
				List<WebElement> loanTypeDataGridList = hook.driver
						.findElements(By.xpath("//td[contains(text(),'" + data.get(0).get("Loan Type") + "')]"));
				if (loanTypeDataGridList.size() > 0) {
					loginfo.log(Status.PASS, "Loan Type  is not displayed in data grid");

				} else {
					loginfo.log(Status.FAIL, "Loan Type  is sucessfully displayed in data grid");
				}

			} else {
				loginfo.log(Status.FAIL, "Loan Type  component is missing");
			}

		} catch (AssertionError e) {
			fname = hook.cm.addScreenshot(testContext);
			loginfo.log(Status.FAIL, "Loan Type component is missing" + e.getMessage());
			loginfo.addScreenCaptureFromPath(fname);

		}
	}

	@Then("^Loan Number filter should display$")
	public void validateBrowserNameFilter() throws Exception {
		ExtentTest loginfo = null;
		try {
			loginfo = test.createNode(new GherkinKeyword("Then"), "Loan Number filter should display");
			if (hook.mp.Mypipelinepage_FilterText_LoanNumber.isDisplayed()) {
				loginfo.log(Status.PASS, "Loan Number component is displayed sucessfully");
			} else {
				loginfo.log(Status.FAIL, "Loan Number component is missing");
			}

		} catch (AssertionError e) {
			fname = hook.cm.addScreenshot(testContext);
			loginfo.log(Status.FAIL, "Verify Loan Number filter is not displayed" + e.getMessage());
			loginfo.addScreenCaptureFromPath(fname);
		}
	}

	@When("^Loan Number should filter and display in data grid")
	public void ValidateLoanNumberFilter(DataTable dt) throws Exception {
		ExtentTest loginfo = null;
		try {
			List<Map<String, String>> data = dt.asMaps(String.class, String.class);
			loginfo = test.createNode(new GherkinKeyword("When"),
					"Loan Number should filter and display in data grid");
			if (hook.mp.Mypipelinepage_FilterText_LoanNumber.isDisplayed()) {
				hook.actions.pause(5000).build().perform();
				String LoanNumber = data.get(0).get("Loan Number").toString().toString();
				hook.mp.Mypipelinepage_FilterText_LoanNumber.clear();
				hook.mp.Mypipelinepage_FilterText_LoanNumber.sendKeys(LoanNumber);
				hook.mp.Mypipelinepage_FilterText_LoanNumber.sendKeys(Keys.TAB);
				WebElement LoanNumberDataGrid = hook.driver
						.findElement(By.xpath("//td[contains(text(),'" + data.get(0).get("Loan Number") + "')]"));
				hook.wait.until(ExpectedConditions.visibilityOf(LoanNumberDataGrid));
				if (LoanNumberDataGrid.isDisplayed()) {
					loginfo.log(Status.PASS, "Loan Number is sucessfully displayed in data grid");
				} else {
					loginfo.log(Status.FAIL, "Loan Number is not displayed in data grid");
				}
			} else {

			}

		} catch (AssertionError e) {
			fname = hook.cm.addScreenshot(testContext);
			loginfo.log(Status.FAIL, "Verify Loan Number filter is not displayed" + e.getMessage());
			loginfo.addScreenCaptureFromPath(fname);
		}
	}

	@When("^Verify that User is able to filter valid Borrower Name in data grid$")
	public void FilterbyBorrowerName(DataTable dt) throws Exception {
		ExtentTest loginfo = null;
		try {
			List<Map<String, String>> data = dt.asMaps(String.class, String.class);
			loginfo = test.createNode(new GherkinKeyword("When"),
					"Verify that User is able to filter valid Borrower Name in data grid");
			if (hook.mp.Mypipelinepage_FilterText_borrowerName.isDisplayed()) {
				hook.actions.pause(5000).build().perform();
				String borrwename = data.get(0).get("Browser Name").toString().toString();
				hook.mp.Mypipelinepage_FilterText_borrowerName.clear();
				hook.mp.Mypipelinepage_FilterText_borrowerName.sendKeys(borrwename);
				hook.mp.Mypipelinepage_FilterText_borrowerName.sendKeys(Keys.TAB);
				WebElement browserNameDataGrid = hook.driver
						.findElement(By.xpath("//td[contains(text(),'" + data.get(0).get("Browser Name") + "')]"));
				hook.wait.until(ExpectedConditions.visibilityOf(browserNameDataGrid));
				if (browserNameDataGrid.isDisplayed()) {
					loginfo.log(Status.PASS, "Borrower Name is sucessfully displayed in data grid");
				} else {
					loginfo.log(Status.FAIL, "Borrower Name is not displayed in data grid");
				}

			} else {
				loginfo.log(Status.FAIL, "Borrower Name component is missing");
			}

		} catch (AssertionError e) {
			fname = hook.cm.addScreenshot(testContext);
			loginfo.log(Status.FAIL, "Borrower Name is not displayed in data grid" + e.getMessage());
			loginfo.addScreenCaptureFromPath(fname);

		}
	}

	@Then("^loan type should not get filter in data grid$")
	public void loantypeshouldnotgetfilterindatagrid() throws Exception {
		ExtentTest loginfo = null;
		try {
			loginfo = test.createNode(new GherkinKeyword("Then"), "loan type should not get filter in data grid");
			hook.wait.until(ExpectedConditions.visibilityOfAllElements(hook.mp.Mypipeline_LoanType_DataList));
			String[] loanTypes = { "Conventional", "VA", "FHA" };
			for (int i = 0; i < hook.mp.Mypipeline_LoanType_DataList.size(); i++) {
				String currType = hook.mp.Mypipeline_LoanType_DataList.get(i).getText().trim();
				boolean isMatched = false;
				for (String loanTypeStr : loanTypes) {
					if (currType.equals(loanTypeStr)) {
						loginfo.log(Status.PASS, "Matching the LoanType:" + currType);
						isMatched = true;
					}
				}
				if (!isMatched) {
					loginfo.log(Status.FAIL, "Not matching the LoanType:" + currType);
				}

			}
		} catch (Exception e) {
			fname = hook.cm.addScreenshot(testContext);
			loginfo.log(Status.FAIL, e.getMessage());
			loginfo.addScreenCaptureFromPath(fname);

		}
	}

	@Then("^Loantype filter should display$")
	public void Loantypefiltershoulddisplay() throws Exception {
		ExtentTest loginfo = null;
		Thread.sleep(1000);
		try {
			loginfo = test.createNode(new GherkinKeyword("Then"), "Loantype filter should display");
			hook.wait.until(ExpectedConditions.visibilityOf(hook.mp.Mypipeline_LoanType_title));
			Assert.assertTrue(hook.mp.Mypipeline_LoanType_title.getText().equalsIgnoreCase("Loan Type"));
			loginfo.log(Status.PASS, "Loantype filter is displayed");
		} catch (AssertionError e) {
			fname = hook.cm.addScreenshot(testContext);
			loginfo.log(Status.FAIL, "Verify Loantype filter is not displayed" + e.getMessage());
			loginfo.addScreenCaptureFromPath(fname);
		}
	}

	
	@When("^User Clicks DropdownList$")
	public void UserClicksDropdownList() throws Exception {
		ExtentTest loginfo = null;
		try {
			loginfo = test.createNode(new GherkinKeyword("When"), "User Clicks DropdownList");
			hook.wait.until(ExpectedConditions.visibilityOf(hook.mp.Mypipeline_LoanType_List));
			WebElement option=hook.mp.Mypipeline_LoanType_List;
			JavascriptExecutor js = (JavascriptExecutor) hook.driver;
			js.executeScript("arguments[0].click();", option);
			//hook.mp.Mypipeline_LoanType_List.click();
			loginfo.log(Status.PASS, "User Clicked on Dropdown");
			} catch (AssertionError e) {
			fname = hook.cm.addScreenshot(testContext);
			loginfo.log(Status.FAIL, "Verify Select Loan Type is not displayed" + e.getMessage());
			loginfo.addScreenCaptureFromPath(fname);
		}
	}

	@When("^User selects \"(.*)\"$")
	public void Userselects(String Loantypes) throws Exception {
		ExtentTest loginfo = null;
		try {

			loginfo = test.createNode(new GherkinKeyword("When"), "User Loantypes " + Loantypes);
			WebElement option = hook.driver.findElement(By.xpath("(//mat-option/span[(text()='" + Loantypes + "')])"));

			JavascriptExecutor js = (JavascriptExecutor) hook.driver;
			js.executeScript("arguments[0].click();", option);
			String selectedoption = hook.mp.Mypipeline_LoanType_List.getText();
			if (selectedoption.equalsIgnoreCase(Loantypes)) {
				loginfo.log(Status.PASS, "Matching the LoanType selected:" + selectedoption);
			} else {
				loginfo.log(Status.FAIL, "Not Matching the LoanType selected:" + selectedoption);
			}

		} catch (Exception e) {
			fname = hook.cm.addScreenshot(testContext);
			loginfo.log(Status.FAIL, e.getMessage());
			loginfo.addScreenCaptureFromPath(fname);

		}
	}
	
	@And("^Verify SAVE button disability while File upload is in Progress state$")
	public void Verify_SAVE_button_disability_while_File_upload_is_in_Progress_state() throws Exception {
		ExtentTest loginfo = null;
		try {
			loginfo = test.createNode(new GherkinKeyword("And"), "Verify SAVE button disability while File upload is in Progress state");			
			boolean progressingStatus=hook.mp.Mypipelinepage_FileUpload_Progress.isDisplayed();
			String saveButtonAttribute=hook.mp.Mypipelinepage_Save_Button.getAttribute("disabled");
			if ((saveButtonAttribute.equals("true"))&(progressingStatus)) {
				loginfo.log(Status.PASS, "Save button is disabled while uploading a document");
			} else {
				loginfo.log(Status.FAIL, "Save button is not disabled while uploading a document");
			}
		} catch (Exception e) {
			fname = hook.cm.addScreenshot(testContext);
			loginfo.log(Status.FAIL, e.getMessage());
			loginfo.addScreenCaptureFromPath(fname);

		}
	}
	
	@Then("^Verify that SAVE button should be enabled when file upload is 100 percent complete$")
	public void verify_that_SAVE_button_should_be_enabled_when_file_upload_is_100_percent_complete() throws Exception {
		ExtentTest loginfo = null;
		try {
			loginfo = test.createNode(new GherkinKeyword("Then"), "Verify that SAVE button should be enabled when file upload is 100 percent complete");			
			boolean progressingStatus=false;
			try {
				progressingStatus = hook.mp.Mypipelinepage_FileUpload_Progress.isDisplayed();
				progressingStatus=true;
				loginfo.log(Status.INFO, "Loan upload progressing percentage enabled though file uploaded successfully");
			} catch (Exception e) {
					loginfo.log(Status.INFO, "Loan upload progressing percentage disabled since file uploaded successfully");
			}
			boolean saveButton=hook.mp.Mypipelinepage_Save_Button.isDisplayed();
			if ((saveButton)&(progressingStatus=false)) {
				loginfo.log(Status.PASS, "Save button is enabled once after uploading a document");
			} else {
				loginfo.log(Status.FAIL, "Save button is not enabled once after uploading a document");
			}
		} catch (Exception e) {
			fname = hook.cm.addScreenshot(testContext);
			loginfo.log(Status.FAIL, e.getMessage());
			loginfo.addScreenCaptureFromPath(fname);

		}
	}
	@Then("^User perform activity for more than 10 minutes and verify Application should not log out$")
	public void User_perform_activity_verify_Application_should_not_log_outEvenAfter_15Mins() throws Exception {
		ExtentTest loginfo = null;
		try {
			loginfo = test.createNode(new GherkinKeyword("Then"), "User perform activity for more than 15 minutes and verify Application should not log out");			
			hook.wait.until(ExpectedConditions.visibilityOf(hook.mp.Mypipelinepage_NewLoan_button));
			boolean progressingStatus=false;
			for(int i=0;i<3;i++) {
				hook.actions.pause(2500*60).build().perform();				
				hook.mp.Mypipelinepage_NewLoan_button.click();
				hook.actions.pause(60000).build().perform();
				hook.mp.Mypipelinepage_close_ICon.click();
			}
			try {
				if(hook.mp.Mypipelinepage_Session_ExpireScreen.isDisplayed()|hook.mp.Mypipelinepage_SignOut_Msg.isDisplayed());
				progressingStatus=true;
				loginfo.log(Status.INFO, "Application has been signed out after 10 mins though we are doing some activity");
			} catch (Exception e) {
					loginfo.log(Status.INFO, "Application is not signing out after 10 mins while we are doing some activity");
			}
			if (progressingStatus==false) {
				loginfo.log(Status.PASS, "Application is not signing out after 10 mins while we are doing some activity");
			} else {
				loginfo.log(Status.FAIL, "Application has been signed out after 10 mins though we are doing some activity");
			}
		} catch (Exception e) {
			fname = hook.cm.addScreenshot(testContext);
			loginfo.log(Status.FAIL, e.getMessage());
			loginfo.addScreenCaptureFromPath(fname);

		}
	}
	
	@Then("^wait for \"(.*)\" minutes to verify expected message$")
	public void wait_for_Specific_Time(String time) throws Exception {
		ExtentTest loginfo = null;
		try {
			loginfo = test.createNode(new GherkinKeyword("Then"), "wait for "+time+" minutes to verify session expiry message");
				for(int i=0;i<Integer.parseInt(time);i++) {
					Thread.sleep(1000*60);
				}
				loginfo.log(Status.PASS, "waited for "+time+" minutes to verify session expiry message");
		} catch (Exception e) {
			fname = hook.cm.addScreenshot(testContext);
			loginfo.log(Status.FAIL, e.getMessage());
			loginfo.addScreenCaptureFromPath(fname);

		}
	}
}
