package com.bki.ot.uwa.automation.pageobjectmanager;


import com.bki.ot.uwa.automation.pageobjects.GenericPage;
import com.bki.ot.uwa.automation.pageobjects.IncomeVarificationTab;
import com.bki.ot.uwa.automation.pageobjects.LoanLandingPage;
import com.bki.ot.uwa.automation.pageobjects.LoanOverview;
import com.bki.ot.uwa.automation.pageobjects.MyPipelinePage;
import com.bki.ot.uwa.automation.stepdefinitions.CommonMethods;
import org.openqa.selenium.WebDriver;

public class PageObjectManager {

	private WebDriver driver;
	private GenericPage genericPage;
	private CommonMethods commonMethods;
	private MyPipelinePage myPipelinePage;
	private LoanLandingPage loanLandingPage;
	private IncomeVarificationTab incomeVerification;
	private LoanOverview loanOverview;	

	public PageObjectManager(WebDriver driver) {
		this.driver = driver;
	}

	public GenericPage getGenericPage() {
		return (genericPage == null) ? genericPage = new GenericPage(driver) : genericPage;
		
	}
	public CommonMethods getCommonMethods() {
		return (commonMethods == null) ? commonMethods = new CommonMethods(driver) : commonMethods;
		
	}
	public MyPipelinePage getmyPipelinePage() {
		return (myPipelinePage == null) ? myPipelinePage = new MyPipelinePage(driver) : myPipelinePage;
		
	}
	
	public LoanLandingPage getloanLandingPage() {
		return (loanLandingPage == null) ? loanLandingPage = new LoanLandingPage(driver) : loanLandingPage;
		
	}
	public IncomeVarificationTab getIncomeVarificationTab() {
		return (incomeVerification == null) ? incomeVerification = new IncomeVarificationTab(driver) : incomeVerification;		
	}
	
	public LoanOverview getLoanOverview() {
		return (loanOverview == null) ? loanOverview = new LoanOverview(driver) : loanOverview;
	}
}
