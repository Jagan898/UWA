package com.bki.ot.uwa.automation.stepdefinitions;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.InputStreamReader;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

import org.openqa.selenium.By;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.GherkinKeyword;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.gherkin.model.Feature;
import com.aventstack.extentreports.gherkin.model.Scenario;
import com.bki.ot.uwa.automation.extentreport.ExtentReportConfig;
import com.bki.ot.uwa.automation.testcontext.TestContext;

import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.cucumber.java.en.Given;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class APIStepDef extends ExtentReportConfig {

	Hooks hook;
	TestContext testContext;
	String url = null;
	public static String fname;
	public String bearerToken = "";
	RequestSpecification request = null;
	Response response = null;
	public static BufferedReader fr = null;
	String line = null;
	Scanner sc = null;

	public APIStepDef(TestContext context) {
		testContext = context;
		hook = new Hooks(context);
		url = "https://dinochiesa.github.io/pkce-redirect/";

	}

	@Given("^I generate the bearer token$")
	public void generateBearerToken() throws Throwable {
		ExtentTest loginfo = null;
		try {
			test = extent.createTest(Scenario.class, hook.getScenarioName())
					.createNode(Feature.class, hook.getFeatureFileNameFromScenarioId())
					.createNode(Scenario.class, hook.getScenarioName());
			loginfo = test.createNode(new GherkinKeyword("Given"), "Launch URL");
			hook.driver.get(url);
			Thread.sleep(10000l);
			String challengeToken = hook.driver.findElement(By.xpath("//input[@id='code_challenge']"))
					.getAttribute("value");
			String codeVerifier = hook.driver.findElement(By.xpath("//input[@id='code_verifier']"))
					.getAttribute("value");
			loginfo.log(Status.INFO, "Challenge Token : " + challengeToken);
			loginfo.log(Status.INFO, "Code Verifier : " + codeVerifier);
			loginfo.log(Status.INFO, "URL Launched successfully");
			String url2 = "https://api-st.dev.bkitest.com/adfs/oauth2/v1/authorize?redirect_uri=http://localhost:4200/&response_type=code&scope=A&code_challenge_method=S256&code_challenge="
					+ challengeToken + "&state=somethingds&client_id=5SUtpjvCqeY2NchUl0GArWdAob2Saj2Q";
			loginfo.log(Status.INFO, "Challenge Token URL : " + url2);

			hook.driver.get(url2);
			Thread.sleep(10000l);
			UserLoginStepDef login = new UserLoginStepDef(testContext);
			login.UserLogin();
			Thread.sleep(10000l);
			String newUrl = hook.driver.getCurrentUrl();
			loginfo.log(Status.INFO, "New URL : " + newUrl);
			String tokenCode = newUrl.substring(28, newUrl.indexOf("&"));
			loginfo.log(Status.INFO, "Token Code : " + tokenCode);
			String bearerTokenCmd = "curl -i -X POST \"https://api-st.dev.bkitest.com/adfs/oauth2/v1/token\"  -d \"grant_type=authorization_code&client_id=5SUtpjvCqeY2NchUl0GArWdAob2Saj2Q&code_verifier="
					+ codeVerifier + "&code=" + tokenCode + "&redirect_uri=http://localhost:4100\"";
			loginfo.log(Status.PASS, "Bearer token Command : " + bearerTokenCmd);
			Runtime rt = Runtime.getRuntime();
			Process p = rt.exec(bearerTokenCmd);
			String s;
			BufferedReader br = new BufferedReader(new InputStreamReader(p.getInputStream()));
			for (int i = 0; i < 20; ++i)
				br.readLine();
			String lineIWant = br.readLine();
			loginfo.log(Status.INFO, lineIWant);
			bearerToken = lineIWant.substring(21, 49);
			loginfo.log(Status.PASS, "Bearer Token : " + bearerToken);
			String Browser = System.getProperty("browserType");
			String BrowserOption = System.getProperty("chromeOptionsArg");
			loginfo.log(Status.INFO, "Browser Type : " + Browser);
			if ("--headless".equalsIgnoreCase(BrowserOption)) {
				loginfo.log(Status.INFO, "Browser Option :" + BrowserOption);
			}
		} catch (Exception e) {
			loginfo.log(Status.FAIL, "Bearer Token validation failed " + e.getMessage());

		}

	}

	@When("^I provide baseURI as \"([^\"]*)\" and contentType as \"([^\"]*)\" and payload as \"([^\"]*)\" and perform the request \"([^\"]*)\"$")
	public void i_provided_baseURI_as_contentType_as_and_payload_as_and_perform_the_request(String baseURI,
			String contentType, String payload, String requestType) throws Throwable {

		ExtentTest loginfo = null;
		try {
			loginfo = test.createNode(new GherkinKeyword("When"),
					"I provide baseURI as " + baseURI + " and contentType as " + contentType + " and payload as "
							+ payload + " and perform the request " + requestType);
			if (contentType.equalsIgnoreCase("JSON")) {
				request = RestAssured.given().auth().preemptive().oauth2(bearerToken);
				request.contentType(io.restassured.http.ContentType.JSON);
			}

			switch (requestType) {

			case "GET":

				fr = new BufferedReader(new FileReader("src\\test\\resources\\QA1DataTable.properties"));
				sc = new Scanner(fr);
				while (sc.hasNextLine()) {
					line = sc.nextLine();
					if (line.contentEquals(baseURI)) {
						line = sc.nextLine().toString();
						loginfo.log(Status.INFO, "Line4 : " + line);
						RestAssured.baseURI = line;
					}
				}
				if (baseURI.contains("EncodedURI")) {

					response = request.log().all().urlEncodingEnabled(false).baseUri(RestAssured.baseURI)
							.queryParam("LoanID", "DI-C01_v3.4")
							.queryParam("PK", "Loan%3934a05b-533b-4251-a3dc-6c18de7fe846").when().get("/review");

				}else if (baseURI.contains("12346")) {
					request = RestAssured.given().auth().preemptive().oauth2(bearerToken);
					response = request.queryParam("fieldStatus", "Active").queryParam("searchBy", "LoanType").get("/configure");

				} else {
					response = request.get(RestAssured.baseURI);
				}
				loginfo.log(Status.PASS, "Validate GET Response :" + response.asString());
				break;

			case "POST":

				fr = new BufferedReader(new FileReader("src\\test\\resources\\QA1DataTable.properties"));
				sc = new Scanner(fr);
				while (sc.hasNextLine()) {
					line = sc.nextLine();
					if (line.contentEquals(baseURI)) {
						line = sc.nextLine().toString();
						loginfo.log(Status.PASS, "Line4 : " + line);
						RestAssured.baseURI = line;
						line = sc.nextLine();
						if (line.toString().contains(baseURI)) {
							loginfo.log(Status.INFO, line);
							loginfo.log(Status.INFO, "Paths.get() :" + Paths.get(line));
							String json = new String(Files.readAllBytes(Paths.get(line)));
							loginfo.log(Status.INFO, "Json File : " + json);
							request.body(json);
						}
					}
				}
				response = request.post(RestAssured.baseURI);
				loginfo.log(Status.PASS, "Validate POST Response : " + response.asString());
			}
		} catch (Exception e) {
			loginfo.log(Status.FAIL, "Getting Response from the request failed " + e.getMessage());
		}
	}

	@Then("^I validate the status code as \"([^\"]*)\"$")
	public void i_validated_statuscode_as(String statuscode) throws Throwable {
		ExtentTest loginfo = null;
		try {
			loginfo = test.createNode(new GherkinKeyword("Then"), "I validate the status code as " + statuscode);
			int statuscode1 = response.getStatusCode();
			loginfo.log(Status.INFO, statuscode + " and " + statuscode1);
			assertEquals(statuscode, String.valueOf(statuscode1));
		} catch (Exception e) {
			loginfo.log(Status.FAIL, "Status code validation failed " + e.getMessage());
		}
	}

	@Then("^I validate the response values for \"([^\"]*)\"$")
	public void i_validated_below_table_data(String baseURI) throws Throwable {

		ExtentTest loginfo = null;
		try {
			loginfo = test.createNode(new GherkinKeyword("Then"), "I validate the response values for " + baseURI);
			fr = new BufferedReader(new FileReader("src\\test\\resources\\QA1DataTable.properties"));
			Response resp = response.then().extract().response();
			String payload1 = resp.asString();
			String s = "{\"documentExtensions\":[{";
			payload1 = payload1.replace(s, "{");
			List<String> myList = new ArrayList<>();

			Scanner sc = new Scanner(fr);
			while (sc.hasNextLine()) {
				String line = sc.nextLine();
				if (line.contentEquals(baseURI)) {
					sc.nextLine();
					do {
						myList.add(String.valueOf(line.toString()));
						line = sc.nextLine();
					} while (!line.contains("break"));
				}
			}

			loginfo.log(Status.INFO, "My List : " + myList);
			myList.remove(0);

			if (myList.get(0).contains("files")) {
				myList.remove(0);
			}
			myList.removeAll(Arrays.asList("", null));
			loginfo.log(Status.INFO, "My List2 : " + myList);
			Collections.replaceAll(myList, ",,", ",");

			// Response
			List<String> actualResult = new ArrayList<String>(Arrays.asList(payload1.split(",")));
			loginfo.log(Status.INFO, "Response Values : " + actualResult);
			// DataTable
			List<String> expectedResult = myList;
			loginfo.log(Status.INFO, "Data Table Values : " + expectedResult);
			int c = 0;
			// change
			int expCnt = expectedResult.size();
			int actCnt = actualResult.size();
			loginfo.log(Status.INFO, "Payload size : " + actCnt + " and Data Table size : " + expCnt);
			loginfo.log(Status.INFO, "Begin Test");
			String expResult = "";
			String resResult = "";

			for (int i = c; i < expCnt; i++) {

				// Expected Value
				String expectedValue = expectedResult.get(i).toString();
				expResult = expectedValue.replace("\"", "").replace("{", "").replace("]", "").replace("[", "")
						.replace("}", "").trim();

				// Response Value
				for (int p = 0; p < actCnt; p++) {
					String responseValue = actualResult.get(p);
					resResult = responseValue.replace("\"", "").replace("{", "").replace("]", "").replace("[", "")
							.replace("}", "").trim();
					loginfo.log(Status.INFO, "First Log Value : " + expResult + " and " + resResult);

					if (resResult.equalsIgnoreCase(expResult)) {
						assertTrue(resResult.equalsIgnoreCase(expResult), "Response value: " + resResult + " Expected value: " + expResult + "");
						break;
					} else {
						continue;
					}
				}
				loginfo.log(Status.INFO, "Expected Result2 : " + expResult);
				loginfo.log(Status.INFO, "Response Result2 : " + resResult);

				assertTrue(resResult.equalsIgnoreCase(expResult), "Response value: " + resResult + " Expected value: " + expResult + "");
			}
		} catch (Exception e) {
			loginfo.log(Status.FAIL, "Validation of Responses failed " + e.getMessage());
		}
	}
}
