package com.bki.ot.uwa.automation.stepdefinitions;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.GherkinKeyword;
import com.aventstack.extentreports.Status;
import com.bki.ot.uwa.automation.extentreport.ExtentReportConfig;
import com.bki.ot.uwa.automation.filereadermanager.FileReaderManager;
import com.bki.ot.uwa.automation.testcontext.TestContext;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class LoanLandingStepDef extends ExtentReportConfig {

	Hooks hook;
	TestContext testContext;
	String url = null;
	public static String fname;
	

	public LoanLandingStepDef(TestContext context) {
		testContext = context;
		hook = new Hooks(context);
		url = FileReaderManager.getFileReaderManagerInstance().getConfigInstance().getUrl();

	}

	@When("^User selects \"(.*)\" tab in Loanlanding page$")
	public void UserselectstabinLoanlandingpage(String tab) throws Exception {
		ExtentTest loginfo = null;
		try {
			loginfo = test.createNode(new GherkinKeyword("When"), "User selects " + tab + " tab in Loanlanding page");
			hook.actions.pause(5000).build().perform();
			hook.wait.until(ExpectedConditions.visibilityOfAllElements(hook.lp.LoanLandingPage_Tabs_list));
			for (int i = 0; i < hook.lp.LoanLandingPage_Tabs_list.size(); i++) {
				if (hook.lp.LoanLandingPage_Tabs_list.get(i).getText().equalsIgnoreCase(tab)) {
					loginfo.log(Status.PASS,
							"Successfull clicked on Tab : " + hook.lp.LoanLandingPage_Tabs_list.get(i).getText());
					hook.lp.LoanLandingPage_Tabs_list.get(i).click();
					break;
				}else {
					continue;
				}
			}
		} catch (Exception e) {
			fname = hook.cm.addScreenshot(testContext);
			loginfo.log(Status.FAIL, e.getMessage());
			loginfo.addScreenCaptureFromPath(fname);

		}

	}
	@And("^Loan Landing page display Breadcrumb links$")
	public void LoanLandingpagedisplayBreadcrumblinksandicond(DataTable dt) throws Exception {
		ExtentTest loginfo = null;
		try {
			loginfo = test.createNode(new GherkinKeyword("And"), "Loan Landing page display Breadcrumb links");
			hook.wait.until(ExpectedConditions.visibilityOf(hook.lp.LoanLandingPage_BreadcrumbLink));
			List<String> list = dt.asList(String.class);
			Assert.assertTrue(list.get(0).equalsIgnoreCase(hook.lp.LoanLandingPage_BreadcrumbLink.getText())
					&& list.get(1).equalsIgnoreCase(hook.lp.LoanLandingPage_Breadcrumb_LoanNumber.getText()));
			loginfo.log(Status.PASS, "Successfully Breadcrumb links displayed :" + "<br />"
					+ hook.lp.LoanLandingPage_BreadcrumbLink.getText());
			loginfo.log(Status.PASS, "Successfully Loan number displayed in Breadcrumb :" + "<br />"
					+ hook.lp.LoanLandingPage_Breadcrumb_LoanNumber.getText());

		} catch (AssertionError e) {
			fname = hook.cm.addScreenshot(testContext);
			loginfo.log(Status.FAIL, "Verify Breadcrumb,Loan number " + e.getMessage());
			loginfo.addScreenCaptureFromPath(fname);

		}

	}
	@And("^Information headers displayed in loan landing page$")
	public void Informationheadersdisplayedinloanlandingpage(DataTable dt) throws Exception {
	ExtentTest loginfo = null;
	try {
		loginfo = test.createNode(new GherkinKeyword("And"), "Information headers displayed in loan landing page");
		hook.wait.until(ExpectedConditions.visibilityOfAllElements(hook.lp.LoanLandingPage_InfoHeaders_list));
		List<String> list = dt.asList(String.class);
		loginfo.log(Status.PASS, "All Information Headers displayed in Loand landing page:");
		for (int i = 0; i < hook.lp.LoanLandingPage_InfoHeaders_list.size(); i++) {
			if (list.get(i).equalsIgnoreCase(hook.lp.LoanLandingPage_InfoHeaders_list.get(i).getText())) {
				loginfo.log(Status.PASS, "" + hook.lp.LoanLandingPage_InfoHeaders_list.get(i).getText());
			} else {
				loginfo.log(Status.FAIL, "Information Headers are  not displayed"
						+ hook.lp.LoanLandingPage_InfoHeaders_list.get(i).getText());
			}
		}
	} catch (Exception e) {
		fname = hook.cm.addScreenshot(testContext);
		loginfo.log(Status.FAIL, e.getMessage());
		loginfo.addScreenCaptureFromPath(fname);
	}
}

@And("^Tabs displayed in Loan landing page$")
public void TabsdisplayedinLoanlandingpage(DataTable dt) throws Exception {
	ExtentTest loginfo = null;
	try {
		loginfo = test.createNode(new GherkinKeyword("And"), "Tabs displayed in Loan landing page");
		hook.wait.until(ExpectedConditions.visibilityOfAllElements(hook.lp.LoanLandingPage_Tabs_list));
		List<String> list = dt.asList(String.class);
		loginfo.log(Status.PASS, "Tabs displayed in Loan Landing page :");
		for (int i = 0; i < hook.lp.LoanLandingPage_Tabs_list.size(); i++) {
			if (list.get(i).equalsIgnoreCase(hook.lp.LoanLandingPage_Tabs_list.get(i).getText())) {
				loginfo.log(Status.PASS, "" + "<br />" + hook.lp.LoanLandingPage_Tabs_list.get(i).getText());

			} else {
				loginfo.log(Status.FAIL, "Tabs are not displayed in Loand landing page: "
						+ hook.lp.LoanLandingPage_Tabs_list.get(i).getText());
			}
		}
	} catch (Exception e) {
		fname = hook.cm.addScreenshot(testContext);
		loginfo.log(Status.FAIL, e.getMessage());
		loginfo.addScreenCaptureFromPath(fname);
	}
}

@When("^User verify \"(.*)\" tab in Loanlanding page$")
public void UserverifytabinLoanlandingpage(String tab) throws Exception {
	ExtentTest loginfo = null;
	try {
		loginfo = test.createNode(new GherkinKeyword("When"), "User verify " + tab + " tab in Loanlanding page");
		int flag = 0;
		hook.wait.until(ExpectedConditions.visibilityOfAllElements(hook.lp.LoanLandingPage_Tabs_list));
		for (int i = 0; i < hook.lp.LoanLandingPage_Tabs_list.size(); i++) {
			if (hook.lp.LoanLandingPage_Tabs_list.get(i).getText().equalsIgnoreCase(tab)) {
				Assert.assertTrue(hook.lp.LoanLandingPage_Tabs_list.get(i).getCssValue("color").substring(8, 19)
						.equals("116, 217, 1"));
				loginfo.log(Status.PASS,
						"Successfull naviagted on Tab : " + hook.lp.LoanLandingPage_Tabs_list.get(i).getText());
				flag = 1;
				break;
			}else {
				continue;
			}
		}
		if (flag == 1) {
			loginfo.log(Status.PASS, "User is on tab : " + tab);
		} else {
			loginfo.log(Status.FAIL, "Unable to navigate on tab" + tab);
		}
	} catch (Exception e) {
		fname = hook.cm.addScreenshot(testContext);
		loginfo.log(Status.FAIL, e.getMessage());
		loginfo.addScreenCaptureFromPath(fname);

	}

}

@Then("^My To Dos should display with data$")
public void MyToDosshoulddisplaywithdata(DataTable dt) throws Exception {
	ExtentTest loginfo = null;
	try {
		loginfo = test.createNode(new GherkinKeyword("Then"), " My To Do's should display with data");
		hook.wait.until(ExpectedConditions.visibilityOfAllElements(hook.lp.LoanLandingPage_My_to_list_name));
		List<String> list = dt.asList(String.class);
		Assert.assertTrue(list.get(0).equalsIgnoreCase(hook.lp.LoanLandingPage_My_to_list_heaidngs.get(0).getText())
				&& list.get(1).equalsIgnoreCase(hook.lp.LoanLandingPage_My_to_list_heaidngs.get(1).getText())
				&& list.get(2).equalsIgnoreCase(hook.lp.LoanLandingPage_My_to_list_heaidngs.get(2).getText())
				&& list.get(3).equalsIgnoreCase(hook.lp.LoanLandingPage_My_to_list_heaidngs.get(3).getText()));
		loginfo.log(Status.PASS,
				"1 new variance identified && 7 open conditions :" + "<br />"
						+ hook.lp.LoanLandingPage_My_to_list_heaidngs.get(0).getText() + "<br />"
						+ hook.lp.LoanLandingPage_My_to_list_heaidngs.get(1).getText());

		try {

			hook.lp.LoanLandingPage_My_to_list_number.isDisplayed();
			loginfo.log(Status.PASS,
					"My to do list number is  :" + hook.lp.LoanLandingPage_My_to_list_number.getText());
		}

		catch (Exception e) {
			loginfo.log(Status.FAIL, "My To Do's number is not displayed  " + e.getMessage());
		}

	} catch (AssertionError e) {
		fname = hook.cm.addScreenshot(testContext);
		loginfo.log(Status.FAIL, "My To Do's should display with data " + e.getMessage());
		loginfo.addScreenCaptureFromPath(fname);

	}

}

@When("^User clicks on 1 new variance identified$")
public void Userclickson1newvarianceidentified() throws Exception {
	ExtentTest loginfo = null;
	try {
		loginfo = test.createNode(new GherkinKeyword("When"), "User clicks on 1 new variance identified");
		hook.wait.until(ExpectedConditions.visibilityOfAllElements(hook.lp.LoanLandingPage_My_to_list_name));
		hook.lp.LoanLandingPage_My_to_list_varince_arrow.click();
		loginfo.log(Status.PASS, "User clicks on new varinace link ");

	} catch (AssertionError e) {
		fname = hook.cm.addScreenshot(testContext);
		loginfo.log(Status.FAIL, "User is not able  clicks on new varinace link  " + e.getMessage());
		loginfo.addScreenCaptureFromPath(fname);

	}

}

@When("^click on open Conditions$")
public void clickonopenConditions() throws Exception {
	ExtentTest loginfo = null;
	try {
		loginfo = test.createNode(new GherkinKeyword("When"), "click on open Conditions");
		hook.wait.until(ExpectedConditions.visibilityOfAllElements(hook.lp.LoanLandingPage_My_to_list_name));
		hook.lp.LoanLandingPage_My_to_list_conditions_arrow.click();
		loginfo.log(Status.PASS, "User click on open Conditions ");

	} catch (AssertionError e) {
		fname = hook.cm.addScreenshot(testContext);
		loginfo.log(Status.FAIL, "User is not able  click on open Conditions  " + e.getMessage());
		loginfo.addScreenCaptureFromPath(fname);

	}

}
@When("^Displays Status Analyzing Documents with Bg grey color$")
public void DisplaysStatusAnalyzingDocumentswithBggreycolor() throws Exception {
	ExtentTest loginfo = null;
	try {
		loginfo = test.createNode(new GherkinKeyword("When"),
				"Displays Status Analyzing Documents with Bg grey color");
		hook.wait.until(ExpectedConditions.visibilityOf(hook.lp.LoanLandingPage_Loan_Status));
		Assert.assertTrue(hook.lp.LoanLandingPage_Loan_Status.getText().equalsIgnoreCase("Analyzing Docs")
				&& hook.lp.LoanLandingPage_Loan_Status_BGcolor.getCssValue("background-color").substring(5, 21)
						.equalsIgnoreCase("43, 46, 76, 0.08"));
		loginfo.log(Status.PASS,
				"Loan status displayed properly :" + hook.lp.LoanLandingPage_Loan_Status.getText() + "<br />"
						+ "Status Bg color:"
						+ hook.lp.LoanLandingPage_Loan_Status_BGcolor.getCssValue("background-color"));
	} catch (AssertionError e) {
		fname = hook.cm.addScreenshot(testContext);
		loginfo.log(Status.FAIL, "Verify Loan status Analyzing Documents and Bg color is Grey" + e.getMessage());
		loginfo.addScreenCaptureFromPath(fname);

	}
}

@When("^Displays Status Ready for Review with Bg light orange color$")
public void DisplaysStatusReadyforReviewwithBggreycolor() throws Exception {
	ExtentTest loginfo = null;
	try {
		loginfo = test.createNode(new GherkinKeyword("When"),
				"Displays Status Ready for Review with Bg grey color");
		hook.wait.until(ExpectedConditions.visibilityOf(hook.lp.LoanLandingPage_Loan_Status));
		Assert.assertTrue(hook.lp.LoanLandingPage_Loan_Status.getText().equalsIgnoreCase("Ready For Review")
				&& hook.lp.LoanLandingPage_Loan_Status_BGcolor.getCssValue("background-color").substring(5, 22)
						.equalsIgnoreCase("240, 117, 9, 0.08"));
		loginfo.log(Status.PASS,
				"Loan status displayed properly :" + hook.lp.LoanLandingPage_Loan_Status.getText() + "<br />"
						+ "Status Bg color:"
						+ hook.lp.LoanLandingPage_Loan_Status_BGcolor.getCssValue("background-color"));
	} catch (AssertionError e) {
		fname = hook.cm.addScreenshot(testContext);
		loginfo.log(Status.FAIL,
				"Verify Loan status Ready for Review and Bg color is light orange" + e.getMessage());
		loginfo.addScreenCaptureFromPath(fname);

	}
}

@When("^Displays Status Not Started with Bg light red color$")
public void DisplaysStatusNotStartedwithBggreycolor() throws Exception {
	ExtentTest loginfo = null;
	try {
		loginfo = test.createNode(new GherkinKeyword("When"), "Displays Status Not Started  with Bg grey color");
		hook.wait.until(ExpectedConditions.visibilityOf(hook.lp.LoanLandingPage_Loan_Status));
		Assert.assertTrue(hook.lp.LoanLandingPage_Loan_Status.getText().equalsIgnoreCase("Not Started")
				&& hook.lp.LoanLandingPage_Loan_Status_BGcolor.getCssValue("background-color").substring(5, 22)
						.equalsIgnoreCase("219, 55, 44, 0.08"));
		loginfo.log(Status.PASS,
				"Loan status displayed properly :" + hook.lp.LoanLandingPage_Loan_Status.getText() + "<br />"
						+ "status Bg color:"
						+ hook.lp.LoanLandingPage_Loan_Status_BGcolor.getCssValue("background-color"));
	} catch (AssertionError e) {
		fname = hook.cm.addScreenshot(testContext);
		loginfo.log(Status.FAIL, "Verify Loan status Not Started and Bg color is light red" + e.getMessage());
		loginfo.addScreenCaptureFromPath(fname);

	}
}

@When("^Displays Status In progress with Bg light blue color$")
public void DisplaysStatusInprogresswithBggreycolor() throws Exception {
	ExtentTest loginfo = null;
	try {
		loginfo = test.createNode(new GherkinKeyword("When"), "Displays Status In progress with Bg grey color");
		hook.wait.until(ExpectedConditions.visibilityOf(hook.lp.LoanLandingPage_Loan_Status));
		Assert.assertTrue(hook.lp.LoanLandingPage_Loan_Status.getText().equalsIgnoreCase("In Progress")
				&& hook.lp.LoanLandingPage_Loan_Status_BGcolor.getCssValue("background-color").substring(5, 22)
						.equalsIgnoreCase("0, 116, 217, 0.08"));
		loginfo.log(Status.PASS,
				"Loan status displayed properly :" + hook.lp.LoanLandingPage_Loan_Status.getText() + "<br />"
						+ "Status Bg color:"
						+ hook.lp.LoanLandingPage_Loan_Status_BGcolor.getCssValue("background-color"));
	} catch (AssertionError e) {
		fname = hook.cm.addScreenshot(testContext);
		loginfo.log(Status.FAIL, "Verify Loan status In progress and Bg color is light blue" + e.getMessage());
		loginfo.addScreenCaptureFromPath(fname);

	}
}

@When("^Displays Status Completed with Bg light green color$")
public void DisplaysStatusCompletedwithBggreycolor() throws Exception {
	ExtentTest loginfo = null;
	try {
		loginfo = test.createNode(new GherkinKeyword("When"), "Displays Status Completed with Bg grey color");
		hook.wait.until(ExpectedConditions.visibilityOf(hook.lp.LoanLandingPage_Loan_Status));
		Assert.assertTrue(hook.lp.LoanLandingPage_Loan_Status.getText().equalsIgnoreCase("Completed")
				&& hook.lp.LoanLandingPage_Loan_Status_BGcolor.getCssValue("background-color").substring(5, 21)
						.equalsIgnoreCase("0, 138, 39, 0.08"));
		loginfo.log(Status.PASS,
				"Loan status displayed properly :" + hook.lp.LoanLandingPage_Loan_Status.getText() + "<br />"
						+ "Status Bg color:"
						+ hook.lp.LoanLandingPage_Loan_Status_BGcolor.getCssValue("background-color"));
	} catch (AssertionError e) {
		fname = hook.cm.addScreenshot(testContext);
		loginfo.log(Status.FAIL, "Verify Loan status Completed and Bg color is light green" + e.getMessage());
		loginfo.addScreenCaptureFromPath(fname);

	}
}

@When("^Displays Status Inactive with Bg light purple color$")
public void DisplaysStatusInactivewithBggreycolor() throws Exception {
	ExtentTest loginfo = null;
	try {
		loginfo = test.createNode(new GherkinKeyword("When"), "Displays Status Inactive with Bg grey color");
		hook.wait.until(ExpectedConditions.visibilityOf(hook.lp.LoanLandingPage_Loan_Status));
		Assert.assertTrue(hook.lp.LoanLandingPage_Loan_Status.getText().equalsIgnoreCase("Inactive")
				&& hook.lp.LoanLandingPage_Loan_Status_BGcolor.getCssValue("background-color").substring(5, 23)
						.equalsIgnoreCase("119, 83, 208, 0.08"));
		loginfo.log(Status.PASS,
				"Loan status displayed properly :" + hook.lp.LoanLandingPage_Loan_Status.getText() + "<br />"
						+ "Status Bg color:"
						+ hook.lp.LoanLandingPage_Loan_Status_BGcolor.getCssValue("background-color"));
	} catch (AssertionError e) {
		fname = hook.cm.addScreenshot(testContext);
		loginfo.log(Status.FAIL, "Verify Loan status Inactive and Bg color is light purple" + e.getMessage());
		loginfo.addScreenCaptureFromPath(fname);

	}
}

@Then("^widgets displayed in loan overview tab$")
public void widgetsdisplayedinloanoverviewtab(DataTable dt) throws Exception {
	ExtentTest loginfo = null;
	try {
		loginfo = test.createNode(new GherkinKeyword("Then"), " widgets displayed in loan overview tab");
		hook.wait.until(ExpectedConditions.visibilityOfAllElements(hook.lp.LoanLandingPage_My_to_list_name));
		List<String> list = dt.asList(String.class);
		Assert.assertTrue(list.get(0)
				.equalsIgnoreCase(hook.lp.LoanLandingPage_Loan_overview_widget_title_list.get(0).getText())
				&& list.get(1)
						.equalsIgnoreCase(hook.lp.LoanLandingPage_Loan_overview_widget_title_list.get(1).getText())
				&& list.get(2).equalsIgnoreCase(
						hook.lp.LoanLandingPage_Loan_overview_widget_title_list.get(2).getText()));
		loginfo.log(Status.PASS,
				"All widgets displayed properly :" + "<br />"
						+ hook.lp.LoanLandingPage_Loan_overview_widget_title_list.get(0).getText() + "<br />"
						+ hook.lp.LoanLandingPage_Loan_overview_widget_title_list.get(1).getText() + "<br />"
						+ hook.lp.LoanLandingPage_Loan_overview_widget_title_list.get(2).getText());
		Assert.assertTrue(hook.lp.LoanLandingPage_Loan_overview_Open_Conditions_widget_icon.isDisplayed()
				&& hook.lp.LoanLandingPage_Loan_overview_OpenVariances_icon.isDisplayed()
				&& hook.lp.LoanLandingPage_Loan_overview_Loan_Process_widget_icon.isDisplayed());
		Assert.assertTrue(hook.lp.LoanLandingPage_Loan_overview_OpenVariances_icon.getCssValue("color")
				.substring(5, 19).equalsIgnoreCase("219, 55, 44, 1")
				&& hook.lp.LoanLandingPage_Loan_overview_Open_Conditions_widget_icon.getCssValue("color")
						.substring(5, 19).equalsIgnoreCase("0, 116, 217, 1")
				&& hook.lp.LoanLandingPage_Loan_overview_Loan_Process_widget_icon.getCssValue("stroke")
						.substring(4, 14).equalsIgnoreCase("0, 138, 39"));
		loginfo.log(Status.INFO, "Open Variances icon displayed with Red color :"
				+ hook.lp.LoanLandingPage_Loan_overview_OpenVariances_icon.getCssValue("color"));
		loginfo.log(Status.INFO, "Open Conditio icon displayed with blue color :"
				+ hook.lp.LoanLandingPage_Loan_overview_Open_Conditions_widget_icon.getCssValue("color"));
		loginfo.log(Status.INFO, "LoanProcess icon displayed with Ggreen color :"
				+ hook.lp.LoanLandingPage_Loan_overview_Loan_Process_widget_icon.getCssValue("stroke"));

	} catch (AssertionError e) {
		fname = hook.cm.addScreenshot(testContext);
		loginfo.log(Status.FAIL, "My To Do's should display with data " + e.getMessage());
		loginfo.addScreenCaptureFromPath(fname);

	}

}

@When("^User clicks \"(.*)\" widget  in Loanlanding page$")
public void UserclickswidgetinLoanlandingpage(String widget) throws Exception {
	ExtentTest loginfo = null;
	try {
		loginfo = test.createNode(new GherkinKeyword("When"),
				"User selects " + widget + " widget  in Loanlanding page");
		int flag = 0;
		hook.wait.until(ExpectedConditions
				.visibilityOfAllElements(hook.lp.LoanLandingPage_Loan_overview_widget_title_list));
		for (int i = 0; i < hook.lp.LoanLandingPage_Loan_overview_widget_title_list.size(); i++) {
			if (hook.lp.LoanLandingPage_Loan_overview_widget_title_list.get(i).getText().equalsIgnoreCase(widget)) {
				loginfo.log(Status.PASS, "Successfull clicked on widget : "
						+ hook.lp.LoanLandingPage_Loan_overview_widget_title_list.get(i).getText());
				hook.lp.LoanLandingPage_Loan_overview_widget_title_list.get(i).click();
				flag = 1;
				break;
			}
		}
		if (flag == 1) {
			loginfo.log(Status.PASS, "widget : " + widget);
		} else {
			loginfo.log(Status.FAIL, "Unable to click on widget : " + widget);
		}

	} catch (Exception e) {
		fname = hook.cm.addScreenshot(testContext);
		loginfo.log(Status.FAIL, e.getMessage());
		loginfo.addScreenCaptureFromPath(fname);

	}
}

@When("^Table view is displayed$")
public void tableViewiDisplayed() throws Exception {
	ExtentTest loginfo = null;
	try {
		loginfo = test.createNode(new GherkinKeyword("When"), "Display the Row count at the right hand side corner of the table");
		
		if (hook.lp.LoanLandingPage_condition_tab_loandocument.isDisplayed()) {			
			loginfo.log(Status.PASS, "Loan document is displayed sucessully in All condition tab");
		} else {
			loginfo.log(Status.FAIL, "Failed to displayed document in All condition tab");
		}
	} catch (AssertionError e) {
		fname = hook.cm.addScreenshot(testContext);
		loginfo.log(Status.FAIL, "Failed to displayed rows in All condition tab" + e.getMessage());
		loginfo.addScreenCaptureFromPath(fname);

	}

	}


@When("^User able to Navigate from Table to Grid view$")
public void userisabletoNavigatetoTableGrid() throws Exception {
	ExtentTest loginfo = null;
	try {
		loginfo = test.createNode(new GherkinKeyword("When"), "clicks on table grid");
		hook.lp.LoanLandingPage_condition_tab_tableGrid.click();
		if (hook.lp.LoanLandingPage_condition_tab_documentname.isDisplayed()) {			
			loginfo.log(Status.PASS, "Document Name is displayed sucessully in All condition tab");
		} else {
			loginfo.log(Status.FAIL, "Failed to displayed document name in All condition tab");
		}
	} catch (AssertionError e) {
		fname = hook.cm.addScreenshot(testContext);
		loginfo.log(Status.FAIL, "Failed to displayed document name in All condition tab" + e.getMessage());
		loginfo.addScreenCaptureFromPath(fname);

	}
}
@And("^All Conditions grid displays All Conditions text$")
public void Allconditionsgriddisplays() throws Exception {
      ExtentTest loginfo = null;
      try {

             loginfo = test.createNode(new GherkinKeyword("And"), "All conditions grid displays All Conditions text");
      hook.wait.until(ExpectedConditions.visibilityOf(hook.lp.LoanLandingPage_Loan_overview_AllConditionstext));
      Assert.assertTrue(hook.lp.LoanLandingPage_Loan_overview_AllConditionstext.getText()
                          .equalsIgnoreCase("All Conditions"));
             loginfo.log(Status.PASS, "All Conditions text displayed");
      } catch (AssertionError e) {
             fname = hook.cm.addScreenshot(testContext);
             loginfo.log(Status.FAIL, "Verify All Conditions text is not displayed" + e.getMessage());
             loginfo.addScreenCaptureFromPath(fname);
      }
}

@Then("^All Conditions grid displays ADD CONDITIONS text$")
public void Addconditionsgriddisplays() throws Exception {
      ExtentTest loginfo = null;
      try {
             loginfo = test.createNode(new GherkinKeyword("Then"), "All Conditions grid displays Add Conditions text");
      hook.wait.until(ExpectedConditions.visibilityOf(hook.lp.LoanLandingPage_addConditionButton));
      Assert.assertTrue(hook.lp.LoanLandingPage_addConditionButton.getText().equalsIgnoreCase("+ Add condition"));
             loginfo.log(Status.PASS, "+ Add Conditions text displayed");
      } catch (AssertionError e) {
             fname = hook.cm.addScreenshot(testContext);
             loginfo.log(Status.FAIL, "Verify + Add Conditions text is not displayed" + e.getMessage());
             loginfo.addScreenCaptureFromPath(fname);
      }
}

@Then("^Verify loan details from \"(.*)\"$")
public void verifyLoanDetailsWithXMLTagValue(String xmlFileName, DataTable dt) throws Exception {
      ExtentTest loginfo = null;
      try {
             loginfo = test.createNode(new GherkinKeyword("Then"), "Verify loan details from " + xmlFileName);
             DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
             DocumentBuilder builder = null;
             builder = factory.newDocumentBuilder();
             String xmlFilePath = System.getProperty("user.dir") + "/src/test/resources/files/" + xmlFileName;
             List<String> listOfUI = new ArrayList<String>();
      listOfUI.add(hook.lp.LoanLandingPage_SideInfovalue_list.get(0).getText());
      listOfUI.add(hook.lp.LoanLandingPage_SideInfovalue_list.get(1).getText());
      listOfUI.add(hook.lp.LoanLandingPage_SideInfovalue_list.get(4).getText());
      listOfUI.add(hook.lp.LoanLandingPage_SideInfovalue_list.get(5).getText());
             List<String> list = dt.asList(String.class);
             for (int i = 0; i < list.size(); i++) {
                   String tags = list.get(i);
                   String[] tagsSplit = tags.split(",");
                   for (int j = 0; j < tagsSplit.length; j++) {
                          Document doc = builder.parse(new File(xmlFilePath));
                          doc.getDocumentElement().normalize();
                          Element rootElement = doc.getDocumentElement();
                          boolean Tag_Exists = false;
                          NodeList node = rootElement.getElementsByTagName(tagsSplit[j]);
                          if (tagsSplit[j].contains("userName")) {
                                String username = hook.gp.Username_Underwriter.getText();
                                 System.out.println("User Name Validation");
                                if (tagsSplit[j].contains(username)) {
                                       System.out.println("val available");
                                       break;
                                }
                          } else {
                                for (int k = 0; k < node.getLength(); k++) {
                                       Node node1 = node.item(k);

                                       Tag_Exists = true;
                                       System.out.println("Current Tag Element " + node1.getNodeName());
                                       System.out.println(node1.getNodeName() + " : " + node1.getTextContent().trim());
                                       String tagName = node1.getNodeName();
                                       String tagValue = node1.getTextContent().trim();
                                       if (listOfUI.get(i).contains(tagValue)) {
                                              loginfo.log(Status.PASS, tagValue + " is matched sccessfully");
                                              loginfo.log(Status.INFO,
                                                           "Tag " + tagName + " is " + tagValue + " And UI value is " + listOfUI.get(i));
                                       }
                                }

                          }
                   }
             }
      } catch (Exception e) {
             fname = hook.cm.addScreenshot(testContext);
             loginfo.log(Status.FAIL, e.getMessage());
             loginfo.addScreenCaptureFromPath(fname);
      }

}




}
